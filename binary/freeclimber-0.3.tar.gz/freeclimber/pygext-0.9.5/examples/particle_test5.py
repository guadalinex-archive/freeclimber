
import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()


from pygext.gl.all import *
from pygext.gl.particles import *
from pygext.lazy import Random

class TestEmitter(RingEmitter):
    delay = 0.01
    num_particles = 1
    life = 1.0
    fade_time = 0.2
    fade_in = 0.0
    scale = Random(0.3, 0.4)
    scale_delta = -0.1
    rotation = Random(360)
    rotation_delta = 100
    color = (0,0,200,155)
    velocity = 100
    angle = 0
    direction = 180
    tangent = True
    radius = 100
    

class TestSystem(BitmapParticleSystem):
    image = "gfx/ball.png"
    layer = "particles"
    mutators = [
        LinearForce(30,-40),
        ]    

class ParticleScene(Scene):
    def enter(self):
        self.new_layer("particles")

        system = TestSystem()

        node = Entity()
        node.set(realx=400, realy=300)

        system.new_emitter(TestEmitter, node)



    def handle_keydown(self, ev):
        director.quit()

screen.init((800,600))
director.run(ParticleScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
