########################################################################
## NOTE: This example is rather old and messy. See asteroids.py for a ##
## much better learning example.                                      ##
##                                                                    ##
## This example won't work properly until updated for latest pygext   ##
########################################################################

import setpath

from sets import Set
from random import random
import time
import pickle

import pygame
from pygame.locals import *

from pygext.gl.all import *
from pygext.color import VGradient
from pygext.render.halo import halocircle
from pygext.gl.vector.primitives import rect
import pygext.sound.generate as sound

try:
    import psyco
    from psyco.classes import *
    psyco.full()
except ImportError:
    pass

#RESOLUTION = (640,480)
RESOLUTION = (800,600)
#RESOLUTION = (1024,768)
#RESOLUTION = (1280,960)
#RESOLUTION = (1600,1200)

FULLSCREEN = False

LEVELS = [
    #(columns, rows, intial_speed)
    (4, 4, 7),
    (7, 3, 8),
    (6, 5, 8),
    (13, 3, 7),
    (7, 7, 9),
    (10, 6, 10),
    (10, 7, 10),
    (10, 8, 11),
    (10, 9, 12),
    (10, 10, 13),
    ]

#coll = RadialCollisions()

class Invader(Entity):

    def __init__(self, index):
        self.anim_index = index
        Entity.__init__(self, self.frames[index])
        self.dead = False
        self.add_collnode("enemies")

    def animate(self):
        self.anim_index = (self.anim_index + 1) % 3
        self.shape = self.frames[self.anim_index]


class Shot(Entity):
    def __init__(self):
        Entity.__init__(self, self.shape)
        self.static_rect = self.shape.bounding_rect

class EnemyShot(Shot):
    pass

class Cannon(Entity):
    def __init__(self):
        Entity.__init__(self, self.shape)
        self.add_collnode("cannon", 35, 0, -70)
        self.add_collnode("cannon", 35, -50, -25)
        self.add_collnode("cannon", 35, 50, -25)
        
        self.recycle = 0
        self.dead = False
        r = Rect(self.shape.bounding_rect)
        r.height -= 50
        r.top += 50
        self.static_rect = r
      

class InvaderGroup(object):
    def __init__(self, scene, cols, rows, speed):
        self.ticker = Ticker(resolution=speed)
        self.direction = 1
        self.difficulty = 0
        self.dropdown = False
        self.scene = scene
        self.invaders = []

        index = 0
        for row in range(rows):
            for col in range(cols):
                invader = Invader(index).place("invaders")
                index += 1
                index %= 3
                invader.set(x = col * 180 + 80, y = row * 140 + 100)
                self.invaders.append(invader)

    def tick(self):
        self.ticker.tick()
        if not self.ticker.realtick:
            return

        if self.dropdown:
            dx = 0
            dy = 1
            self.direction = -self.direction
            self.ticker = Ticker(resolution = self.ticker.resolution*1.1)            
            self.difficulty += 1
        else:
            dx = self.direction
            dy = 0

        next_dropdown = False

        for i in self.invaders:
            i.animate()
            if dy:
                i.do(MoveDelta(0, 60, 1.0/self.ticker.resolution))
            i.x += dx * 20
            #i.y += dy * 60

            if i.dead:
                continue

            if not self.dropdown and (i.x < 100 or i.x > 2900):
                next_dropdown = True

            if i.y > 2000:
                self.scene.cannon_collide(self.scene.cannon, None)
                next_dropdown = False
            
            if random()*2000 < self.difficulty+self.scene.game.level:
                shot = EnemyShot().place("enemyshots").set(x=i.x, y=i.y)
                shot.add_collnode("enemyshots")
                #coll.add_node("enemyshots", shot)
                yvel = 300 + self.difficulty * 20
                xvel = random() * 200 - 100
                gfx = self.scene.game.gfx_explosion
                action = Move(xvel, yvel).limit(area=(0,0,3000,2000)).do(shot)
                shot.action = action
                action += SetAttr(action=None) + Animate(gfx, 0.2) + Delete
                shot.do(Rotate(360))
            
        self.dropdown = next_dropdown

class Invaders(object):

    def __init__(self):
        screen.init(RESOLUTION, (3000,2200), fullscreen=FULLSCREEN, title="Pygext Invaders")
        self.load_resouces()
        self.init_scorelist()
        self.score = 0
        self.level = 0

    def save_scorelist(self):
        f = open("invaders.score", "wb")
        pickle.dump(self.hiscores, f)

    def init_scorelist(self):
        try:
            f = open("invaders.score", "rb")
            try:
                self.hiscores = pickle.load(f)
            finally:
                f.close()
        except:
            self.hiscores = [(0,"")] * 10

    def load_resouces(self):
        Invader.frames = [
            Bitmap("gfx/invader1.png", hotspot=(0.5,0)),
            Bitmap("gfx/invader2.png", hotspot=(0.5,0)),
            Bitmap("gfx/invader3.png", hotspot=(0.5,0)),
            ]

        self.gfx_explosion = [
            Bitmap("gfx/explosion%i.png" % i, hotspot=(0.5,0.5))
            for i in range(1,9)
            ]

        self.gfx_buildings = [
            Bitmap("gfx/building%i.png" % i, hotspot=(0,1))
            for i in range(1,4)
            ]

        self.gfx_shot = Bitmap(
            halocircle((255,255,100), 4, 7, corealpha=0.9, haloalphamax=0.4, haloalphamin=0.2),
            hotspot=(0.5,0.5)).scale(2)

        Cannon.shape = Bitmap("gfx/cannon.png", hotspot=(0.5,1))
        Shot.shape = self.gfx_shot
        EnemyShot.shape = Bitmap("gfx/invadershot.png", hotspot=(0.5,0.5))

        font = pygame.font.SysFont("Arial", 40)
        self.font = GLFont(font)

    def new_game(self):
        self.score = 0
        self.level = 0


class TitleScreen(Scene):

    def init(self):
        self.new_static("bg", -5)
        self.new_static("text", 0)
        self.new_layer("menu", 5)

    def enter(self, game):
        self.game = game

        font = self.game.font

        self.menu = SimpleTextMenu(items=["New Game", "View Scores"], font=font, scale=3)
        self.menu.place("menu")
        self.menu.select_callback = self.menu_select
        self.menu.escape_callback = director.quit

        txt_python = Entity(font.render("Pygext", color=(0,255,0,255)).scale(5)).place("text")
        txt_invaders = Entity(font.render("Invaders", color=(255,0,0,255)).scale(8)).place("text")

        txt_python.top = 50
        txt_python.right = 1500
        
        txt_invaders.centerx = 1500
        txt_invaders.top = txt_python.bottom-50

        invader = Entity(Invader.frames[0]).set(scale=5).place("bg")
        invader.center = 1500,1000

        self.menu.centerx = 1500
        self.menu.top = invader.bottom + 200

    def menu_select(self):
        if self.menu.selected == 0:
            director.set_scene(MainGame, self.game)
        else:
            director.set_scene(ScoreList, self.game, listonly=True)
    
    def handle_keydown(self, event):
        self.menu.handle_keydown(event)

class MainGame(Scene):

    collengine = RadialCollisions

    def init(self):

        self.new_static("background0", 0)
        self.new_static("background1", -5)
        self.new_static("background2", -10)
        self.new_static("sky", -15)
        
        self.new_layer("invaders", 10)
        self.new_layer("enemyshots", 15)
        self.new_layer("shots", 12)
        self.new_layer("cannon", 8)
        self.new_layer("explosions", 20)
        self.new_layer("text", 25)


    def enter(self, game):
        self.game = game
        self.explode = Animate(self.game.gfx_explosion[1:], 0.3) + Delete
        self.shoot = Fork(Scale(1.5, 0.1, PingPongMode)) + \
                     Move(0, -800).limit(area=(0,0,3000,2200)) + \
                     Delete
        self.init_background()
        
##        self.collision_handler["shots", "invaders"] = self.invader_collide
##        self.collision_handler["cannon", "enemyshots"] = self.cannon_collide
##        self.set_collision_handler("ownshots", "enemies", self.invader_collide)
##        self.set_collision_handler("cannon", "enemyshots", self.cannon_collide)

        self.game.new_game()
        self.next_level()

    def init_level(self):
        self.init_invaders()
        self.cannon = Cannon().place("cannon").set(x=1500, y=2050)
        self.cannon.mover = Move(0,0).do(self.cannon)

        level_title = TextEntity(self.game.font, "Level", scale=3).place("text")
        level_title.color = (200,200,200)
        level_title.bottom = 2200
        level_title.left = 50

        level = TextEntity(self.game.font, str(self.game.level), scale=3).place("text")
        level.bottom = level_title.bottom
        level.left = level_title.right + 50

        score_title = TextEntity(self.game.font, "Score", scale=3).place("text")
        score_title.color = (200,200,200)
        score_title.left = 700
        score_title.bottom = 2200

        self.score = score = TextEntity(self.game.font, str(self.game.score), scale=3.0).place("text")
        score.left = score_title.right + 50
        score.bottom = 2200
        
        self.level_start = time.time()


    def add_score(self, pts):
        self.game.score += pts
        left = self.score.left
        self.score.set_text(str(self.game.score))
        self.score.left = left

    def end_level(self):
        director.reactor.clear()
        
        endtime = time.time()
        t = int(endtime - self.level_start)
        
        self.set_state("endlevel")

        lvl_bonus = self.game.level * 200        
        time_bonus = int(10000 * self.game.level / (t*(0.9**self.game.level)+10))        

        txt_header = TextEntity(self.game.font, "Level %i Clear!" % self.game.level, scale=5)
        txt_lvl_bonus = TextEntity(self.game.font, "Level bonus = %i" % lvl_bonus, scale=3)
        txt_time_bonus = TextEntity(self.game.font, "Time bonus for %is = %i" % (t, time_bonus), scale=3)
        txt_info = TextEntity(self.game.font, "Press SPACE to continue", scale=2)
        
        txt_header.centerx = 1500
        txt_header.y = 500
        
        txt_lvl_bonus.centerx = 1500
        txt_lvl_bonus.top = txt_header.bottom + 200

        txt_time_bonus.centerx = 1500
        txt_time_bonus.top = txt_lvl_bonus.bottom

        txt_info.centerx = 1500
        txt_info.top = txt_time_bonus.bottom + 400

        txt_header.place("text").set(hidden=True)
        txt_lvl_bonus.place("text").set(hidden=True)
        txt_time_bonus.place("text").set(hidden=True)
        txt_info.place("text").set(hidden=True)

        txt_header.do(
            Delay(0.5) +
            Show)

        txt_lvl_bonus.do(
            Delay(1.0) +
            Show +
            CallFunc(self.add_score, lvl_bonus))
        
        txt_time_bonus.do(
            Delay(1.5) +
            Show +
            CallFunc(self.add_score, time_bonus))
        
        txt_info.do(
            Delay(2.0) +
            Show)

    def state_endlevel_handle_keydown(self, ev):
        if ev.key == K_SPACE:
            self.next_level()

    def next_level(self):
        self.game.level += 1
        self.clear_nonstatic()
        director.reactor.clear()
        #coll.start()
        self.init_level()

        self.set_state("intro")

        txt = TextEntity(self.game.font, "Level %02i" % self.game.level, scale=5.0)
        txt.place("text")
        txt.right = 0
        txt.centery = 1100
        delta = 1500 - txt.centerx
       
        action = MoveDelta(delta, 0, secs=0.5) \
                 + Delay(0.3) \
                 + Fork(SetState("main") + ColorFade((0,0,0,0), secs=1.0)) \
                 + MoveDelta(delta, 0, secs=1.0) \
                 + Delete()
        action.do(txt)

    def state_intro_tick(self):
        # hack to keep the invader group in place
        self.invaders.ticker.tick()
        
    def init_invaders(self):
        level = min(self.game.level, len(LEVELS)-1)
        cols,rows,speed = LEVELS[level]
        self.invaders = InvaderGroup(self, cols, rows, speed)

    def init_background(self):
        from random import seed, randrange
        seed(1234) # so that background will look the same every time
        gfx = self.game.gfx_buildings

        for l in range(3):
            x = 0
            while x < 3000:
                index = randrange(3)
                e = Entity(gfx[index])
                bright = randrange(80,110) - l*10
                e.color = (bright,bright,bright,255)
                e.scale = 1.0 + randrange(50,100) / 100.0
                e.x = x
                e.y = 2000
                e.y -= l * randrange(100,150)
                e.place("background%i" % l)
                x += randrange(300,600)
        seed()
        ground = rect(0,0,3000, 350)
        ground.fillcolor(VGradient((0,0,0), (90,80,30)))
        ground = Entity(ground).place("background2").set(left=0, bottom=2065)

        sky = rect(0,0,3000,1500)
        sky.fillcolor(VGradient((0,0,0), (0,0,200)))
        Entity(sky).place("sky").set(left=0, bottom=ground.top)

    def tick_cannon(self):
        cannon = self.cannon
        
        if director.ticker.realtick:
            cannon.recycle -= 1
        
            cannon.mover.vx = 0
            keys = self.keys
            if keys[K_LEFT] and cannon.x > 200:
                cannon.mover.vx = -700
            elif keys[K_RIGHT] and cannon.x < 2800:
                cannon.mover.vx = 700
            if keys[K_SPACE] and cannon.recycle <= 0:
                shot = Shot().place("shots").set(x=cannon.x, y=cannon.y-100)
                shot.add_collnode("ownshots")
                #coll.add_node("ownshots", shot)
                shot.do(self.shoot)
                cannon.recycle = 30 * 0.9 ** self.game.level

    def collision_ownshots_enemies(self, shot, invader):
        if invader.dead:
            return
        shot.abort_actions()
        shot.scale = 1.0
        shot.do(Fork(Scale(3.0, 0.15)) + \
                ColorFade((255,255,255,0), 0.3) + \
                Delete)
        invader.dead = True

        self.add_score(5 + self.game.level)
        invader.do(Blink(0.05, repeats=3) + Delete + CallFunc(self.check_victory))

    def check_victory(self):
        if len(self['invaders']) == 0:
            self.end_level()

    def collision_cannon_enemyshots(self, cannon, shot):
        if cannon.dead:
            return

        cannon.dead = True
        cannon.mover.vx = 0

        if shot and shot.action:
            shot.action.end()
            shot.action = None

        gfx = self.game.gfx_explosion
        
        cannon.do(Blink(0.04).limit(time=2.0) + Delete)
        for e in range(25):
            x = cannon.x + random()*200-100
            y = cannon.y - random()*100
            action = Delay(e*0.1) + CreateAnim("explosions", x, y, gfx, 0.5)
            action.do()
        action += CallFunc(self.wait_end)
        cannon.do(ColorFade((255,255,255,0), 2.0))

        text = self.game.font.render("GAME OVER").scale(10)
        text = Entity(text).place("text")
        text.center = 1500,1100
        text.color = (255,0,0,0)
        text.do(ColorFade((255,0,0,255), 2.0))
        

    def wait_end(self):
        self.set_state("gameover")
        director.reactor.clear()

    def handle_keydown(self, event):
        if event.key == K_F1:
            self.end_level()
        elif event.key == K_F2:
            self.cannon_collide(self.cannon, None)

    def state_gameover_handle_keydown(self, event):
        director.set_scene(ScoreList, self.game)

    def state_gameover_tick(self):
        pass

    def state_main_tick(self):
        
        if director.ticker.realtick:
            self.keys = pygame.key.get_pressed()
            if self.keys[K_ESCAPE]:
                director.quit()
                return
            
            self.invaders.tick()

        if not self.cannon.dead:
            self.tick_cannon()


class ScoreList(Scene):
    def init(self):
        self.new_static("scores")
        self.new_layer("input")
        
    def enter(self, game, listonly=False):
        self.game = game
        score = self.game.score
        font = self.game.font

        self.set_state("view")

        self.txt_info = TextEntity(font, scale=3)\
                        .place("input").set(top=2000)
        
        hiscores = self.game.hiscores
        if not listonly and (not hiscores or score > hiscores[-1][0]):
            hiscores[-1:] = [(score, None)]
            hiscores.sort()
            hiscores.reverse()
            cursor = Entity(rect(0,0,60,80).fillcolor(255,255,255))
            self.input = TextInputEntity(font, scale=3, cursor=cursor, maxlen=10)
            self.set_state("input")
            self.txt_info.set_text("Enter you name")
            self.txt_info.centerx = 1500
        else:
            self.txt_info.set_text("Press SPACE to continue")
            self.txt_info.centerx = 1500

        title = TextEntity(font, "High Scores", scale=5).place("scores")
        title.set(centerx=1500, top=50, color=(0,255,0,255))


        self.index = None
        
        for i, (score,name) in enumerate(hiscores):
            index_e = TextEntity(font, "%i." % (i+1), scale=3)
            index_e.place("scores").set(top=350+i*150, left=100)
            
            score_e = TextEntity(font, str(score), scale=3)
            score_e.set(top=index_e.top, right=1000)
            if name is None:
                self.index = i
                name_e = self.input
                self.score_e = score_e
                score_e.place("input")
                act = ColorFade((255,255,0,255), 0.5, PingPongMode)
                score_e.do(act)
                name_e.do(act)
                cursor.place("input").do(Blink(0.3))
                name_e.place("input")
            else:
                score_e.place("scores")
                name_e = TextEntity(font, name, scale=3).place("scores")
            name_e.set(top=score_e.top, left=1100)
            if name is None:
                name_e.update_cursor()

    def state_view_handle_keydown(self, ev):
        if ev.key == K_SPACE:
            director.set_scene(TitleScreen, self.game)

    def state_input_handle_keydown(self, ev):
        if ev.key == K_RETURN:
            self.game.hiscores[self.index] = (self.game.score, self.input.text)
            self.input.cursor.hidden = True
            self.input.cursor.end_actions()
            for entity in (self.input, self.score_e):
                entity.end_actions()
                entity.color = None
            self.set_state("view")
            self.game.save_scorelist()
            self.txt_info.set_text("Press SPACE to continue")
            self.txt_info.centerx = 1500
        else:
            self.input.handle_keydown(ev)

def run():
    import hotshot, hotshot.stats
    game = Invaders()
    director.run(TitleScreen, game)
##    p = hotshot.Profile("profile.dat")
##    p.runcall(director.run, TitleScreen, game)
##    p.close()
##    stats = hotshot.stats.load("profile.dat")
##    stats.sort_stats('time', 'calls')
##    stats.print_stats(20)
##    stats.print_callers(5)
    
if __name__ == '__main__':
    run()
