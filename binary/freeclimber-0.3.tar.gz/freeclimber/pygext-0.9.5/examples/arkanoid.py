## NOTE:
## This is a very old example and doesn't properly demonstrate
## good pygext coding practices.

import time

import setpath

from pygext.gl.all import *
import pygame
from pygame.locals import *

class Ball(Entity):
    image = "gfx/ball.png"
    layer = "foreground"
    
    def init(self):
        self.set(
            x = 400,
            y = 300,
            scale = 0.7,
        )

        self.mover = Move(240,240).do(self)


class Bat(Entity):
    image = "gfx/bat.png"
    layer = "foreground"
    
    def init(self):
        self.set(
            x = 400,
            y = 500,
            scale = 0.5,
        )

class BatAndBall(Scene):

    def enter(self):
        self.init_layers()
        self.init_entities()
        pygame.event.set_grab(True)
        pygame.mouse.set_pos((400,500))

    def init_layers(self):
        self.new_static("tiles")
        self.new_layer("foreground")

    def init_entities(self):
        self.ball = Ball()
        self.bat = Bat()

        self.init_tiles()

    def init_tiles(self):
        tiles = []
        for row in range(5):
            column = []
            for col in range(10):
                e = Entity("gfx/tile.png")
                e.set(
                    left = col * 65 + 70,
                    top = row * 35 + 20
                )
                e.place("tiles")
                column.append(e)
            tiles.append(column)
        self.tiles = tiles

    def check_collision(self):
        ball = self.ball
        bat = self.bat
        
        ball_rect = ball.get_bounding_rect()

        tx,mx = divmod(int(ball_rect.centerx - 70), 65)
        ty,my = divmod(int(ball_rect.centery - 20), 35)

        if (0 <= tx < 10) and (0 <= ty < 5):
            e = self.tiles[ty][tx]
            if e:
                e.delete()
                self.tiles[ty][tx] = None
                if mx < 5 or mx > 60:
                    ball.mover.vx = -ball.mover.vx
                else:
                    ball.mover.vy = -ball.mover.vy

        if ball_rect.left < 0:
            ball_rect.left = 0
            ball.left = ball_rect.left
            ball.mover.vx = -ball.mover.vx
        elif ball_rect.right > 800:
            ball_rect.right = 800
            ball.left = ball_rect.left
            ball.mover.vx = -ball.mover.vx
        if ball_rect.top < 0:
            ball_rect.top = 0
            ball.top = ball_rect.top
            ball.mover.vy = -ball.mover.vy
        
        bat_rect = bat.get_bounding_rect()
        if ball_rect.colliderect(bat_rect):
            if ball.y < bat.y:
                ball.mover.vy = -ball.mover.vy
                ball_rect.bottom = bat_rect.top
                ball.y = ball_rect.top

    def tick(self):
        x,y = pygame.mouse.get_pos()
        if x < 50:
            x = 50
        elif x > 750:
            x = 750
        self.bat.x = x

        self.check_collision()

    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            director.quit()
        

if __name__ == '__main__':
    screen.init((800,600), title="Arkanoid Example")
    director.run(BatAndBall)
