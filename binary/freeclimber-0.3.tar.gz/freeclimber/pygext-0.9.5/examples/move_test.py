
from pygext.gl.all import *

class TestScene(Scene):
    def enter(self):
        self.new_layer("entities")
        
        self.e1 = e = Entity("gfx/invader1.png")
        e.set(left=0,y=200).place("entities")

        self.e2 = e = Entity("gfx/invader1.png")
        e.set(left=0,y=400).place("entities")

        self.set_state("waitkey")

    def state_waitkey_handle_keydown(self, ev):
        self.set_state(None)
        self.e1.do(Move(10,0))
        self.e2.do(MoveDelta(800,0, secs=80))

    def handle_keydown(self, ev):
        director.quit()


screen.init((800,600))
director.run(TestScene)
