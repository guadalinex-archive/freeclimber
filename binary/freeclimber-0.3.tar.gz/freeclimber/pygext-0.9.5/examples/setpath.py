
try:
    import pygext
except ImportError:
    import sys
    sys.path.append("..")
