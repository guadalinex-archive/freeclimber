"""Miscellanous math utilities
"""
