##
## pyVectorGFX - SVG importer
##
## author: Sami Hangaslammi
## email:  shang@iki.fi
##

from xml.dom import minidom

## XXX this module is at the planning phase
