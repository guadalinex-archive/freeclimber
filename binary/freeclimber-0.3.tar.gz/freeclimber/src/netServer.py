#!/usr/bin/env python

import curses
import os
import threading
import config
from time import sleep, time
import pygame

LOG_FILE = "/tmp/freeclimber-server.log"
f = open(LOG_FILE, 'w')
f.close()

def debug(msg):
    if "--debug" in sys.argv:
        command = "echo '[%.3f] %s' >> %s" % (time(), msg, LOG_FILE)
        os.popen(command)

config.debug = debug
from netFrame import netFrame, netGame, netPlayer

class netServer:
    def __init__(self):
        self.scr = curses.initscr()
        self.serverpid = None
        self.juegoenred = netFrame()
        self.serverstarted = False
        self.running = False
        self.maxy, self.maxx = self.scr.getmaxyx()

        self.titlewin = curses.newwin(7,self.maxx-20,1,10)
        self.menuwin = curses.newwin(10,self.maxx-20,8,10)
        self.debugwin = curses.newwin(self.maxy-26,self.maxx-20,18,10)
        self.statuswin = curses.newwin(8,self.maxx-20,self.maxy-8,10)

        self.text = []
        self.c = ''

        self.scr.clear()

        self.titlewin.clear()
        self.debugwin.clear()
        self.menuwin.clear()
        self.statuswin.clear()

        self.menuwin.border()
        self.debugwin.border()
        self.statuswin.border()

        pygame.init()


    def imprimeTitulo(self):
        #self.titlewin.redrawwin()
        self.titlewin.refresh()

        titulo = []
        titulo.append(" _____ ____  _____ _____ ____ _     ___ __  __ ____  _____ ____")
        titulo.append("|  ___|  _ \| ____| ____/ ___| |   |_ _|  \/  | __ )| ____|  _ \\")
        titulo.append("| |_  | |_) |  _| |  _|| |   | |    | || |\/| |  _ \|  _| | |_) |")
        titulo.append("|  _| |  _ <| |___| |__| |___| |___ | || |  | | |_) | |___|  _ <")
        titulo.append("|_|   |_| \_\_____|_____\____|_____|___|_|  |_|____/|_____|_| \_\\")

        #historial = os.popen(command)
        row = 0

        #for ln in historial:
        #    if ln[-1] == '\n': ln = ln[:-1]
        #    self.titlewin.addstr(row+1,1,str(ln),curses.A_BOLD)
        #    row = row +1

        for ln in titulo:
            self.titlewin.addstr(row+1,1,str(ln),curses.A_BOLD)
            row = row+1

        #historial.close()

        self.titlewin.redrawwin()



    def imprimeStatus(self):
        self.statuswin.refresh()
        #self.statuswin.clear()
        self.statuswin.addstr(1,1,str(self.juegoenred.status),curses.A_BOLD)
        self.statuswin.redrawwin()

    def imprimeDebug(self):

        self.debugwin.refresh()
        #self.debugwin.clear()

        command = "tail -n 20 '%s'"% LOG_FILE
        historial = os.popen(command,'r')
        row = 0

        for ln in historial:
            #ln = ln[:curses.COLS]
            if ln[-1] == '\n': ln = ln[:-1]
            self.text.append(ln)
            self.debugwin.addstr(row+2,2,ln,curses.A_NORMAL)
            row=row+1
        historial.close()
        self.debugwin.redrawwin()

    def imprimeMenu(self):
        self.menuwin.refresh()
        #self.menuwin.clear()

        if not self.serverstarted:
            self.menuwin.addstr(1,1,"Presiona 'j' para iniciar el servidor de red",curses.A_NORMAL)
        else:
            self.menuwin.addstr(1,1,"Presiona 'j' para detener el servidor de red",curses.A_NORMAL)
            self.menuwin.addstr(2,1,"Presiona 'f' para forzar el inicio del juego en red",curses.A_NORMAL)
            self.menuwin.addstr(3,1,"Presiona 'b' para enviar una bomba",curses.A_NORMAL)
        self.menuwin.addstr(4,1,"Presiona 'q' para salir",curses.A_NORMAL)
        self.menuwin.redrawwin()


    def start(self):
        self.running = True
        curses.noecho()
        curses.cbreak()
        self.menuwin.keypad(1)
        self.debugwin.keypad(1)
        self.statuswin.keypad(1)
        threading.Timer(0.5,self.update).start()
        while self.running:
            self.readchar()
            sleep(0.5)

    def update(self):
        self.imprimeTitulo()
        self.imprimeMenu()
        self.imprimeDebug()
        self.imprimeStatus()
        threading.Timer(0.5,self.update).start()
        #self.readchar()


    def readchar(self):
        c = self.menuwin.getch()
        self.c= chr(c)

        if c == 'j':
            if not self.serverstarted:
                self.serverstarted = True
                self.juegoenred.start()
            else:
                self.juegoenred.stop()
                self.serverstarted = False

        elif c == 'f':
            self.juegoenred.game.forceGameStart()
            self.statuswin.addstr(2,2,"Forzando inicio del juego...",curses.A_BOLD)

        elif c == 'b':
            self.juegoenred.eventer.publishObject({'id':'javi','msg':'Bombaaaaaaaaaaa',})

        elif c == 'q':
            self.stop()


    def stop(self):
        self.running = False
        config.debug("Deteniendo interfaz...")
        if self.serverstarted:
            config.debug("Deteniendo servidor de red...")
            #os.remove(config.LOG_FILE)
            self.juegoenred.stop()
            self.serverstarted = True
        curses.echo()
        curses.cbreak()
        self.scr.keypad(0)
        curses.endwin()


def main():
    test = netServer()
    test.start()
    #test.stop()
    os.system('reset')


if __name__ == "__main__" : main()
