#!/usr/bin/python
# -*- coding: utf-8 -*-
# Pyro remote objects test

import Pyro
import Pyro.core
import Pyro.naming
from Pyro.EventService.Server import EventServiceStarter
from Pyro.EventService.Clients import Publisher, Subscriber
from Pyro.naming import NameServerStarter
from Pyro.errors import NamingError, URIError, PyroError
from Pyro.ext.daemonizer import Daemonizer
import signal
import os, sys
import types
import threading
from time import sleep
from config import *
from types import ListType
import socket
from random import randint
import urlparse
import pygame
from pygame.locals import *
#from pygext.gl.all import *


Pyro.config.__dict__['PYRO_TRACELEVEL'] = 3
Pyro.config.__dict__['PYRO_STORAGE'] = '/tmp'
Pyro.config.__dict__['PYRO_NS_URIFILE'] = '/tmp/Pyro_NS_URI'
Pyro.config.__dict__['PYRO_LOGFILE'] = '/tmp/Pyro_log'
DELAY = 3



class netPlayer:

    #colors  = ('violet', 'white', 'pink', 'orange', 'yellow', 'green', 'blue', 'red')

    def __init__(self):
        self.id = str(randint(10**5,10**7))
        self.idgame = None
        self.name = self.id
        self.ip = socket.gethostbyname(socket.gethostname())
        self.score = 0
        self.lifes = 0
        self.level = 0
        self.window = 0
        self.numplayer = 0
        self.ready = False
        self.color = 'violet'

    def __str__(self):
        return "Jugador '%s' (%s) en partida '%s' desde %s <Position: %d, Score: %d, Lifes: %d>" % (self.color, self.name, self.ip, self.idgame, self.level, self.score, self.lifes)

def compare_netplayers(a, b):
    debug ("Comparando jugadores %s y %s..."  % (a, b))
    if not(isinstance(a, netPlayer) and isinstance(b, netPlayer)):
        return 0
    if a.level > b.level:
        return 1
    elif a.level < b.level:
        return -1
    elif a.level == b.level:
        if a.score > b.score:
            return 1
        elif a.score < b.score:
            return -1
        else:
            if a.lifes > b.lifes:
                return 1
            elif a.lifes < b.lifes:
                return -1
            else:
                return 0

class netGame(Pyro.core.SynchronizedObjBase):

    colors  = ['red','green','blue','yellow','pink','white','orange','violet']


    def __init__(self):
        Pyro.core.SynchronizedObjBase.__init__(self)
        self.players = {}
        self.queued = []
        self.gameStarted = False
        self.id = str(randint(10**5,10**7))
        self.winner = None
        self.status = None
        self.timeout = TIMEOUT
        self.ready = False
        self.max_players = MAX_PLAYERS
        self.levels = LEVELS
        #self.theme = None
        self.timer = threading.Timer(1.0, self.is_ready)

    def is_ready(self):
        if self.ready:
            pass
        else:
            ready = True
            for p in self.validPlayers():
                ready = ready and p.ready
            self.ready = ready
        return self.ready and not self.winner

    def register(self,player,isWinner=False):
        if not self.validPlayers():
            self.timeout = TIMEOUT
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()
            debug("Iniciando cuentra atras en %d segundos" % self.timeout)
        if self.playerExists(player):
            debug("Jugador '%s' ya está registrado." % player.name)
            r = "OK"
        elif self.gameStarted:
            debug("Juego ya empezado. Encolando jugador '%s'" % player.name)
            r = "Juego empezado"
            if not player in self.queued: self.queued.append(player)
        elif len(self.players) >= MAX_PLAYERS:
            debug("Alcanzado número máximo de jugadores. Encolando jugador '%s'" % player.name)
            r = "En cola"
            if not player in self.queued: self.queued.append(player)
            self.forceGameStart()
        else:
            debug("Registrando jugador '%s'" % player.name)
            self.addplayer(player)
            self.clean()
            r = "OK"
        return r

    def playersIsList(self):
        return type(self.players) is ListType

    def clean(self):
        for j in self.validPlayers():
            if not j.idgame == self.id:
                self.unregister(j)

    def addplayer(self,player):
        regcolors = []
        for p in self.validPlayers():
            regcolors.append(p.color)
        for c in netGame.colors:
            if not c in regcolors:
                player.color = c
                break
        player.idgame = self.id
        player.numplayer = netGame.colors.index(c)
        if self.playersIsList():
            self.players.append(player)
        else:
            self.players[player.name] = player

    def get_player_by_id(self, id):
        for p in self.validPlayers():
            if p.id == id:
                return p

    def numPlayers(self):
        return len(self.players)

    def countdown(self):
        if self.timeout:
            self.timeout -= 1
            try:
                self.timer = threading.Timer(1.0, self.countdown)
                self.timer.start()
            except:
                debug("Fallo al inicializar el Timer")
        else:
            self.gameStart()

    def unregister(self,player):
        debug("Unregistrando jugador '%s'" % player.name)
        if self.playersIsList():
            for object in self.players:
                if player.name == object.name:
                    self.players.remove(object)
        else:
            if player.name in self.players.keys():
                del self.players[player.name]

        # borrar de la cola
        for q in self.queued:
            if q.id == player.id:
                self.queued.remove(q)

        # registrar el primero de la cola
        if self.queued:
            debug("Comprobando cola de espera...")
            firstqueued = self.queued[0]
            if self.register(firstqueued) == 'OK':
                self.queued.pop(0)

        # terminar juego vacio
        if not self.validPlayers():
            debug("Terminando juego por falta de jugadores")
            self.gameStarted = False
            self.ready = False
            self.timer.cancel()
            #self.gameStop()
            for p in self.queued:
                if self.register(p) == 'OK':
                    self.queued.remove(p)


    def playerExists(self,player):
        if self.playersIsList():
            for temp_player in self.players:
                if player.name == temp_player.name:
                    return True
            return False
        else:
            return player.name in self.players.keys()


    def getQueuePosition(self,player):
        if player in self.queued:
            return self.queued.index(player)

    def getPlayer(self,player):
        if self.playersIsList():
            for temp_player in self.players:
                if player.name == temp_player.name:
                    return temp_player
            return False
        else:
            if player.name in self.players.keys():
                return self.players[player.name]

    def getLeader(self):
        players = self.validPlayers(True)
        if players:
            return players[-1]

    def validPlayers(self, order = False):
        if self.playersIsList():
            jugadores = self.players
        else:
            jugadores = self.players.values()
        if order:
            jugadores.sort(compare_netplayers)
        return jugadores


    def imprime(self):
        text = ""
        if self.playersIsList():
            for object in self.players:
                text += object.name + '\n'

        else:
            for object in self.players.values():
                text += object.name + '\n'

        return text

    def setWinner(self,player):
        self.winner = self.getPlayer(player)
        self.gameStarted = False
        self.ready = False
        self.id = str(randint(10**5,10**7))
        self.timeout = TIMEOUT+15
        self.timer = threading.Timer(1.0, self.countdown)
        self.timer.start()



    def getWinner(self):
        return self.winner


    def isWinner(self,player):
        if self.winner.name == player.name:
            return True


    def updatePlayer(self, player):
        debug("Actualizando %s" % player)
        if self.playersIsList():
            indice = self.getPosition(player)
            self.players.remove(self.getPlayer(player))
            self.players.insert(indice,player)
        else:
            self.players.update({player.name:player})


    def forceGameStart(self):
        try:
            self.timer.cancel()
        except:
            self.timeout = 0
        if self.numPlayers() >= 1:
            self.gameStarted = True
            self.winner = None

    def gameStart(self):
        if self.numPlayers() >= MIN_PLAYERS:
            self.gameStarted = True
            self.winner = None
        else:
            self.gameStarted = False
            self.timer.cancel()
            self.timeout = TIMEOUT
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()

    def gameStop(self):
        self.timer.cancel()
        self.gameStarted = False
        self.ready = False
        for object in self.validPlayers():
            self.unregister(object)
            #self.register(object,isWinner=self.isWinner(object))


class EventListener(threading.Thread,Publisher,Subscriber):
    def __init__(self,channel):
        threading.Thread.__init__(self)
        Subscriber.__init__(self)
        Publisher.__init__(self)
        self.channel = channel
        pygame.init()


    def run(self):
        self.subscribe(self.channel)
        debug("Suscrito al canal: %s" % self.channel)
        self.listen()

    def publishObject(self,object):
        self.publish(self.channel,object)

    def event(self,event):
        pygame.event.post(pygame.event.Event(pygame.USEREVENT,event.msg))
        #debug("Lista de eventos:")
        #debug(pygame.event.get(pygame.USEREVENT))

    def stop(self):
        try:
            self.unsubscribe(self.channel)
        except:
            pass
        else:
            debug("Unsuscrito del canal: %s" % self.channel)
        self.abortListen = 1
        debug("Eventer detenido")


class netFrame(threading.Thread):

    def __init__(self, auto = True):
        threading.Thread.__init__(self)
        self._abort_flag = False
        self.daemon = None
        self.ns = None
        self.namingchildpid = None
        self.eventchildpid = None
        self.nsdaemon = Pyro.naming.NameServerStarter()
        self.evdaemon = EventServiceStarter()
        self.status = None
        self.auto = auto
        self.game = None
        self.tries = 3
        self.serverip = '0.0.0.0'
        self.rol = None

        # Event server preffix
        self.channel = 'FREECLIMBER'
        self.eventer = None
        signal.signal(signal.SIGTERM, self.stop)


    # Checking NameServer existence
    def existsNameServer(self):

        for contador in range(1,self.tries):
            self.status = "Buscando servidor... (Intento %d)" % contador
            debug(self.status)
            try:
                Pyro.naming.NameServerLocator().getNS()
            except (NamingError,PyroError):
                exists = False
            else:
                return True
            if self._abort_flag:
                break
            sleep(1.0)
        return exists

    def run(self):

        #Checking existing name server
        existsns = self.existsNameServer()
        if not existsns and not self._abort_flag and self.auto:

            debug("No se han encontrado servidores en la red")
            self.status = "No se han encontrado servidores en la red\nIniciando el servidor propio..."

            self.namingchildpid = os.fork()

            if (self.namingchildpid == 0):

                debug("Iniciando el servidor de nombres propio... (pid %s)" % os.getpid())
                self.rol = "NameServer"
                #print "child process"
                self.nsdaemon.start()
            else:

                self.eventchildpid = os.fork()
                if (self.eventchildpid == 0):

                    sleep(3.5)
                    debug("Iniciando el servidor de eventos propio... (pid %s)" % os.getpid())
                    self.rol = "EventServer"
                    self.evdaemon.start()

                else:
                    sleep(5)

                    self.daemon = Pyro.core.Daemon()

                    self.ns = Pyro.naming.NameServerLocator().getNS()

                    # daemon and nsdaemon connecting...
                    self.daemon.useNameServer(self.ns)

                    try:
                        self.ns.unregister('netGame')
                    except NamingError:
                        pass

                    # netGame object registering...
                    self.status = "Registrando objeto compartido..."
                    debug(self.status)
                    self.daemon.connect(netGame(),'netGame')

                    # EVENTS
                    self.eventer = EventListener(self.channel)
                    self.eventer.start()



                    # daemon loop...
                    debug("Demonio iniciado")
                    self.status = "Servidor iniciado. Esperando jugadores..."
                    self.rol = "DaemonServer"
                    self.daemon.requestLoop(condition = lambda: not self._abort_flag)

        elif existsns and not self._abort_flag:

            debug("Servidor encontrado. Iniciando conexion...")
            self.status = "Servidor encontrado. Iniciando conexion..."
            for i in range(20):
                try:
                    ns = Pyro.naming.NameServerLocator().getNS()
                    #self.serverip = urlparse.urlparse(str(ns.URI)).netloc
                    #
                    self.serverip = str(str(ns.URI).split('/')[2].split(':')[0])
                    self.game = Pyro.core.getAttrProxyForURI(ns.resolve('netGame'))
                    sleep(0.1)
                    break
                except:
                    debug("Fallo al establecer la conexión")

            if self.game:
                self.status = "Conexion establecida"
                debug(self.status)

                # EVENTS

                self.eventer = EventListener(self.channel)
                self.eventer.start()

                self.rol = "Client"

                while not self._abort_flag:
                    #self.game = Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
                    sleep(0.1)

            self.status = "Conexion terminada"
            debug(self.status)
        else:
            self.status = "No se han encontrado servidores en la red\nPulse ESPACIO para iniciar el servidor propio"


    def get_game(self):
        try:
            return Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
        except: pass

    def restart(self):
        game =  self.get_game()
        if game and not game.gameStarted:
            debug("Reiniciando juego en red")
            game.gameStop()
            self.eventer.publishObject({'id':"server",'msg':'restart',})

    def stop(self,  signum = 15, frame = None):
        if self.rol == "Client":
            try:
                self.eventer.stop()
            except:
                formatExceptionInfo
            self._abort_flag = True
            self.game = None
            debug("Desconectado del servidor")
        elif self.rol == "NameServer":
            debug("Deteniendo servidor de nombres...")
            #self.nsdaemon.shutdown()
            raise KeyboardInterrupt
        elif self.rol == "EventServer":
            debug("Deteniendo servidor de eventos...")
            #self.evdaemon.shutdown()
            raise KeyboardInterrupt
        elif self.rol == "DaemonServer":
            debug("Deteniendo Servidor...")
            debug("Avisando a los conectados")
            self.eventer.publishObject({'id':"server",'msg':'stop',})
            sleep(0.25)
            self.eventer.stop()
            for pid in (self.eventchildpid, self.namingchildpid):
                debug("Deteniendo el proceso %d..." % pid)
                try:
                    if signum == 9:
                        s = signal.SIGKILL
                    else:
                        s = signal.SIGTERM
                    os.kill(pid,s)
                    os.waitpid(pid, 0)
                    sleep(0.5)
                except:
                    debug("No se pudo matar el proceso %d..." % pid)
            self.game = None
            self._abort_flag = True
            if self.eventchildpid and self.namingchildpid:
                debug("Servidor detenido correctamente")
        self.status = "Juego en red parado"


def main(console = False):
    options = ('q','r')
    juegoenred = netFrame()
    #pygame.init()
    juegoenred.start()
    signal.signal(signal.SIGTERM, juegoenred.stop)
    c = ''
    try:
        while not c == 'q':
            if juegoenred.status.startswith("Servidor iniciado") and console:
                c = raw_input("Press 'q' to Quit or 'r' to Restart:")
                if c in options:
                    if c == 'r':
                        juegoenred.restart()
                    elif c == 'q':
                        juegoenred.restart()
                        juegoenred.stop()
            elif juegoenred.status.startswith("Conexion establecida"):
                juegoenred.stop()
                c = 'q'
            elif juegoenred.status == "Juego en red parado":
                c = 'q'
            sleep(1)
    except KeyboardInterrupt:
        juegoenred.stop(9)
    return 1




if __name__ == '__main__':
    main(console = "--control" in sys.argv)


