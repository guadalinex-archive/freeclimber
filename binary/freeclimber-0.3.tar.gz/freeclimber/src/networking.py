#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from config import *
import netFrame
import time
from actors import Status

from pygext.gl.all import *
from pygame.locals import *
import Pyro

SELECTED_RESOLUTION = get_game_resolution()

ENDMUSICEVENT = pygame.USEREVENT + 2

class Networking(Scene):

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene
        self.aborted = False
        director.server = None
        self.next_update = director.ticker.now

    def enter(self):
        if VOLUME:
            try:
                pygame.mixer.music.stop()
                pygame.mixer.music.set_volume(VOLUME*0.01)
                pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'networking0.ogg'))
                pygame.mixer.music.set_endevent(ENDMUSICEVENT)
                self.event_handler[ENDMUSICEVENT] = {"":getattr(self, "handle_endmusicevent")}
                pygame.mixer.music.play()
            except:
                formatExceptionInfo()

        self.new_static("bg")
        self.new_layer("points")
        self.new_stabile("info")
        self.new_layer("actors")

        screen.clear_color = (0,0,0)

        ## Load the background.
        e = Entity(os.path.join(LINUX_GAME_PATH, MENU_PATH, 'option-bg.png'), hotspot=(0,0))
        e.set(centerx=SELECTED_RESOLUTION[0]/2,centery=SELECTED_RESOLUTION[1]/2, scale=SELECTED_RESOLUTION[1]/float(e.height)).place("bg")

        self.font = font = GLFont(("GPUTEKSR.TTF", SELECTED_RESOLUTION[0]/25))
        self.mensaje = TextEntity(self.font, "Modo Multijugador\nPresione ESPACIO para buscar servidores")
        self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)

        self.ring = Entity(os.path.join(LINUX_GAME_PATH, 'images', "common","ring.png"))
        self.ring.set(scale = SELECTED_RESOLUTION[0]/float(5*self.ring.width), centerx = SELECTED_RESOLUTION[0]/10, centery = SELECTED_RESOLUTION[0]/10).place("points")
        self.ring.do(RotateDelta(360,2.0,RepeatMode))

        self.mensaje.place("info")

        if not self.aborted:
            try:
                director.netFrame = netFrame.netFrame(auto = False)
                director.netFrame.start()
            except Exception, inst:
                debug("Error %s al conectar: %s" % (type(inst), inst))
                formatExceptionInfo(inst)
                director.netFrame.status = inst

        if director.wiimote:
            director.wiimote.draw_hands()

        self.registrado = False
        self.ready = False
        self.jugador = None
        self.minis = {}
        self.y = SELECTED_RESOLUTION[1]*3/5


    def set_next_scene(self, new_scene):
        self.next_scene = new_scene

    def set_previous_scene(self, scene):
        self.previous_scene = scene

    def realtick(self):
        if director.netFrame.game and director.ticker.now >= self.next_update:
            self.next_update = director.ticker.now + 500
            juego = director.netFrame.game
            if juego:
                try:
                    jugadores = juego.validPlayers()
                    self.draw_minis(juego, jugadores)
                    self.check_status(juego)
                    if juego.gameStarted and self.ready:
                        self.load_game()
                except Pyro.errors.ConnectionClosedError:
                    director.netFrame.status = "Conexion perdida"
                except Exception, inst:
                    formatExceptionInfo(inst)
        elif director.netFrame.status and not director.netFrame.game:
            self.mensaje.set_text(director.netFrame.status)
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/2)

        if director.netFrame.ns:
            director.server = director.netFrame
            debug("Conectando como cliente")
            director.netFrame = netFrame.netFrame()
            director.netFrame.start()

    def handle_userevent(self, ev):
        if ev.msg == "restart" and ev.id == "server":
            self.registrado = False
            for m in self.minis.values():
                m.erase()
            self.minis = {}
        elif ev.msg == "stop" and ev.id == "server":
            self.registrado = False
            director.netFrame.game = None
            director.netFrame.status = "Conexion perdida con el servidor\nPulse ESPACIO para conectar de nuevo"
            for m in self.minis.values():
                m.erase()
            self.minis = {}

    def handle_endmusicevent(self, ev):
        if VOLUME:
            try:
                if not pygame.mixer.music.get_busy():
                    pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'networking1.ogg'))
                    pygame.mixer.music.play()
            except:
                formatExceptionInfo()

    def draw_minis(self, juego, jugadores):
        if len(jugadores) < len(self.minis):
            i = 0
            for color in self.minis.keys():
                encontrado = False
                for p in jugadores:
                    if color == p.color:
                        encontrado = True
                        self.minis[color].moveTo(self.dx*(1+i%4), self.y+(i/4)*SELECTED_RESOLUTION[1]/4, secs=0.5)
                        i += 1
                        break
                if not encontrado:
                    self.minis[color].erase()
                    del self.minis[color]
        if len(jugadores) > 4:
            self.y += SELECTED_RESOLUTION[1]/4
        for p in jugadores:
            #s += "Jugador '%s' (%s) from %s\n" % (p.color, p.name, p.ip)
            if not p.color in self.minis:
                if juego.max_players > 4:
                    self.dx = SELECTED_RESOLUTION[0]/(juego.max_players/2+1)
                else:
                    self.dx = SELECTED_RESOLUTION[0]/(juego.max_players+1)
                mini = Status(x = self.dx*(1+len(self.minis)%4), y = self.y, color_player = p.color, width = min(SELECTED_RESOLUTION[0]/(MAX_PLAYERS+1),SELECTED_RESOLUTION[0]/9), type = 'static')
                self.minis[p.color] = mini
                mini.abort_actions(Repeat)
                mini.do(Show())
                if self.jugador and self.jugador.color == p.color:
                    mini.escalar(escala=mini.scale*1.25)


    def check_status(self, juego):
        s = ''
        if not self.registrado:
            self.jugador = netFrame.netPlayer()
            r = juego.register(self.jugador)
            if r == 'OK':
                self.registrado = True
                self.ready = True
                self.jugador = director.netFrame.game.get_player_by_id(self.jugador.id)
            else:
                self.registrado = True
                self.ready = False
        elif not self.ready:
            self.mensaje.set_text("Conectado a %s\n%d/%d Jugadores registrados\nEsperando su turno...\n" % (director.netFrame.serverip,juego.numPlayers(), juego.max_players))
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/3)
            self.ready = juego.getPlayer(self.jugador)
        else:
            self.mensaje.set_text("Conectado a %s\n%d/%d Jugadores registrados\nEl juego empezara en %ds.\n%s" % (director.netFrame.serverip,juego.numPlayers(), juego.max_players, juego.timeout, s))
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/3)

    def load_game(self):
        if self.next_scene:
            self.next_scene.color_player = self.jugador.color
            self.next_scene.set_jugador(self.jugador)
            for e in self.get_layer('actors'): e.do(AlphaFade(0,1))
            for e in self.get_layer('points'): e.do(AlphaFade(0,1))
            for e in self.get_layer('info'): e.do(AlphaFade(0,1))
            self.ring.do(Delay(1.25)+CallFunc(director.set_scene, self.next_scene))

    def abort_networking(self):
        try:
            juego = director.netFrame.game
            if self.jugador:
                juego.unregister(self.jugador)
        except:
            debug("Fallo al unregistrar el jugador '%s' " % self.jugador.id)
        if director.netFrame:
            try:
                director.netFrame.stop()
                director.netFrame.join()
            except:
                director.netFrame._abort_flag = True
                debug("Fallo al detener el netFrame")

        if director.server:
            #director.server.restart()
            director.server.stop(signum = 9)
            director.server.join()
        if self.previous_scene:
            director.set_scene(self.previous_scene)
        else:
            director.quit()


    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            self.abort_networking()
        elif ev.key == K_f:
            if director.server and director.netFrame.game:
                debug("Forzando inicio del juego en red")
                director.netFrame.game.forceGameStart()
        elif ev.key == K_SPACE and director.netFrame.status.startswith("Conexion perdida") or director.netFrame.status.startswith("No se han encontrado servidores"):
            self.aborted = False
            try:
                if director.netFrame.status.startswith("No se han encontrado servidores"):
                    director.netFrame = netFrame.netFrame()
                    director.netFrame.tries = 2
                    director.netFrame.start()
                else:
                    director.netFrame = netFrame.netFrame(auto = False)
                    director.netFrame.start()
            except Exception, inst:
                debug("Error %s al conectar: %s" % (type(inst), inst))
                formatExceptionInfo(inst)
                director.netFrame.status = inst

    def handle_joybuttondown(self, ev):
        if self.is_paused():
            return 0
        if ev.button == 3:
            self.demo_mode = False
            print "Exit joybutton"
            self.exit_game()

if __name__ == "__main__":
    screen.init(SELECTED_RESOLUTION, title="Network Test")
    director.wiimote = None
    director.run(Networking)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs
