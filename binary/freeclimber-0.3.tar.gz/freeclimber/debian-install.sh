#!/bin/bash

USER=`whoami`
RUTA="/usr/local/games/"



if [ "$USER" != "root" ]; then
	zenity --warning --text="Son necesarios permisos de administración.\nPor favor, llame a este script con sudo."
	exit 0
fi

#SEGUIR=`zenity --question --title="Programa de instalación de FreeClimber" --text="Bienvenid@ al programa de instalacion de Freeclimber. Procederemos
#~ a instalar las dependencias del programa, para, finalmente, instalar el programa.\n\
#~ Una vez finalice la instalación, podrá ejecutar el programa desde el menú Aplicaciones->Juegos"`

#~ echo $SEGUIR

#~ if [ "$SEGUIR" != 0 ]; then
	#~ exit 0
#~ fi


(
	echo "1"; sleep 1
	echo "# Actualizando repositorios..."
	aptitude update -yq &>/dev/null
	echo "10"; sleep 1
	echo "# Instalando dependencias... (python-xlib)"
	apt-get install -y python-xlib &>/dev/null
	echo "15"; sleep 1
	echo "# Instalando dependencias... (python-pygame)"
	apt-get install -y python-pygame &>/dev/null
	echo "20"; sleep 1
	echo "# Instalando dependencias... (pyro)"
	apt-get install -y pyro &>/dev/null
	echo "25"; sleep 1
	echo "# Instalando dependencias... (python-psyco)"
	apt-get install -y python-psyco &>/dev/null
	echo "30"; sleep 1
	echo "# Instalando dependencias... (python-numpy)"
	apt-get install -y python-numpy &>/dev/null
	echo "35"; sleep 1
	echo "# Instalando dependencias... (python-numeric)"
	apt-get install -y python-numeric &>/dev/null
	echo "40"; sleep 1
	echo "# Instalando dependencias... (python-gtk2)"
	apt-get install -y python-gtk2 &>/dev/null
	echo "45"; sleep 1
	echo "# Instalando dependencias... (python-stats)"
	apt-get install -y python-stats &>/dev/null
	echo "50"; sleep 1
	echo "# Instalando dependencias... (python-cwiid)"
	apt-get install -y python-cwiid &>/dev/null
	echo "55"; sleep 1
	echo "# Desinstalando versiones previas de python-opengl..."
	apt-get install -y libglut3 &>/dev/null
	apt-get remove -y python-opengl &>/dev/null
	echo "60"; sleep 1
	echo "# Instalando soporte opengl..."
	dpkg -i ./extra/python-opengl_2.0.1.09.dfsg.1-0.3_i386.deb &>/dev/null
	aptitude hold python-opengl &>/dev/null
	echo "70"; sleep 1
	echo "# Instalando librerías adiccionales... (pygext-0.9.5)"
	cd pygext-0.9.5 &>/dev/null
	python setup.py install &>/dev/null
	echo "90"; sleep 1
	echo "# Instalando juego..."
	cd ../.. &>/dev/null
	cp -r freeclimber /usr/local/games/ &>/dev/null
	chown -R root.games /usr/local/games/ &>/dev/null
	chmod 1755 -R /usr/local/games/ &>/dev/null
	cp ./freeclimber/freeclimber.desktop /usr/share/applications &> /dev/null
	cp ./freeclimber/freeclimber-config.desktop /usr/share/applications &> /dev/null
	cp ./freeclimber/freeclimber /usr/local/bin &> /dev/null
	cp ./freeclimber/freeclimber-config /usr/local/bin &> /dev/null
	cp ./freeclimber/freeclimber-server /usr/local/bin &> /dev/null
	chmod +x /usr/local/bin/freeclimber*
	echo "100"; sleep 1
	echo "# Instalación finalizada"
) |
zenity --progress \
	--title="Instalador FreeClimber" \
	--text="Comenzando instalación...                               " \
	--percentage=0

if [ "$?" = -1 ]; then
	zenity --error \
		--text="Error en la instalación."
fi
