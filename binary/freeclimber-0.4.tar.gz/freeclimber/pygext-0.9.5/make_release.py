import os

os.system("genapidoc.py")
os.system("gentut.py")
os.system("makebuilds.py")
os.system("zipdoc.py")

