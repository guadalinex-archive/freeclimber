from pygext.gl.all import *

class HelloWorld(Scene):
    def init(self):
        ## The GLFont object takes either a pygame Font
        ## object, or a (fontname, fontsize) tuple.
        self.font = GLFont(("arial", 20))
        
        ## All graphical entities are displayed on layers,
        ## so we need to create at least one.
        self.new_layer("text")
        
        text = TextEntity(self.font, "Hello World!", scale=2)
        text.centerx = 400
        text.centery = 300
        text.color = (0,255,0)
        
        ## Place the text entity on a layer
        text.place("text")

    ## We'll add a simple keydown event handler to the scene
    ## so that pressing any key will quit the program.        
    def handle_keydown(self, event):
        director.quit()

## Initialize pygext.gl using resolution 800 x 600
screen.init((800,600))

## Start the program
director.run(HelloWorld)
