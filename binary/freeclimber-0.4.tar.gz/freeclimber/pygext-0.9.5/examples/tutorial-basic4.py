
import sys, os
import pygame
from pygext.gl.all import *

class ImageScene(Scene):

    def enter(self):
        # Create three layers to control drawing order.
        # Since depth isn't explicitly defined, the layer that is
        # defined first will the drawn first (i.e. it will end up
        # behind the other layers)
        self.new_layer("layer1")
        self.new_layer("layer2")
        self.new_layer("layer3")

        # Create the first Entity using the file name
        e = Entity("gfx/building1.png")
        # place it on the first layer
        e.place("layer1").set(left=150, top=50)
        # and rotate 20 degrees clockwise (relative to the center of the bitmap)
        e.angle = 20
        # set color to red
        e.color = (255,0,0)

        # Alternative way is to create the Bitmap object manually.
        # The difference compared to the above is that the image
        # isn't cached for possible later use.
        bmp = Bitmap("gfx/building2.png")
        e = Entity(bmp)
        e.place("layer2").set(left=250, top=100)
        e.color = (0,255,0)

        # Finally, an Entity created from a pygame surface
        surface = pygame.image.load(os.path.join(sys.path[0],"gfx/building3.png"))
        e = Entity(surface)
        e.place("layer3").set(left=350, top=150)
        e.angle = -20
        e.color = (0,0,255)
        # set the foremost building to partly transparent
        e.alpha = 100


screen.init((800,600))
director.run(ImageScene)
        
