
import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()


from pygext.gl.all import *
from pygext.gl.particles import *
from pygext.lazy import Random

class TestEmitter(LineEmitter):
    delay = 0.1
    num_particles = 1
    life = 3
    fade_time = 1
    fade_in = 0.5
    scale = Random(0.3, 0.5)
    scale_delta = -0.01
    color = (0,200,255,185)
    velocity = 50

class TestEmitter2(LineEmitter):
    delay = 0.05
    num_particles = 1
    life = 2
    fade_time = 1
    fade_in = 0.5
    scale = Random(0.3, 0.5)
    scale_delta = -0.01
    color = (255,255,0,200)
    velocity = 150

    start_point = (-30,-30)
    end_point = (30,30)
    tangent = True

class TestSystem(BitmapParticleSystem):
    image = "gfx/ball.png"
    layer = "particles"
    mutators = [
        LinearForce(0,-50),
        ]    

class ParticleScene(Scene):
    def enter(self):
        self.new_layer("particles")

        system = TestSystem()

        node = Entity()
        node.set(realx=400, realy=500)

        system.new_emitter(TestEmitter, node)

        node = Entity()
        node.set(realx=100, realy=300)

        system.new_emitter(TestEmitter2, node)


    def handle_keydown(self, ev):
        director.quit()

screen.init((800,600))
director.run(ParticleScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
