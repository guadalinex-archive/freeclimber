from pygext.gl.all import *
from pygame.locals import *  # key constants

class HelloWorld(Scene):
    def init(self):
        self.font = GLFont(("arial", 20))      
        self.new_layer("text")

    def enter(self):
        ## create "Hello" and "World" into different entities
        text = TextEntity(self.font, "Hello", scale=2)
        text.set(centerx=300, centery=300).place("text")
        
        text2 = TextEntity(self.font, "World!", scale=2)
        text2.set(left=text.right+10, top=text.top).place("text")

        ## Move 50 points to the right in one second
        ## The PingPongMode causes the entity to move back and forth
        action = MoveDelta(50, 0, secs=1.0, mode=PingPongMode)
        text2.do(action)

        ## Continuously rotate 90 degrees per second
        action = Rotate(90)

        ## Move down 100 points per second for two seconds, then delete the entity
        action2 = Move(0, 100).limit(time=2) + Delete

        text.do(action)
        text.do(action2)
       
    def handle_keydown(self, event):
        director.quit()

screen.init((800,600))
director.run(HelloWorld)
