##
## A complete Asteroids clone
##
## requires pygext 0.9.1 or newer
##
## Thanks to Petteri Liimatainen for most of the graphics.
##

import pygame
from pygame.locals import *

## First we'll define some constants so we can
## easily alter any game parameters.
class Settings:
    acceleration = 20
    turn_rate = 250
    friction = 0.965

    num_asteroids = 3
    asteroid_speed = 100
    initial_size = 1.0

    bullet_speed = 350
    bullet_color = (255,255,150,200)

    key_left = K_LEFT
    key_right = K_RIGHT
    key_thrust = K_UP
    key_shoot = K_SPACE


## Import psyco if available
try:
    import psyco
except ImportError:
    pass
else:
    from psyco.classes import *
    psyco.full()

from pygext.gl.all import *
from pygext.math.vecalg import sincos
from pygext.lazy import Random # lazy Random function for particles
from math import sqrt

from random import random

## Define particle systems and emitters.
##
## A "system" of particles, is a particle group that shares
## the same image and layer.
##
## An "emitter" creates the particles and dictates most of their
## properties.

## First the particles emitted by the ship's engine.
## Since we won't use scaling or other transformations,
## we can choose the SimpleBitmapParticleSystem for efficiency.
class EngineParticles(SimpleBitmapParticleSystem):
    image = "gfx/alpha_sphere.png"
    layer = "particles"

## PointEmitter emits the particles from a single point.
## By using the lazy Random evaluator, we can set a random
## distribution for the particle attributes that is evaluated
## when the particle is created.
class EngineEmitter(PointEmitter):
    color = (255,Random(255),0,Random(100,200))
    life = 0.7  ## time-to-live in seconds
    num_particles = 3 ## number of particles per emission
    fade_time = 0.3  ## how many seconds to fade out the particle in the end
    fade_in = 0.1  ## how many seconds to fade in the particle at creation
    velocity = 50  ## velocity in pixels per second
    angle = 90  ## width of the emission arc in degrees
    direction = 180 ## direction of the particles
    align_to_node = True ## direction is relative to source node's angle

## BulletEmitter is used to emit particles when a bullet collides
## with an asteroid.
class BulletEmitter(PointEmitter):
    color = Settings.bullet_color
    delay = None ## delay between emissions, None means that we only emit once
    num_particles = 5
    life = 1
    fade_time = 0.5 
    velocity = 100
    angle = 360

## Particle system for the ship's explosion. Since the particles
## are transformed, we can't use the SimpleBitmapParticleSystem.
class ExplosionParticles(BitmapParticleSystem):
    image = "gfx/particle.png"
    layer = "particles"

## Circle emitter creates the particles inside a specified
## circle.
class ExplosionEmitter(CircleEmitter):
    color = (255,Random(100,255),100)
    num_emits = 3 ## emit three waves of particles
    delay = 0.1 ## with a 0.1 second delay between emissions
    life = 2
    fade_time = 2
    num_particles = 50
    scale = Random(0.5,2) # scale by a random amount
    velocity = Random(50,150)
    rotation_delta = Random(300,500) # rotate by 300-500 degrees per second
    direction = 10 # alter the particle direction slightly clockwise
    angle = 0
    tangent = True # set the particle direction tangential to the circle's arc
    radius = 16 # radius of the emission circle

## Recycle the asteroid image for the dust particles.
## We will scale the image to a smaller size, so we'll use
## the regular BitmapParticleSystem again.
class DustParticles(BitmapParticleSystem):
    image = "gfx/asteroid.png"
    layer = "particles"

class DustEmitter(CircleEmitter):
    color = (255,255,255,Random(50,150))
    delay = None
    life = 2
    fade_time = 2
    num_particles = 200
    scale = Random(0.05,0.2)
    velocity = Random(50,150)
    rotation_delta = Random(300,500)
    angle = 360
    tangent = False
    radius = 50


## We'll subclass the Entity class for our Asteroids objects
class Asteroid(Entity):

    ## The 'image' class attribute is used a default image for Entities
    ## if none is given in the constructor.
    image = "gfx/asteroid.png"

    ## By defining a 'layers' class attribute, the Entity is automatically
    ## placed on a layer upon creation.
    layer = "asteroids"

    ## We'll define a custom init method. You pass paramters for the custom
    ## intializer via keyword arguments to the Entity constructor.
    def init(self, scale=Settings.initial_size):
        ## Attribute for keeping track wether this asteroid is
        ## already destroyed or not. Every Entity has a 'deleted'
        ## attribute that is set when the Entity is deleted from
        ## scene, but we don't want to use this, because asteroids
        ## stay visible for a short while after they have already
        ## been destroyed (they fade out).
        self.dead = False

        ## Set a random position from somewhere outside the screen.
        x = y = -80
        if random() > 0.5:
            x += random()*960
        else:
            y += random()*760
        self.set(x=x, y=y, scale=scale) # also set the drawing scale here

        ## Move the asteroid in a random direction
        d = random()*360
        vx,vy = sincos(d, Settings.asteroid_speed)
        print vx
        print vy
        ## Save a reference to the movement action so we can alter it
        ## later on.
        self.move = Move(vx,vy).do(self)

        ## Set the asteroid to rotate at a constant rate
        r = random()*80-40
        r /= self.scale
        self.do(Rotate(r))

        # Create a collision node for this asteroid.
        # 74 is the approximate radius of the biggest asteroid,
        # so we multiply by current scale. The first parameter
        # is the "type" or collision group of the Entity that is
        # used when defining collision rules.
        self.add_collnode("asteroid", 74*self.scale)

        # Endurance is the number of hits this asteroid can take before
        # being destroyed.
        self.endurance = self.scale * 8

        # Update the asteroid count to keep track of win condition.
        # The standard way to refer to the currently active scene
        # is using the global 'director' object.
        director.scene.num_asteroids += 1

    # Method that is called when a bullet hits the asteroid.
    def on_hit(self, damage=1):
        self.endurance -= damage
        if self.endurance <= 0:
            self.split()

    # Destroy the asteroid
    def split(self):
        # Set the dead flag, so we won't e.g. register collisions from
        # this asteroid anymore.
        self.dead = True

        # Emit dust particles. After creating the emitter, we
        # can adjust its attributes to make smaller asteroids
        # emit less dust.
        emitter = DustEmitter(director.scene.dust_particles, self)        
        emitter.radius *= self.scale
        emitter.num_particles *= self.scale * self.scale
        emitter.emit() # emit a single pulse of particles

        # If the asteroid is still large enough, we'll create two
        # smaller asteroids.
        if self.scale >= 0.3:
            
            # Random adjustment for the positions
            dx = random()*30*self.scale
            dy = random()*30*self.scale
            for i in range(2):
                # Reduce size by 40%
                a = Asteroid(scale = self.scale*0.6)                
                a.set(
                    x = self.x + dx,
                    y = self.y + dy,
                    alpha = 0
                )
                # Set alpha to 0 at first and fade the asteroids in to view
                # gradually.
                a.do(AlphaFade(255,secs=0.3))
                dx,dy = -dx,-dy

                # Transfer some of the velocity from parent asteroid
                # to the new ones.
                a.move.add_velocity(self.move.vx*0.5, self.move.vy*0.5)

                ## Prevent straight horizontal or vertical movement, because
                ## that might make the asteroid stay beyond screen limits
                ## forever.
                if abs(a.move.vx) < 20:
                    a.move.vx = 20
                if abs(a.move.vy) < 20:
                    a.move.vy = 20

        # Alpha fade the destroyed asteroid away in 0.3 seconds and delete
        # the Entity.
        self.do(AlphaFade(0,0.3) + Delete)

        # Update the number of asteroids
        director.scene.num_asteroids -= 1
        

## We'll inherit the Ship entity from EntityNode, because we want to
## attach other entities to it. EntityNodes have more features, but aren't
## quite as efficient as regular Entities.
class Ship(EntityNode):
    image = "gfx/asteroid_ship.png"
    layer = "actors"
    
    def init(self):
        ## Define a flag for the ships state just like for Asteroid objects.
        self.dead = False

        ## Create the ship to the middle of the screen.
        self.set(
            x = 400,
            y = 300,
            )

        ## Create actions that do nothing for now, but which
        ## can be manipulated later. We call the do-method of
        ## the created actions to get a copy of the action
        ## that is linked to this Entity.
        self.move = Move(0,0).do(self)
        self.turn = Rotate(0).do(self)

        ## Created two nodes that have no graphical presentation,
        ## but are used as anchor points for engine particles
        ## and bullets.
        self.rearnode = Entity().set(x=0,y=17).attach_to(self)
        self.frontnode = Entity().set(x=0,y=-16).attach_to(self)

        ## Instantiate a particle emitter for engine particles.
        ## We must give the particle system and an anchor node
        ## as parameters.
        self.engine = EngineEmitter(
            director.scene.engine_particles,
            self.rearnode
            )

        ## Add a collision node with a radius of 16 pixels
        self.add_collnode("ship", 16)

        ## Set a flag to control firing rate of the gun.
        self.gun_ready = True


    ## Method for firing the thruster in the ship.
    def thrust(self):
        ## Get x- and y- velocity components for current angle
        ## and acceleration using the handly utility function.
        ax,ay = sincos(self.angle, Settings.acceleration)

        ## Add the velocity to our Move action. Note that actions
        ## should only be altered during "realticks" to keep the
        ## animation smooth.
        self.move.add_velocity(ax,ay)

        ## This is a bit of a hack. Because the actual 'angle' attribute
        ## of the rear node does not change even though it rotates with
        ## the ship, we need to mirror the ship's direction to the rear
        ## node before emitting the particles.
        self.rearnode.angle = self.angle 
        self.engine.emit()

        
    ## Set current turning speed by altering the Rotate action we
    ## created in the init method.
    def set_turn(self, vel):
        self.turn.set_velocity(vel)

    ## Fire a bullet.
    def fire(self):
        if not self.gun_ready:
            return
        ## Since the bullets are automatically added to the layer, we
        ## don't have to keep a reference to the created Bullet entity.
        Bullet(ship=self)

        ## Limit firing rate by clearing the gun_ready flag and set up
        ## a timed event to re-activate the gun.
        self.gun_ready = False
        act = Delay(0.3) + SetAttr(gun_ready = True)
        self.do(act)

## Entity class for bullets        
class Bullet(Entity):
    image = "gfx/alpha_sphere.png"
    layer = "actors"
    
    def init(self, ship):
        ## Note that the bullet is fired from the frontnode anchor.
        ## The realx and realy give the Entity's "real" coordinates
        ## on the screen. Regular x and y would return the Entity's
        ## relative position to its parent (i.e. the ship).
        self.set(
            x = ship.frontnode.realx,
            y = ship.frontnode.realy,
            color = Settings.bullet_color,
            angle = ship.angle,
            scale = 2  # enlarge the image to double size
            )

        ## Calculate the bullet velocity components from
        ## the ships current angle.
        vx,vy = sincos(self.angle, Settings.bullet_speed)

        self.add_collnode("bullet", 8)

        ## Move the bullet for two seconds before deleting it
        self.do(Move(vx,vy).limit(time=2) + Delete)

        ## Start fading the bullet away after 1.5 seconds.
        self.do(Delay(1.5) + AlphaFade(0,secs=0.5))
        

class GameScene(Scene):

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions
    
    def enter(self):
        ## Create a static layer for the non-animated background.
        ## Entities on static layers can't be altered in any way,
        ## they are rendered more efficiently.
        self.new_static("bg")

        ## The actors layer contains the ship and bullets.
        self.new_layer("actors")

        ## Create a "stabile" layer for the Asteroids to prevent them
        ## from changing z-order while overlapping. Stabile layers
        ## retain the internal z-order of its Entities, which is not
        ## guaranteed on a regular layer. The trade-off is that adding
        ## and deleting Entities is a slower operation, so that's why
        ## we won't put the bullets and particles on this layer.
        self.new_stabile("asteroids")

        ## The particles get their own layer so that they are
        ## rendered on top of the other sprites (since we didn't give
        ## any depth parameters, the layers are drawn in the order they
        ## are defined).
        self.new_layer("particles")

        ## Layer for text messages
        self.new_layer("text")

        ## Create a font.
        self.font = GLFont(("arial", 36))

        ## Load the background. It is a single 800x600 bitmap.
        e = Entity("gfx/asteroid_bg.png", hotspot=(0,0))
        e.set(x=0,y=0).place("bg")

        ## Since the background image covers the whole screen, set
        ## the clear_color to None to save time in screen updates.
        screen.clear_color = None

        ## Create our particle systems.
        self.engine_particles = EngineParticles()
        self.explosion_particles = ExplosionParticles()
        self.dust_particles = DustParticles()

        ## Track the number of asteroids so we know when the game ends.
        self.num_asteroids = 0

        ## Create the ship and some large asteroids. We don't need
        ## a reference to the asteroid objects, since they are automatically
        ## added to their own layer.
        self.ship = Ship()
        for x in range(Settings.num_asteroids):
            Asteroid()

    ## Collision handler for ship and asteroids.
    ## Notice that we don't register the handle at any point.
    ## The Scene object registers it automagically based on the
    ## method name that begins with 'collision_'. Here we use the
    ## names of the collision groups given when creating the
    ## collision nodes.
    def collision_ship_asteroid(self, ship, asteroid):
        ## Ignore the collision if either participant is already "dead",
        ## otherwise the fading "ghost image" of a destroyed asteroid
        ## could destroy the ship.
        if asteroid.dead or ship.dead:
            return

        ## Create a new emitter and start the emissions. The 'start'
        ## method sends out several pulses (if defined in the emitter),
        ## compared to the 'emit' method that always sends just one.
        ExplosionEmitter(self.explosion_particles, ship).start()

        ## Set the dead flag on the ship and delete the Entity
        ship.dead = True
        ship.delete()

        ## For visual flavor's sake, destroy the asteroid too.
        asteroid.split()

        ## Create a "Game Over" text to the middle of the screen
        ## and gradually fade it in.
        text = TextEntity(self.font, "Game Over")
        text.set(
            centerx = 400,
            centery = 300,
            color = (255,0,0,0),
            )
        text.place("text").do(AlphaFade(255, secs=1.0))

        ## Exit the game in three seconds.
        act = Delay(3) + CallFunc(director.quit)
        act.do()


    ## Collision between an asteroid and a bullet
    def collision_asteroid_bullet(self, asteroid, bullet):
        ## Prevent collision to the "ghost image" of a destroyed
        ## asteroid.
        if asteroid.dead:
            return

        ## Emit particles and delete the bullet entity.
        BulletEmitter(self.engine_particles, bullet).emit()
        bullet.delete()

        ## Call our custom hit callback in the Asteroid object.
        asteroid.on_hit()

        if self.num_asteroids <= 0 and not self.ship.dead:
            text = TextEntity(self.font, "Level Completed!")
            text.set(
                centerx = 400,
                centery = 300,
                color = (0,255,0,0),
                )
            text.place("text").do(AlphaFade(255, secs=1.0))

            ## Exit the game in three seconds.
            act = Delay(3) + CallFunc(director.quit)
            act.do()
            

    ## This callback is called by the director on every "realtick"
    ## aka. "engine tick". While frames are drawn as fast as possible,
    ## engine ticks happen at a constant time of 40 times per second.
    def realtick(self):
        self.handle_input()

        ## Slow the ship down
        f = Settings.friction
        self.ship.move.mul_velocity(f, f)

        ## Check if any objects needs to wrap around the screen
        self.check_bounds()


    ## Handle key input
    def handle_input(self):
        if self.ship.dead:
            return
        s = Settings
        keys = pygame.key.get_pressed()
        rate = Settings.turn_rate
        if keys[s.key_thrust]:
            self.ship.thrust()
        if keys[s.key_shoot]:
            self.ship.fire()
        if keys[s.key_left]:
            self.ship.set_turn(-rate)
        elif keys[s.key_right]:
            self.ship.set_turn(rate)
        else:
            self.ship.set_turn(0)

    ## Utility function for looping through both
    ## layers.
    def iterate_entities(self):
        for e in self.get_layer("actors"):
            yield e
        for e in self.get_layer("asteroids"):
            yield e

    def check_bounds(self):
        for e in self.iterate_entities():
            if e.x < -80:
                e.x += 960
            elif e.x > 880:
                e.x -= 960
            if e.y < -80:
                e.y += 760
            elif e.y > 680:
                e.y -= 760

    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            director.quit()

screen.init((800,600), title="Pygext Asteroids")
director.run(GameScene)
