"""OpenGL graphics and scene rendering
"""

from pygext.gl.display import screen
