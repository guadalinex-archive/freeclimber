##
## pyVectorGFX - 2D Vector Graphics Engine for PyGame
##
## author: Sami Hangaslammi
## email:  shang@iki.fi
##
## required libraries:
## * PyGame
## * OpenGL
## * Numeric
## * Polygon
##

  

