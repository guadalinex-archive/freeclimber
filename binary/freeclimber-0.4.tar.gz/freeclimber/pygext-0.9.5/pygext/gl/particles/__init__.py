"""Particle Effects.

Note: The current implementation is pure Python. After the particle API
has stabilised, it is my intention to rewrite the particle engine in C or
Pyrex to allow for more particles.
"""

from pygext.gl.particles.python_impl import *
