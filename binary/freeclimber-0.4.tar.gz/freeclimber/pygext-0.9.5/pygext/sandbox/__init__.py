"""Sandboxing Utilities

This package contains tools for running "untrusted" code such as user
plugins etc.
"""
