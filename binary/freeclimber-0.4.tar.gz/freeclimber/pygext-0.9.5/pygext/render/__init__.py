"""Additions to pygame.draw

Utility functions for generating different kind of surfaces
"""

from pygext.render.rects import *
from pygext.render.halo import *
from pygext.render.stencils import *
