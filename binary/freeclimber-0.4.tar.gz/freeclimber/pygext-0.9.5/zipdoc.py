
import zipfile, os
from os.path import join
from pygext import __version__ as version

def makezip(dirname):
    zipname = "dist/pygext-%s-%s.zip" % (version, dirname)
    zf = zipfile.ZipFile(zipname, "w")
    for base,dirs,files in os.walk(dirname):
        dirs.remove(".svn")
        for fn in files:
            if fn.endswith(".pyc") or fn.endswith(".svg"):
                continue
            path = os.path.join(base, fn)
            print "compressing", path
            zf.write(path, path, zipfile.ZIP_DEFLATED)
    zf.close()

if __name__ == '__main__':
    makezip("apidoc")
    makezip("tutorials")
    makezip("examples")
