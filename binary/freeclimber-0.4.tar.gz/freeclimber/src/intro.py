# -*- coding: utf-8 -*-
##
## requires pygext 0.9.1 or newer
##

import pygame
import os
from pygame.locals import *
from glob import glob
#from menu import MainMenu

## First we'll define some constants so we can
## easily alter any game parameters.
from config import *

## Import psyco if available
try:
    import psyco
except ImportError:
    pass
else:
    from psyco.classes import *
    psyco.full()

from pygext.gl.all import *
from random import random

SELECTED_RESOLUTION= get_game_resolution()


## We'll subclass the Entity class for our Logo objects

message = """Las secciones del juego mostradas \nen esta demo aun se encuentran en \ndesarrollo y como tal no representan \nel contenido y la calidad del producto final"""


class Logo(Entity):

    ## The 'image' class attribute is used a default image for Entities
    ## if none is given in the constructor.
    #image = os.path.join(LINUX_GAME_PATH, INTRO_PATH, "fyshon-logo.png")
    image = os.path.join(LINUX_GAME_PATH, INTRO_PATH, "fyshon-logo.png")

    ## By defining a 'layers' class attribute, the Entity is automatically
    ## placed on a layer upon creation.
    layer = "foreground"

    ## We'll define a custom init method. You pass paramters for the custom
    ## intializer via keyword arguments to the Entity constructor.
    def init(self, fadein=3.0, pause = 6.0, fadeout=2.0):
        scale = 1
        if self.width > min(SELECTED_RESOLUTION):
            scale = min(SELECTED_RESOLUTION)*0.75/(self.width)
        self.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, scale=scale) # also set the drawing scale here
        self.set_alpha(0)
        font = GLFont(("/usr/share/fonts/truetype/ttf-larabie-straight/primer.ttf", SELECTED_RESOLUTION[0]/16),(255,255,255,0))
        self.m = TextEntity(font, message)
        logo = Entity(os.path.join(LINUX_GAME_PATH, INTRO_PATH, "junta.png"))
        logo.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, scale=scale).place(Logo.layer) # also set the drawing scale here
        self.place(Logo.layer)
        anim = glob(os.path.join(LINUX_GAME_PATH,INTRO_PATH,'intro*.png'))
        anim.sort()
        self.do(Delay(fadein)+Animate([resources.get_bitmap(e) for e in anim], 4.1))
        self.do(AlphaFade(255, secs=fadein) + Delay(pause) +AlphaFade(0, secs=fadeout) + CallFunc(self.show_message))
        logo.do(Delay(fadein+pause+fadeout-1.0) + AlphaFade(0, secs=1.0)+Delete())


    def show_message(self):
        global message
        self.m.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, alpha=0).place(Logo.layer)
        self.m.do(AlphaFade(255,1.0)+Delay(5.0)+AlphaFade(0,1.0))

    def isfinished(self):
        return len(self.current_actions) + len(self.m.current_actions) == 0

class Intro(Scene):

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene

    def enter(self):

        #pygame.event.set_grab(True)
        ## Create a static layer for the non-animated background.
        ## Entities on static layers can't be altered in any way,
        ## they are rendered more efficiently.
        self.new_static("bg")

        ## The actors layer contains the ship and bullets.
        self.new_layer("foreground")

        ## Since the background image covers the whole screen, set
        ## the clear_color to None to save time in screen updates.
        screen.clear_color = (255,255,255,255)

        if VOLUME:
            try:
                pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'menuintro.ogg'))
                pygame.mixer.music.play(-1)
                pygame.mixer.music.set_volume(VOLUME*0.01)
            except:
                formatExceptionInfo()

        self.logo = Logo()
        init_gamepad()

    def set_next_scene(self, new_scene):
        self.next_scene = new_scene



    ## This callback is called by the director on every "realtick"
    ## aka. "engine tick". While frames are drawn as fast as possible,
    ## engine ticks happen at a constant time of 40 times per second.
    def realtick(self):
        if self.logo.isfinished():
            self.end()

    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            director.quit()
        elif ev.key == K_SPACE:
            self.end()

    def handle_joybuttondown(self, ev):
        self.end()

    def end(self):
        if self.next_scene:
            director.set_scene(self.next_scene)
        else:
            director.quit()

def init_gamepad(dev = 0):
    try:
        j = pygame.joystick.Joystick(dev)
    except:
        return 0
    else:
        j.init()

if __name__ == "__main__":
    screen.init(SELECTED_RESOLUTION, title="Intro Game")
    #director.ticker = Ticker(FPS)
    director.run(Intro)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs
