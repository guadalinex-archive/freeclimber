#!/usr/bin/python
# -*- coding: utf-8 -*-
##
## requires pygext 0.9.1 or newer
##

from pygame.locals import *
from pygext.gl.all import *
from config import *
from weather import *
from building import *
from actors import *
import threading
import Pyro

## Import psyco if available
try:
    import psyco
except ImportError:
    pass
else:
    from psyco.classes import *
    psyco.full()

SELECTED_RESOLUTION = get_game_resolution()

ENDMUSICEVENT = USEREVENT + 2

class Game(Scene):
    init_gamepad()
    nfloors = 25
    if ASPECT == '4:3' or ASPECT == "9:6" or ASPECT == "10:16":
        columns = 8
    else:
        columns = 10

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene
        self.demo_mode = False
        self.paused = False
        self.game_finished = False
        self.color_player = None
        self.netpositions = {}
        self.secs = []
        self.next_update = 0
        self.jugadores = []


    def enter(self, theme = 'default'):
        self.i = 0
        self.game_finished = False

        debug("Cargando juego...")

        self.new_static("bg")

        ## The actors layer contains the ship and bullets.
        self.new_layer("city")
        self.new_layer("weather_b")
        self.new_layer("particles")
        self.new_layer("dummy")
        self.new_layer("room")
        self.new_layer("glass")
        self.new_stabile("building")
        self.new_stabile("actors")

        self.new_layer("weather_f")
        self.new_stabile("info")
        self.new_layer("points")
        self.new_stabile("pausa")

        ## Load the background.
        e = Entity(os.path.join(LINUX_GAME_PATH, 'images','stages', theme,  ASPECT, 'tile.jpg'), hotspot=(0,0))
        e.set(x=0,y=0,scale=SELECTED_RESOLUTION[0]/float(e.width)).place("bg")

        debug("Capas creadas")

        if VOLUME:
            try:
                pygame.mixer.music.stop()
                pygame.mixer.music.set_volume(VOLUME*0.008)
                pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'juego0.ogg'))
                pygame.mixer.music.play()
                pygame.mixer.music.set_endevent(ENDMUSICEVENT)
                self.event_handler[ENDMUSICEVENT] = {"":getattr(self, "handle_endmusicevent")}
            except:
                formatExceptionInfo()

        debug("Musica cargada")

        screen.clear_color = None

        self.system = TestSystem()

        for x in range(6):
            Cloud(theme = theme)
            Cloud(capa = "weather_f", theme = theme)

        columns = director.netFrame and 8 or Game.columns
        levels = director.netFrame and int(director.netFrame.game.levels) or int(LEVELS)
        self.escenario = Stage((levels, columns), theme)

        debug("Escenario creado")

        self.player = Climber(x = SELECTED_RESOLUTION[0]/2, y = SELECTED_RESOLUTION[1]/2, width = self.escenario.width_unit, height = self.escenario.height_unit, color_player = self.color_player)
        debug("Jugador creado")
        self.set_player()



        self.pausedbg = Entity(os.path.join(LINUX_GAME_PATH, 'images','common', 'paused.png'), hotspot=(0,0))
        self.pausedbg.set(x=0,y=0,scale=max(SELECTED_RESOLUTION), alpha=165).place('pausa')
        self.pausedbg.do(Hide())
        self.pausedmsg = TextEntity(GLFont(("/usr/share/fonts/truetype/ttf-larabie-deco/qswitcha.ttf", SELECTED_RESOLUTION[0]/10),(255,255,255)), "PAUSA")
        self.pausedmsg.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2).place("pausa")
        self.pausedmsg.do(Hide())

        debug("Pausa preparada")

        if CONTROLLER == "IR controller":
            if not director.wiimote:
                try:
                    from wiimote import IRreceptor
                    director.wiimote = IRreceptor()
                except:
                    pass
            else:
                director.wiimote.draw_hands()
                director.wiimote.rpt_mode=9
        elif CONTROLLER.startswith("gamepad"):
            init_gamepad(int(CONTROLLER[-1]))
            director.wiimote = None
        else:
            director.wiimote = None

        debug("Controles configurados")

        if self.demo_mode:
            now = pygame.time.get_ticks()
            self.prev_movement = now
            self.next_movement = now
            debug("Demo preparada")

        self.enter_netGame()

        self.countdown(True)

    def enter_netGame(self):
        pass

    def countdown(self, start = False):
        center = (SELECTED_RESOLUTION[0]/2,SELECTED_RESOLUTION[1]/2)
        path = os.path.join(LINUX_GAME_PATH, 'images','common')
        if start:
            self.secs = [Entity(os.path.join(path,str(s)+'.png')) for s in range(4)]
            for e in self.secs:
                e.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, scale=float(SELECTED_RESOLUTION[0])/e.width).place("info")
                e.do(Hide())
        if len(self.secs) :
            self.secs.pop().do(Show()+Delay(0.1)+CenteredScale(0,0.9,center)+Delete())
            self.timer = threading.Timer(1.25, self.countdown)
            self.timer.start()

    def collision_player_bonus(self, player, item):
        if item.destroyed or self.is_paused():
            return 0
        item.destroyed = True
        item.do(MoveTo(player.scoreboard.centerx, player.scoreboard.centery, 1.0))
        item.do(Delay(0.9) + CallFunc(play_audio, 'puntos.ogg', 0.75) + CallFunc(self.increase_score))
        item.do(Delay(0.7) + CallFunc(item.destroy))

    def increase_score(self):
        self.player.score += 500
        self.player.update()

    def life1up(self):
        self.player.lifes += 1
        self.player.update()

    def subir(self):
        for e in self.netpositions.values():
            a = e.get_actions(MoveTo)
            if len(a)>0:
                e.do(MoveTo(a[0].targetx, a[0].targety-self.player.height, secs=0.5))
            else:
                e.do(MoveTo(e.x,e.y-self.player.height, secs= 0.50))
            #e.moveTo(e.x,e.y-self.player.height, secs= 0.50)
        self.escenario.bajar(-self.player.height, secs= 0.25)
        self.player.do(MoveDelta(0, -self.player.height, secs= 0.25))
        for e in self.get_layer("weather_f"):
            e.do(MoveDelta(0,-self.player.height, secs= 0.50))
        for e in self.get_layer("city"):
            e.do(MoveDelta(0,-self.player.height/16, secs= 0.50))

    def bajar(self):
        for e in self.netpositions.values():
            a = e.get_actions(MoveTo)
            if len(a)>0:
                e.do(MoveTo(a[0].targetx, a[0].targety+SELECTED_RESOLUTION[1]/2, secs=0.5))
            else:
                e.do(MoveTo(e.x,e.y+SELECTED_RESOLUTION[1]/2, secs= 0.50))
            #e.moveTo(e.x,e.y+SELECTED_RESOLUTION[1]/2, secs= 0.50)
        self.escenario.subir(SELECTED_RESOLUTION[1]/2, secs= 0.50)
        self.player.do(MoveDelta(0, SELECTED_RESOLUTION[1]/2, secs= 0.50))
        for e in self.get_layer("weather_f"):
            e.do(MoveDelta(0,SELECTED_RESOLUTION[1]/2, secs= 0.50))
        for e in self.get_layer("city"):
            e.do(MoveDelta(0,SELECTED_RESOLUTION[1]/20, secs= 0.50))

    def collision_player_life1up(self, player, item):
        debug("Colision: vida extra")
        if item.destroyed or self.is_paused():
            return 0
        play_audio('bien.ogg',0.75)
        item.destroyed = True
        item.do(MoveTo(player.lifeboard.right, player.lifeboard.centery, 1.0))
        item.do(Delay(0.9) + CallFunc(self.life1up))
        item.do(Delay(0.7) + CallFunc(item.destroy))

    def collision_player_enemy(self, player, item):
        debug("Colision: enemigo")
        if item.destroyed or self.is_paused():
            return 0
        if item.active:
            if not self.player.invencible():
                player.move('hit')
                item.destroy(distance(player,item))

    def collision_player_invincibility(self, player, item):
        debug("Colision: invencibilidad")
        if item.destroyed or self.is_paused():
            return 0
        item.destroy()
        player.score += 500
        player.update()
        Supertirititran(scale = player.scale)
        play_audio('supertirititran.ogg',0.75)
        #play_audio('lema.wav')
        player.do(Repeat(AlphaFade(200,0.5)+AlphaFade(128, 0.5), times=10)+AlphaFade(255,1.0))


    def collision_player_bomb(self, player, item):
        debug("Colision: Explosion")
        if item.destroyed or self.is_paused():
            return 0
        play_audio('bomb.ogg')
        for e in self.get_layer('actors'):
            if isinstance(e,Plant) and e.y <= player.y+min(SELECTED_RESOLUTION)/3 and e.y >= player.y-min(SELECTED_RESOLUTION)/3:
                d = distance(e,item)
                e.do(Delay(d*0.0025)+CallFunc(e.destroy,d+50))
        item.destroy()
        if director.netFrame:
            director.netFrame.eventer.publishObject({'id':self.player.id,'msg':'bomba',})
        pass

    def collision_ground_player(self, g, player):
        debug("Colision: suelo")
        player.abort_actions(MoveDelta)

    def collision_ground_enemy(self, g, item):
        debug("Colision: suelo")
        if item.destroyed or self.is_paused():
            return 0
        if item.active:
            item.destroy(distance(self.player,item))

    def is_paused(self):
        return  len(self.secs) or self.paused or self.game_finished

    def end_game(self):
        self.game_finished = True
        if self.end_netGame() and self.player.level >= self.escenario.dim[0]:
            self.player.move('winner')
            activate_fireworks(None,self.system,5)
            if VOLUME:
                try:
                    pygame.mixer.music.fadeout(1500)
                    pygame.mixer.music.set_endevent()
                except:
                    formatExceptionInfo()

            play_audio('victoria.ogg')

            Status(x = SELECTED_RESOLUTION[0]/2, y = SELECTED_RESOLUTION[1]/2, color_player = self.player.color_player, width = min(SELECTED_RESOLUTION)/3, type = 'static')
            self.cd = Entity(os.path.join(LINUX_GAME_PATH, 'images', 'common', 'winner.png'))
            self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]*3/4, scale = SELECTED_RESOLUTION[0]/(2*float(self.cd.width))).place("info")
            self.cd.do(ColorFade(colormap[self.player.color_player], 0.5))
            scale = self.cd.scale
            self.cd.do(Repeat(Delay(0.4)+CenteredScale(scale*1.1, 0.5, (SELECTED_RESOLUTION[0]/2, SELECTED_RESOLUTION[1]*3/4))+CenteredScale(scale, 0.1, (SELECTED_RESOLUTION[0]/2, SELECTED_RESOLUTION[1]*3/4)), times=10)+CallFunc(self.exit_game))
        else:
            if VOLUME:
                try:
                    pygame.mixer.music.fadeout(1500)
                    pygame.mixer.music.set_endevent()
                except:
                    formatExceptionInfo()

            play_audio('perdedor.ogg')
            self.cd = Entity(os.path.join(LINUX_GAME_PATH, 'images', 'common', 'gameover.png'))
            self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, scale = SELECTED_RESOLUTION[0]/(2*float(self.cd.width))).place("info")
            scale = self.cd.scale
            self.cd.do(Repeat(Delay(0.4)+CenteredScale(scale*1.1, 0.5, (SELECTED_RESOLUTION[0]/2, SELECTED_RESOLUTION[1]/2))+CenteredScale(scale, 0.1, (SELECTED_RESOLUTION[0]/2, SELECTED_RESOLUTION[1]/2)), times=10)+CallFunc(self.exit_game))


    def set_previous_scene(self, scene):
        self.previous_scene = scene

    def pause(self):
        if self.paused:
            self.pausedbg.do(Hide())
            self.pausedmsg.do(Hide())
            self.paused = False
            for e in self.interrupted:
                e.close_window(True)
                self.interrupted.remove(e)
        else:
            self.interrupted = []
            for e in self.get_layer("dummy"):
                if isinstance(e, MetaWindow):
                    if e.close_window(False):
                        self.interrupted.append(e)
            self.pausedbg.do(Show())
            self.pausedmsg.do(Show())
            self.paused = True
        try:
            pygame.mixer.music.fadeout(2000)
        except:
            formatExceptionInfo()


    def exit_game(self):
        debug("Saliendo del juego...")
        if self.demo_mode:
                director.set_scene(self)
        elif self.previous_scene:
            #if director.wiimote:
            #    self.previous_scene.wiimote = director.wiimote
            director.set_scene(self.previous_scene)
        else:
            director.quit()

    ## This callback is called by the director on every "realtick"
    ## aka. "engine tick". While frames are drawn as fast as possible,
    ## engine ticks happen at a constant time of FPS times per second.
    def realtick(self):
        debug("Realtick")
        self.netGame_events()

        if self.is_paused():
            debug("Juego pausado")
            return 1

        if self.demo_mode:
            debug("Modo demostración")
            self.ia()

        try:
            if director.wiimote and director.wiimote.initialized and not self.is_paused():
                director.wiimote.get_status()
        except Exception, inst:
            debug("Error %s en wiimote: %s" % (type(inst), inst))

        self.handle_wiimote_movements()

        if not self.player.ismoving(): # scroll
            debug("Comprobación de estados")

            if self.player.last_movement == "fall":
                #recolocar
                self.set_player()

            elif isinstance(self.escenario.escenario[-self.player.level][self.player.window], MetaWindow) and self.escenario.escenario[-self.player.level][self.player.window].is_closed() and not self.player.invencible():
                self.player.move("fall")
                play_audio('ups.ogg')

            elif self.player.y < SELECTED_RESOLUTION[1]/4 and self.player.manos == 2:
                self.bajar()

            elif self.player.y > SELECTED_RESOLUTION[1]*5/6 and self.player.manos == 2:
                self.subir()

            elif not self.game_finished and (self.player.level >= self.escenario.dim[0] and self.player.manos == 2) or self.player.lifes == 0: # game over
                self.end_game()

            else:
                self.escenario.check_windows(self.player.x)

        for e in self.get_layer("weather_b"):
            e.check_bounds(self.escenario.get_middle_level())
        for e in self.get_layer("weather_f"):
            e.check_bounds(self.escenario.get_middle_level())

    def set_player(self):
        punto_partida = self.escenario.escenario[-self.player.level][self.player.window]
        while not punto_partida.isescalable():
            if self.player.level > 2:
                self.player.level -= 1
            else:
                self.player.window = (self.player.window + 1) % self.escenario.dim[1]
            punto_partida = self.escenario.escenario[-self.player.level][self.player.window]
        self.player.set_in_window(punto_partida, self.player.level==2)

    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            self.demo_mode = False
            self.exit_game()
        elif ev.key == K_p:
            self.pause()
        if self.is_paused():
            return 0
        keys = pygame.key.get_pressed()
        if ((ev.key == K_s and keys[K_k]) or (ev.key == K_KP2)):
            self.player.move('down', stage = self.escenario.escenario)
        elif ((ev.key == K_i and keys[K_s]) or (ev.key == K_s and keys[K_i]) or (ev.key == K_KP9)):
            self.player.move('up_right', stage = self.escenario.escenario)
        elif ((ev.key == K_w and keys[K_k]) or (ev.key == K_k and keys[K_w]) or (ev.key == K_KP7)):
            self.player.move('up_left', stage = self.escenario.escenario)
        elif ((ev.key == K_d and keys[K_l]) or (ev.key == K_l and keys[K_d]) or (ev.key == K_KP6)):
            self.player.move('right', stage = self.escenario.escenario)
        elif ((ev.key == K_a and keys[K_j]) or (ev.key == K_j and keys[K_a]) or (ev.key == K_KP4)):
            self.player.move('left', stage = self.escenario.escenario)

    def handle_joybuttondown(self, ev):
        if ev.button == 9:
            self.pause()
        if self.is_paused():
            return 0
        if ev.button == 8:
            self.demo_mode = False
            print "Exit joybutton"
            self.exit_game()

    def handle_joyaxismotion(self, ev):
        if self.is_paused() or self.demo_mode:
            return 0
        if ev.axis == 3 and ev.value < -0.2:
            self.player.move('up_right', stage = self.escenario.escenario)
        elif ev.axis == 1 and ev.value < -0.9:
            self.player.move('up_left', stage = self.escenario.escenario)
        elif ev.axis == 0 and ev.value < -0.9:
            self.player.move('left', stage = self.escenario.escenario)
        elif ev.axis == 4 and ev.value > 0.8:
            self.player.move('right', stage = self.escenario.escenario)
        if (ev.axis == 3 and ev.value > 0.5) or (ev.axis == 1 and ev.value > 0.9):
            self.player.move('down', stage = self.escenario.escenario)


    def handle_wiimote_movements(self):
        if self.is_paused() or self.demo_mode:
            return 0
        if director.wiimote and director.wiimote.initialized:
            #director.wiimote.get_status()
            mov = director.wiimote.get_movement()

            if mov == "ll":
                self.player.move('left', stage = self.escenario.escenario)
            elif mov == "ul":
                self.player.move('up_left', stage = self.escenario.escenario)
            elif mov == "dl":
                self.player.move('down', stage = self.escenario.escenario)
            elif mov == "rr":
                self.player.move('right', stage = self.escenario.escenario)
            elif mov == "ur":
                self.player.move('up_right', stage = self.escenario.escenario)
            elif mov == "dr":
                self.player.move('down', stage = self.escenario.escenario)

    def handle_endmusicevent(self, ev):
        if VOLUME:
            try:
                if not pygame.mixer.music.get_busy():
                    if self.paused:
                        pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'pause.ogg'))
                    elif self.player.level >= self.escenario.dim[0]*3/4:
                        pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'juego3.ogg'))
                    elif self.player.level >= self.escenario.dim[0]/2:
                        pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'juego2.ogg'))
                    else:
                        pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'juego1.ogg'))
                    pygame.mixer.music.play()
            except:
                formatExceptionInfo()

    def ia(self):
        now = pygame.time.get_ticks()
        if now > self.next_movement:
            self.prev_movement = now
            self.next_movement += self.player.auto_move(self.escenario.escenario)
            debug("Next movement at: %.2f" % (self.next_movement/1000.0))

    def netGame_events(self):
        pass

    def refresh_positions(self, players=None):
        pass

    def end_netGame(self):
        return True

class NetGame(Game):

    columns = 8

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    #collengine = RadialCollisions

    def enter(self):
        debug("Cargando juego en red...")
        Game.enter(self)
        debug("Juego en red cargado")

    def set_netFrame(self, net):
        director.netFrame = net

    def set_jugador(self, player):
        self.jugador = player

    def enter_netGame(self):
        self.mensaje = TextEntity(GLFont(("/usr/share/fonts/truetype/ttf-larabie-straight/primerb.ttf", 48),(255,255,255)), "Juego on-line")
        self.mensaje.set(right=SELECTED_RESOLUTION[0], bottom=SELECTED_RESOLUTION[1]).place("info")
        self.mensaje.do(Blink(0.5, 0.25))
        debug("Generando el marcador...")
        self.clasification = Ranking()
        self.player.attach_netclimber(self.jugador)
        self.set_player()
        self.netpositions = {}
        juego = director.netFrame.game
        if juego:
            juego.updatePlayer(self.player.netclimber)
            self.jugadores = juego.validPlayers(order = True)
            self.clasification.update(self.jugadores)
            self.refresh_positions(self.jugadores)
        self.player.place("actors")

    def netGame_events(self):
        if director.ticker.now >= self.next_update:
            self.next_update = director.ticker.now + 750
            debug("Actualizando estado del juego en red")
            try:
                juego = director.netFrame.game
                if juego:
                    juego.updatePlayer(self.player.netclimber)
                    if not self.player.netclimber.ready and not len(self.secs):
                        self.player.netclimber.ready = True
                    if not self.is_paused():
                        self.jugadores = juego.validPlayers(order = True)
                        self.clasification.update(self.jugadores)
                        self.refresh_positions(self.jugadores)


            except Pyro.errors.ConnectionClosedError:
                director.netFrame.status = "Conexion perdida"
                self.previous_scene.aborted = True
                self.exit_game()
            except Exception, inst:
                debug("Error %s en juego en red: %s" % (type(inst), inst))
                formatExceptionInfo(inst)
                director.netFrame.game.unregister(self.jugador)
                director.netFrame.stop()
                director.netFrame.join()
                director.set_scene(self.previous_scene)

    def refresh_positions(self, players=None):
        if not players:
            players = self.jugadores
        else:
            #limpiar desconectados
            for nid in self.netpositions.keys():
                encontrado = False
                for p in players:
                    if p.id == nid:
                        encontrado = True
                        continue
                if not encontrado:
                    #self.netpositions[nid].erase()
                    self.netpositions[nid].do(Delete())
                    del self.netpositions[nid]
        for p in players:
            if p.id in self.netpositions.keys():
                window = self.escenario.escenario[-p.level][p.window]
                if isinstance(window,Escalable) and not len(window.current_actions):
                    #self.netpositions[p.id].moveTo(x = window.centerx, y = window.centery-window.height/3, secs = 0.35)
                    self.netpositions[p.id].do(MoveTo(window.x, window.y + window.height*3/5, secs=0.5))
            elif not p.id == self.player.id:
                window = self.escenario.escenario[-p.level][p.window]
                if isinstance(window,Escalable):
                    #self.netpositions[p.id] = Status(x = window.centerx, y = window.centery-window.height/2, width = window.width/3, color_player=p.color, type = 'ghost')
                    self.netpositions[p.id] = Climber(x = SELECTED_RESOLUTION[0]/2, y = SELECTED_RESOLUTION[1]/2, width = self.escenario.width_unit, height = self.escenario.height_unit, color_player = p.color, ghost = True)
                    self.netpositions[p.id].set_in_window(window)
                    self.netpositions[p.id].move()
                    #self.netpositions[p.id].do(AlphaFade(128,0.5)+ColorFade(colormap[p.color], 0.5))

    def is_paused(self):
        try:
            return Game.is_paused(self) or (director.netFrame.game and not director.netFrame.game.is_ready())
        except Pyro.errors.ConnectionClosedError:
            director.netFrame.status = "Conexion perdida"
            self.previous_scene.aborted = True
            self.exit_game()

    def end_netGame(self):
        self.game_finished = True
        if director.netFrame.game.winner and not director.netFrame.game.winner.id == self.player.netclimber.id:
            ganador = director.netFrame.game.getWinner()
            self.netpositions[ganador.id].move('winner')
            w = Status(x = SELECTED_RESOLUTION[0]*3/5, y = SELECTED_RESOLUTION[1]*2/3, color_player = ganador.color, width = min(SELECTED_RESOLUTION)/4, type = 'static')
            cd = Entity(os.path.join(LINUX_GAME_PATH, 'images', 'common', 'winner.png'))
            cd.set(right=w.left, centery=w.centery, scale = SELECTED_RESOLUTION[0]/(3*float(cd.width))).place("info")
            cd.do(ColorFade(colormap[ganador.color], 0.5))
            scale = cd.scale
        elif self.player.level >= self.escenario.dim[0]:
            director.netFrame.game.setWinner(self.player.netclimber)
            director.netFrame.eventer.publishObject({'id':self.player.id,'msg':'winner',})
            return True

    def collision_player_bonus(self, player, item):
        if not self.is_paused():
            Game.collision_player_bonus(self, player, item)

    def collision_player_life1up(self, player, item):
        if not self.is_paused():
            Game.collision_player_life1up(self, player, item)

    def collision_player_enemy(self, player, item):
        if not self.is_paused():
            Game.collision_player_enemy(self, player, item)

    def collision_player_invincibility(self, player, item):
        if not self.is_paused():
            Game.collision_player_invincibility(self, player, item)

    def collision_player_bomb(self, player, item):
        if not self.is_paused():
            Game.collision_player_bomb(self, player, item)

    def collision_ground_enemy(self, g, item):
        if not self.is_paused():
            Game.collision_ground_enemy(self, g, item)

    def handle_userevent(self, ev):
        if ev.id == self.player.id :
            return 0
        if ev.msg == "bomba":
            play_audio('bomb.ogg',0.5)
            onda = Entity(os.path.join(LINUX_GAME_PATH,'images','common', 'onda2.png'))
            onda.set(centerx=self.player.centerx, centery=self.player.centery, scale=self.player.width/float(onda.width)).place('building')
            onda.do(CenteredScale(1,1,(onda.centerx,onda.centery))+Delete())
            for a in self.get_layer('actors'):
                if isinstance(a, Plant) and a.y <= self.player.y+min(SELECTED_RESOLUTION)/3 and a.y >= self.player.y-min(SELECTED_RESOLUTION)/3:
                    d = distance(a,self.player)
                    a.do(Delay(d*0.0025)+CallFunc(a.activate))
        elif ev.msg == "winner":
            try:
                self.jugadores = director.netFrame.game.validPlayers(order = True)
                self.clasification.update(self.jugadores)
                self.refresh_positions(self.jugadores)
            except:
                formatExceptionInfo()
            self.end_game()
        elif ev.msg == "restart" and ev.id == "server":
            self.exit_game()

    def exit_game(self):
        debug("Saliendo del juego...")
        scene = self.previous_scene
        if not self.previous_scene.aborted:
            try:
                director.netFrame.game.unregister(self.player.netclimber)
                director.netFrame.stop()
                director.netFrame.join()
            except:
                debug("Fallo al salir del juego en red")
                formatExceptionInfo()
        if scene:
            director.set_scene(scene)
        else:
            director.quit()

def init_gamepad(dev = 0):
    try:
        j = pygame.joystick.Joystick(dev)
    except:
        return 0
    else:
        j.init()

def main():
    screen.init(SELECTED_RESOLUTION, fullscreen= FULLSCREEN, title="Free Climber")
    juego = Game()
    #director.visible_collision_nodes = True
    director.wiimote = None
    director.netFrame = None
    director.run(juego)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs

if __name__ == "__main__":
    main()
