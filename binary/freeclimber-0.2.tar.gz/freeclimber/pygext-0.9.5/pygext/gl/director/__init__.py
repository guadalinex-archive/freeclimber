"""Scene rendering and management.

This package implements a comprehensive event-driven scene
director that aims to abstract state transitions, input handling etc.

XXX TODO: There is a lot of general purpose code in this package that
          should be refactor out of the 'gl' package.
"""
