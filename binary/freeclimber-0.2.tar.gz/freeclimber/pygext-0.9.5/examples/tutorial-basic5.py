from pygext.gl.all import *

# define some action shortcuts
move_right = MoveDelta(200,0, secs=1)
move_down = MoveDelta(0,200, secs=1)
move_left = MoveDelta(-200,0, secs=1)
move_up = MoveDelta(0,-200, secs=1)

class MyScene(Scene):
    
    def enter(self):
        self.new_layer("entities")

        # create the "root" node that the other nodes will refer to
        # NOTE: you can only attach other entities to EntityNodes, not
        # regular Entity objects.
        root = EntityNode("gfx/invader1.png")
        root.place("entities").set(left=0, centery=300)
        root.do(Move(100,0))
        
        # create a child entity that is attached to the root entity
        child1 = Entity("gfx/invader1.png")
        child1.attach_to(root)
        # set the child's position relative to the root node
        child1.set(scale=0.5, centerx=-100, centery=-100)
        
        # create a path around the root node that is repeated indefinately
        path1 = move_right + move_down + move_left + move_up
        child1.do(Repeat(path1))
        
        child2 = Entity("gfx/invader1.png")
        child2.attach_to(root)
        child2.set(scale=0.5, centerx=100, centery=100)
        
        path2 = move_left + move_up + move_right + move_down
        child2.do(Repeat(path2))

    def handle_keydown(self, event):
        director.quit() # quit if any key is pressed
                
screen.init((800,600))
director.run(MyScene)
