
import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()


from pygext.gl.all import *
from pygext.gl.particles import *
from pygext.lazy import Random

class TestEmitter(RectEmitter):
    delay = 0.01
    num_particles = 2
    life = 1.5
    fade_time = 1
    fade_in = 0.5
    scale = Random(0.3, 0.5)
    scale_delta = -0.01
    color = (0,200,0,185)
    velocity = 150

    direction = 0
    angle = 50

class TestSystem(BitmapParticleSystem):
    image = "gfx/ball.png"
    layer = "particles"
    mutators = [
        LinearForce(0,100),
        ]    

class ParticleScene(Scene):
    def enter(self):
        self.new_layer("particles")

        system = TestSystem()

        node = Entity()
        node.set(realx=400, realy=300)

        system.new_emitter(TestEmitter, node)


    def handle_keydown(self, ev):
        director.quit()

screen.init((800,600))
director.run(ParticleScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
