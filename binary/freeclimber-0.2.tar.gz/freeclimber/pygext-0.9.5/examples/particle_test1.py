
import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()


from pygext.gl.all import *
from pygext.gl.particles import *
from pygext.lazy import Random

class TestEmitter(PointEmitter):
    delay = 0.01
    num_particles = 1
    life = 2
    fade_time = 1
    fade_in = 0.5
    scale = Random(1.0, 3.0)
    scale_delta = -0.5
    rotation = Random(360)
    rotation_delta = 100
    color = (195,Random(50),0,Random(150,200))
    velocity = 100
    angle = 35

class TestEmitter2(PointEmitter):
    delay = Random(0.1,0.3)
    num_particles = 1
    life = 1
    fade_time = 0.1
    fade_in = 0.1
    scale = Random(0.5, 1.5)
    scale_delta = -0.5
    rotation = Random(360)
    rotation_delta = 100
    color = (255,255,Random(255),Random(100,200))
    velocity = Random(150,250)
    angle = 55
    

class TestSystem(BitmapParticleSystem):
    image = ("gfx/particle.png")
    layer = "particles"
    mutators = [
        LinearForce(30,-40),
        ]    

class ParticleScene(Scene):
    def enter(self):
        self.new_layer("particles")

        system = TestSystem()

        node = Entity()
        node.set(realx=500, realy=500)

        system.new_emitter(TestEmitter, node)


        node = Entity()
        node.set(realx=300, realy=500)

        system.new_emitter(TestEmitter, node)
        system.new_emitter(TestEmitter2, node)



    def handle_keydown(self, ev):
        director.quit()

screen.init((800,600))
director.run(ParticleScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
