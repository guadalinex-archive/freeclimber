
import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()


from pygext.gl.all import *
from pygext.gl.particles import *
from pygext.lazy import Random

class TestEmitter(CircleEmitter):
    delay = 0.01
    num_particles = 1
    life = 1.5
    fade_time = 1
    fade_in = 0.1
    scale = Random(0.1, 0.2)
    scale_delta = 0.5
    color = (255,0,0,185)
    velocity = 100

    radius = 100
    tangent = True
    angle = 0
    direction = 0

class TestEmitter2(CircleEmitter):
    delay = 0.01
    num_particles = 1
    life = 1.5
    fade_time = 1
    fade_in = 0.1
    scale = Random(0.3, 0.5)
    scale_delta = -0.01
    color = (255,255,0,185)
    velocity = 100
    angle = 360

    tangent = False

class TestSystem(BitmapParticleSystem):
    image = "gfx/ball.png"
    layer = "particles"
    mutators = []    

class ParticleScene(Scene):
    def enter(self):
        self.new_layer("particles")

        system = TestSystem()

        node = Entity()
        node.set(realx=200, realy=300)

        system.new_emitter(TestEmitter, node)

        node = Entity()
        node.set(realx=600, realy=300)

        system.new_emitter(TestEmitter2, node)


    def handle_keydown(self, ev):
        director.quit()

screen.init((800,600))
director.run(ParticleScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
