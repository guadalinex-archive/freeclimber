#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from config import *
import netFrame
import time
from actors import Status

from pygext.gl.all import *
from pygame.locals import *
import Pyro

SELECTED_RESOLUTION = get_game_resolution()



class Networking(Scene):

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene
        self.wiimote = None
        self.aborted = False
        self.server = None
        self.next_update = director.ticker.now

    def enter(self):
        if VOLUME:
            try:
                pygame.mixer.music.stop()
                pygame.mixer.music.set_volume(VOLUME*0.01)
                pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'menuintro.ogg'))
                pygame.mixer.music.play(-1)
            except:
                formatExceptionInfo()

        self.new_static("bg")
        self.new_layer("points")
        self.new_stabile("info")
        self.new_layer("actors")

        screen.clear_color = (0,0,0)

        ## Load the background.
        e = Entity(os.path.join(LINUX_GAME_PATH, MENU_PATH, 'option-bg.png'), hotspot=(0,0))
        e.set(centerx=SELECTED_RESOLUTION[0]/2,centery=SELECTED_RESOLUTION[1]/2, scale=SELECTED_RESOLUTION[1]/float(e.height)).place("bg")

        self.font = font = GLFont(("GPUTEKSR.TTF", SELECTED_RESOLUTION[0]/25))
        self.mensaje = TextEntity(self.font, "Prueba de conexion en red")
        self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)

        self.ring = Entity(os.path.join(LINUX_GAME_PATH, 'images', "common","ring.png"))
        self.ring.set(scale = SELECTED_RESOLUTION[0]/float(5*self.ring.width), centerx = SELECTED_RESOLUTION[0]/10, centery = SELECTED_RESOLUTION[0]/10).place("points")
        self.ring.do(RotateDelta(360,2.0,RepeatMode))

        self.mensaje.place("info")

        if not self.aborted:
            try:
                self.net = netFrame.netFrame()
                self.net.start()
            except Exception, inst:
                debug("Error %s al conectar: %s" % (type(inst), inst))
                formatExceptionInfo(inst)
                self.net.status = inst

        self.registrado = False
        self.ready = False
        self.jugador = None
        self.minis = {}
        self.y = SELECTED_RESOLUTION[1]*3/5


    def set_next_scene(self, new_scene):
        self.next_scene = new_scene

    def set_previous_scene(self, scene):
        self.previous_scene = scene

    def realtick(self):
        if self.net.game and director.ticker.now >= self.next_update:
            self.next_update = director.ticker.now + 500
            juego = self.net.game
            if juego:
                try:
                    jugadores = juego.validPlayers()
                    self.draw_minis(juego, jugadores)
                    self.check_status(juego)
                    if juego.gameStarted and self.ready:
                        self.load_game()
                except Pyro.errors.ConnectionClosedError:
                    self.net.status = "Conexion perdida"
                except Exception, inst:
                    print type(inst)     # the exception instance
                    print inst.args      # arguments stored in .args
                    print inst           # __str__ allows args to printed directly
        elif self.net.status and not self.net.game:
            self.mensaje.set_text(self.net.status)
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/2)

        if self.net.ns:
            self.server = self.net
            debug("Conectando como cliente")
            self.net = netFrame.netFrame()
            self.net.start()

    def draw_minis(self, juego, jugadores):

        if len(juego.validPlayers()) > 4:
            self.y += SELECTED_RESOLUTION[1]/4
        for p in jugadores:
            #s += "Jugador '%s' (%s) from %s\n" % (p.color, p.name, p.ip)
            if not p.color in self.minis:
                if juego.max_players > 4:
                    self.dx = SELECTED_RESOLUTION[0]/(juego.max_players/2+1)
                else:
                    self.dx = SELECTED_RESOLUTION[0]/(juego.max_players+1)
                mini = Status(x = self.dx*(1+len(self.minis)%4), y = self.y, color_player = p.get_color(), width = min(SELECTED_RESOLUTION[0]/(MAX_PLAYERS*2+1),SELECTED_RESOLUTION[0]/9), type = 'static')
                self.minis[p.color] = mini
                mini.abort_actions(Repeat)
                mini.do(Show())
                if self.jugador and self.jugador.color == p.color:
                    mini.escalar(escala=mini.scale*1.25)
        if not len(jugadores) == len(self.minis):
            for color in self.minis.keys():
                encontrado = False
                for p in jugadores:
                    if color == p.color:
                        encontrado = True
                        break
                    if not encontrado:
                        self.minis[color].erase()
                        del self.minis[color]

    def check_status(self, juego):
        s = ''
        if not self.registrado:
            self.jugador = netFrame.netPlayer()
            r = juego.register(self.jugador)
            if r == 'OK':
                self.registrado = True
                self.ready = True
                self.jugador = self.net.game.get_player_by_id(self.jugador.id)
            else:
                self.registrado = True
                self.ready = False
        elif not self.ready:
            self.mensaje.set_text("Conectado a %s\n%d/%d Jugadores registrados\nEsperando su turno...\n" % (self.net.serverip,juego.numPlayers(), juego.max_players))
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/3)
            self.ready = juego.getPlayer(self.jugador)
        else:
            self.mensaje.set_text("Conectado a %s\n%d/%d Jugadores registrados\nEl juego empezara en %ds.\n%s" % (self.net.serverip,juego.numPlayers(), juego.max_players, juego.timeout, s))
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/3)

    def load_game(self):
        try:
            if self.next_scene:
                if self.wiimote:
                    self.next_scene.wiimote = self.wiimote
                self.next_scene.color_player = self.jugador.color
                self.next_scene.set_netFrame(self.net)
                if self.server:
                    self.next_scene.server = self.server
                self.next_scene.set_jugador(self.jugador)
                #director.set_scene(self.next_scene)
                director.run(self.next_scene)
        except Pyro.errors.ConnectionClosedError:
            self.net.status = "Conexion perdida"
            self.aborted = True
            director.set_scene(self)
        except Exception, inst:
            debug("Error %s en juego en red: %s" % (type(inst), inst))
            formatExceptionInfo(inst)
            #director.quit()
            self.net.game.unregister(self.jugador)
            self.net.stop()
            self.net.join()
            if self.wiimote:
                self.previous_scene.wiimote = self.wiimote
            director.set_scene(self.previous_scene)

    def abort_networking(self):
        try:
            if self.previous_scene:
                if self.wiimote:
                    self.previous_scene.wiimote = self.wiimote
                director.set_scene(self.previous_scene)
            else:
                self.net.stop()
                self.net.join()
                director.quit()
        except:
            director.quit()


    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            try:
                juego = self.net.game
                #juego = self.net.get_game()
                if self.jugador:
                    juego.unregister(self.jugador)
            except: debug("Fallo al unregistrar el jugador '%s' " % self.jugador.id)
            self.net.stop()
            self.net.join()
            if self.server:
                self.server.stop()
                self.server.join()
            self.abort_networking()
        elif ev.key == K_f:
            if self.server and self.net.game:
                debug("Forzando inicio del juego en red")
                self.net.game.forceGameStart()
        elif ev.key == K_SPACE and self.net.status == "Conexion perdida":
            self.aborted = False
            try:
                self.net = netFrame.netFrame()
                self.net.start()
            except Exception, inst:
                debug("Error %s al conectar: %s" % (type(inst), inst))
                formatExceptionInfo(inst)
                self.net.status = inst

    def handle_joybuttondown(self, ev):
        if self.is_paused():
            return 0
        if ev.button == 3:
            self.demo_mode = False
            print "Exit joybutton"
            self.exit_game()

if __name__ == "__main__":
    screen.init(SELECTED_RESOLUTION, title="Network Test")
    director.run(Networking)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs
