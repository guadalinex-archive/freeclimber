#!/usr/bin/python
# -*- coding: utf-8 -*-
# Pyro remote objects test

import Pyro
import Pyro.core
import Pyro.naming
from Pyro.EventService.Server import EventServiceStarter
from Pyro.naming import NameServerStarter
from Pyro.errors import NamingError, URIError, PyroError
from Pyro.ext.daemonizer import Daemonizer
import signal
import os, sys
import types
import threading
from time import sleep
from config import *
from types import ListType
import socket
from random import randint
import urlparse


Pyro.config.__dict__['PYRO_TRACELEVEL'] = 3
Pyro.config.__dict__['PYRO_STORAGE'] = '/tmp'
Pyro.config.__dict__['PYRO_NS_URIFILE'] = '/tmp/Pyro_NS_URI'
Pyro.config.__dict__['PYRO_LOGFILE'] = '/tmp/Pyro_log'



class netPlayer:

    colors  = ('red','blue','green','yellow','white','orange','pink','violet')

    def __init__(self):
        self.id = str(randint(10**5,10**7))
        self.idgame = None
        self.name = self.id
        self.ip = socket.gethostbyname(socket.gethostname())
        self.score = 0
        self.lifes = 0
        self.level = 0
        self.window = 0
        self.numplayer = 0
        self.ready = False

    def get_color(self):
        return netPlayer.colors[self.numplayer]

    color = property(get_color)

    def __str__(self):
        return "Jugador '%s' (%s) en partida '%s' desde %s <Position: %d, Score: %d, Lifes: %d>" % (self.color, self.name, self.idgame, self.ip, self.level, self.score, self.lifes)

def compare_netplayers(a, b):
    debug ("Comparando jugadores %s y %s..."  % (a, b))
    if not(isinstance(a, netPlayer) and isinstance(b, netPlayer)):
        return 0
    if a.level > b.level:
        return 1
    elif a.level < b.level:
        return -1
    elif a.level == b.level:
        if a.score > b.score:
            return 1
        elif a.score < b.score:
            return -1
        else:
            if a.lifes > b.lifes:
                return 1
            elif a.lifes < b.lifes:
                return -1
            else:
                return 0

class netGame(Pyro.core.SynchronizedObjBase):

    colors  = ('red','blue','green','yellow','white','orange','pink','violet')

    def __init__(self):
        Pyro.core.SynchronizedObjBase.__init__(self)
        self.players = {}
        self.queued = []
        self.gameStarted = False
        self.id = str(randint(10**5,10**7))
        self.winner = None
        self.status = None
        self.timeout = TIMEOUT
        self.ready = False
        self.max_players = MAX_PLAYERS

    def is_ready(self):
        if self.ready:
            pass
        else:
            ready = True
            for p in self.validPlayers():
                ready = ready and p.ready
            self.ready = ready
        return self.ready and not self.winner

    def register(self,player,isWinner=False):
        if not self.validPlayers():
            self.timeout = TIMEOUT
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()
            debug("Iniciando cuentra atras en %d segundos" % self.timeout)
        if self.playerExists(player):
            debug("Jugador '%s' ya está registrado." % player.name)
            r = "OK"
        elif self.gameStarted:
            debug("Juego ya empezado. Encolando jugador '%s'" % player.name)
            r = "Juego empezado"
            if not player in self.queued: self.queued.append(player)
        elif len(self.players) >= MAX_PLAYERS:
            debug("Alcanzado número máximo de jugadores. Encolando jugador '%s'" % player.name)
            r = "En cola"
            if not player in self.queued: self.queued.append(player)
            self.forceGameStart()
        else:
            debug("Registrando jugandor '%s'" % player.name)
            self.addplayer(player)
            self.clean()
            r = "OK"
        return r

    def playersIsList(self):
        return type(self.players) is ListType

    def clean(self):
        for j in self.validPlayers():
            if not j.idgame == self.id:
                self.unregister(j)

    def addplayer(self,player):
        player.numplayer = self.numPlayers()
        player.idgame = self.id
        if self.playersIsList():
            self.players.append(player)
        else:
            self.players[player.name] = player

    def get_player_by_id(self, id):
        for p in self.validPlayers():
            if p.id == id:
                return p

    def numPlayers(self):
        return len(self.players)

    def countdown(self):
        if self.timeout:
            self.timeout -= 1
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()
        else:
            self.gameStart()

    def unregister(self,player):
        debug("Unregistrando jugador '%s'" % player.name)
        if self.playersIsList():
            for object in self.players:
                if player.name == object.name:
                    self.players.remove(object)

        else:
            if player.name in self.players.keys():
                del self.players[player.name]
        if self.queued:
            debug("Comprobando cola de espera...")
            if player in self.queued:
                self.queued.remove(player)
            else:
                firstqueued = self.queued[0]
                if self.register(firstqueued) == 'OK':
                    self.queued.pop(0)

        if not self.validPlayers():
            debug("Terminando juego...")
            self.gameStop()
            for player in self.queued:
                if self.register(player) == 'OK':
                     self.queued.remove(player)


    def playerExists(self,player):
        if self.playersIsList():
            for temp_player in self.players:
                if player.name == temp_player.name:
                    return True
            return False
        else:
            return player.name in self.players.keys()


    def getQueuePosition(self,player):
        if player in self.queued:
            return self.queued.index(player)

    def getPlayer(self,player):
        if self.playersIsList():
            for temp_player in self.players:
                if player.name == temp_player.name:
                    return temp_player
            return False
        else:
            if player.name in self.players.keys():
                return self.players[player.name]

    def getLeader(self):
        players = self.validPlayers(True)
        if players:
            return players[-1]

    def validPlayers(self, order = False):
        if self.playersIsList():
            jugadores = self.players
        else:
            jugadores = self.players.values()
        if order:
            jugadores.sort(compare_netplayers)
        return jugadores


    def imprime(self):
        text = ""
        if self.playersIsList():
            for object in self.players:
                text += object.name + '\n'

        else:
            for object in self.players.values():
                text += object.name + '\n'

        return text

    def setWinner(self,player):
        self.winner = self.getPlayer(player)
        self.gameStarted = False
        self.ready = False
        self.id = str(randint(10**5,10**7))
        self.timeout = TIMEOUT+15
        self.timer = threading.Timer(1.0, self.countdown)
        self.timer.start()


    def getWinner(self):
        return self.winner


    def isWinner(self,player):
        if self.winner.name == player.name:
            return True


    def updatePlayer(self, player):
        debug("Actualizando %s" % player)
        if self.playersIsList():
            indice = self.getPosition(player)
            self.players.remove(self.getPlayer(player))
            self.players.insert(indice,player)
        else:
            self.players.update({player.name:player})


    def forceGameStart(self):
        try:
            self.timer.cancel()
        except:
            self.timeout = 0
        if self.numPlayers() >= 1:
            self.gameStarted = True
            self.winner = None

    def gameStart(self):
        if self.numPlayers() >= MIN_PLAYERS:
            self.gameStarted = True
            self.winner = None
        else:
            self.gameStarted = False
            self.timeout = TIMEOUT
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()

    def gameStop(self):
        self.gameStarted = False
        self.ready = False
        for object in self.validPlayers():
            self.unregister(object)
            #self.register(object,isWinner=self.isWinner(object))






class netFrame(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self)
        self._abort_flag = False
        self.daemon = None
        self.ns = None
        self.childpid = None
        self.nsdaemon = Pyro.naming.NameServerStarter()
        self.status = None
        self.game = None
        self.serverip = '0.0.0.0'



    # Cheching existen NameServer

    def existsNameServer(self):

        for contador in range(1,3):
            self.status = "Buscando servidor... (Intento %d)" % contador
            debug(self.status)
            try:
                Pyro.naming.NameServerLocator().getNS()
            except (NamingError,PyroError):
                exists = False
            else:
                return True
            if self._abort_flag:
                break
            sleep(1.0)
        return exists

    def run(self):

        #Checking existing name server

        if not self.existsNameServer() and not self._abort_flag:

            debug("No se han encontrado servidores en la red")
            self.status = "No se han encontrado servidores en la red\nIniciando el servidor propio..."
            self.childpid = os.fork()

            if (self.childpid == 0):

                debug("Iniciando el servidor propio... (pid %s)" % os.getpid())

                #print "child process"
                self.nsdaemon.start()
            else:

                sleep(5)
                #while not self.nsdaemon.waitUntilStarted():
                #   sleep(1)

                #print "parent process"
                self.daemon = Pyro.core.Daemon()

                self.ns = Pyro.naming.NameServerLocator().getNS()

                # daemon and nsdaemon connecting...
                self.daemon.useNameServer(self.ns)

                try:
                    self.ns.unregister('netGame')

                except NamingError:
                    pass

                # netGame object registering...
                self.status = "Registrando objeto compartido..."
                debug(self.status)
                self.daemon.connect(netGame(),'netGame')

                # daemon loop...
                debug("Demonio iniciado")
                self.status = "Servidor iniciado. Esperando jugadores..."
                self.daemon.requestLoop(condition = lambda: not self._abort_flag)

        elif not self._abort_flag:
            debug("Servidor encontrado. Iniciando conexion...")
            self.status = "Servidor encontrado. Iniciando conexion..."
            for i in range(20):
                try:
                    ns = Pyro.naming.NameServerLocator().getNS()
                    #self.serverip = urlparse.urlparse(str(ns.URI)).netloc
                    #
                    self.serverip = str(str(ns.URI).split('/')[2].split(':')[0])
                    self.game = Pyro.core.getAttrProxyForURI(ns.resolve('netGame'))
                    sleep(0.1)
                    break
                except:
                    debug("Fallo al establecer la conexión")

            if self.game:
                self.status = "Conexion establecida"
                debug(self.status)
                while not self._abort_flag:
                    #self.game = Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
                    sleep(0.1)
            self.status = "Conexion terminada"
            debug(self.status)


    def get_game(self):
        try:
            return Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
        except: pass

    def stop(self):

        # Server
        if self.ns is not None:
            self.game = None
            debug("Deteniendo Servidor de red..")
            try:
                os.kill(self.childpid,signal.SIGINT)
                os.waitpid(self.childpid, 0)
            except:
                debug("No se puto matar el proceso %d.." % self.childpid)
            self._abort_flag = True
            debug("Servidor detenido")
        # Client
        else:
            self._abort_flag = True
            debug("Desconectado del servidor")
            pass
        self.status = "Juego en red cancelado"


def main():

    juegoenred = netFrame()
    juegoenred.start()
    while 1:
        sleep(1)
    juegoenred.stop()




if __name__ == '__main__':
    main()


