# -*- coding: utf-8 -*-
##
## requires pygext 0.9.1 or newer
##

import pygame
import os
from pygame.locals import *
#from menu import MainMenu

## First we'll define some constants so we can
## easily alter any game parameters.
from config import *

## Import psyco if available
try:
    import psyco
except ImportError:
    pass
else:
    from psyco.classes import *
    psyco.full()

from pygext.gl.all import *
from pygext.render.halo import halocircle
from random import random, randint
from glob import glob
from math import ceil, floor
from base64 import b64encode
import socket
from netFrame import netPlayer
from building import Escalable, MetaWindow

SELECTED_RESOLUTION= get_game_resolution()

class Wait(Animate):

    def cleanup(self):
        pass

class Status(Entity):

    image = os.path.join(LINUX_GAME_PATH, 'images','common','miniclimber.png')
    layer = 'info'

    def init(self, width, color = None):
        #if color:
        #    self.shape = resources.get_bitmap(glob.glob(os.path.join(LINUX_GAME_PATH, 'images','common', 'miniclimber_'+color+'*.png')), hotspot = None)
        #    if self.shape is not None and self.shape._listid is None:
        #        self.shape.compile()
        if width:
            self.escala = float(width)/self.width
        self.set(x=width, y=SELECTED_RESOLUTION[1]-width, scale=self.escala) # also set the drawing scale here
        self.position_font = GLFont(("NORMT.TTF", 48),(225,225,30))
        self.position = TextEntity(self.position_font, "1ª")
        self.position.set(left= self.right, centery= self.centery).place("info")

    def set_status(self, position = None):
        print position
        if position:
            self.position.set_text("%d" % (int(position)-1))

    def moveTo(self, x, y, secs=0.25, escala = 1, alpha=255):
        self.do(MoveTo(x, y, secs))
        self.position.do((MoveTo(x, y, secs)))
        self.do(Scale(escala, secs))
        self.position.do(Scale(escala, secs))
        self.do(AlphaFade(alpha, secs))
        self.position.do(AlphaFade(alpha, secs))

class Lifes(Entity):

    image = os.path.join(LINUX_GAME_PATH, 'images','common','climber.png')
    layer = "info"

    def init(self, x, y, width = None, lifes = None, theme='default'):
        self.num = lifes and lifes or 3
        if width:
            self.escala = float(width)/self.width
        self.set(x=x, y=y, scale=self.escala)
        self.vidas = TextEntity(GLFont(("TUFFY.TTF", 28),(255,0,0)), "x %d" % self.num)
        self.vidas.set(x= self.right-self.width/4, centery = self.centery).place("info")

    def set_lifes(self, num):
        self.num = num
        self.vidas.set_text("x %d" % self.num)

class Clasification:

    def __init__(self):
        self.jugadores = {}
        self.marcador = {}

    def add(self, e):
        debug("Añadiendo jugador en red: '%s'" % e.name)
        self.jugadores[e.color] = e
        self.marcador[e.color] = Status(width=SELECTED_RESOLUTION[0]/20,color=e.color)

    def update(self, jugadores = []):
        for j in jugadores:
            self.jugadores[j.color]=j
            self.marcador[j.color].set_status(position = j.position)
        x = 20
        y = SELECTED_RESOLUTION[1]-20
        escala = 1.0
        alpha = 127
        dalpha = 128/len(self.jugadores)
        for e in self.get_order():
            print self.marcador[e.color]
            self.marcador[e.color].moveTo(x, y, 0.25, escala, alpha)
            alpha += dalpha
            print self.marcador[e.color].height
            y -= self.marcador[e.color].height

    def get_order(self):
        order = self.jugadores.values()
        order.sort(compare_climbers)
        print order
        #order.reverse()
        return order

class netClimber:

    def __init__(self):
        self.id = str(randint(10**5,10**7))
        self.name = self.id
        self.ip = socket.gethostbyname(socket.gethostname())
        self.score = 0
        self.lifes = 0
        self.position = 0
        self.color = ""

    def __str__(self):
        return "Player %s on %s" % (self.name, self.ip)


def compare_climbers(a, b):
    print a
    print b
    if not(isinstance(a, netPlayer) and isinstance(b, netPlayer)):
        return 0
    if a.pos > b.pos:
        return 1
    elif a.pos < b.pos:
        return -1
    elif a.pos == b.pos:
        if a.score > b.score:
            return 1
        elif a.score < b.score:
            return -1
        else:
            if a.lifes > b.lifes:
                return 1
            elif a.lifes < b.lifes:
                return -1
            else:
                return 0

class Climber(Entity):

    image = os.path.join(LINUX_GAME_PATH, 'images','common','climber.png')
    layer = "actors"

    def init(self, x, y, width = None, height = None, theme='default'):
        self.id = b64encode(str(randint(10**5,10**7)))
        self.name = self.id
        self.escala = 1
        self.lifes = 3
        self.floor = 2
        self.window = 2
        self.score = 0
        self.color = None
        self.netclimber = None
        theme_path = os.path.join(LINUX_GAME_PATH, 'images','levels', theme)
        self.shape = resources.get_bitmap(os.path.join(theme_path, 'climber.png'), hotspot = None)
        if self.shape is not None and self.shape._listid is None:
            self.shape.compile()
        if width:
            self.escala = float(width)/self.width
        self.altura = height and height or self.height
        self.set(x=x, y=y, scale=self.escala) # also set the drawing scale here

        #self.status = Status()
        score_big_font = GLFont(("RDS.TTF", 64),(225,225,30))
        position_big_font = GLFont(("TUFFY.TTF", 128),(225,225,30))
        self.big_position = TextEntity(position_big_font, "1ª")
        self.big_score = TextEntity(score_big_font, "0")
        self.big_position.set(left= SELECTED_RESOLUTION[0]/30, top = 25).place("info")
        self.big_score.set(right= SELECTED_RESOLUTION[0]*29/30, top = 25).place("info")
        self.vidas = Lifes(x = SELECTED_RESOLUTION[0]-self.width, y = self.big_score.bottom+self.big_score.height, width = self.width/1.5)

        self.set_status(position = self.floor, score = self.score, lifes = self.lifes)
        self.last_movement=None
        self.manos = 2
        #self.escudo = Escudo()
        #self.escudo.set(centerx = self.centerx, centery = self.centery, scale = self.escala/2)
        #self.escudo.do(Hide())

        up1left = glob(theme_path+'/*_up1left_*.png')
        up1left.sort()

        up2left = glob(theme_path+'/*_up2left_*.png')
        up2left.sort()

        up3left = glob(theme_path+'/*_up3left_*.png')
        up3left.sort()

        up1right = glob(theme_path+'/*_up1right_*.png')
        up1right.sort()

        up2right = glob(theme_path+'/*_up2right_*.png')
        up2right.sort()

        up3right = glob(theme_path+'/*_up3right_*.png')
        up3right.sort()

        left = glob(theme_path+'/*_left_*.png')
        left.sort()

        right = glob(theme_path+'/*_right_*.png')
        right.sort()

        down = glob(theme_path+'/*_down_*.png')
        down.sort()

        fall = glob(theme_path+'/*_fall_*.png')
        fall.sort()

        wait = glob(theme_path+'/*_wait_*.png')
        wait.sort()

        waitleft = glob(theme_path+'/*_waitleft_*.png')
        waitleft.sort()

        waitright = glob(theme_path+'/*_waitright_*.png')
        waitright.sort()

        winner = glob(theme_path+'/*_winner_*.png')
        winner.sort()

        self.animations={'up1left': Animate([resources.get_bitmap(e) for e in up1left], 0.5),\
                        'up1right': Animate([resources.get_bitmap(e) for e in up1right], 0.5),\
                        'up2left': Animate([resources.get_bitmap(e) for e in up2left], 0.7),\
                        'up2right': Animate([resources.get_bitmap(e) for e in up2right], 0.7),\
                        'up3left': Animate([resources.get_bitmap(e) for e in up3left], 0.5),\
                        'up3right': Animate([resources.get_bitmap(e) for e in up3right], 0.5),\
                        'down':  Animate([resources.get_bitmap(e) for e in down], 0.5),\
                        'left': Animate([resources.get_bitmap(e) for e in left], 0.95),\
                        'right': Animate([resources.get_bitmap(e) for e in right], 0.95),\
                        'wait': Wait([resources.get_bitmap(e) for e in wait], 0.5, mode = PingPongMode),\
                        'waitleft': Wait([resources.get_bitmap(e) for e in waitleft], 0.5, mode = PingPongMode),\
                        'waitright': Wait([resources.get_bitmap(e) for e in waitright], 0.5, mode = PingPongMode),\
                        'fall': Animate([resources.get_bitmap(e) for e in fall], 0.5, mode = PingPongMode),\
                        'winner': Animate([resources.get_bitmap(e) for e in winner], 0.5, mode = PingPongMode)
                        }

        self.movements={'up1left': MoveDelta(0, ceil(-self.altura/2.0), 0.4)+Delay(0.1),\
                        'up1right': MoveDelta(0, ceil(-self.altura/2.0), 0.4)+Delay(0.1),\
                        'up2left': Delay(0.1)+MoveDelta(0, floor(-self.altura/2.0), 0.5)+Delay(0.1),\
                        'up2right': Delay(0.1)+MoveDelta(0, floor(-self.altura/2.0), 0.5)+Delay(0.1),\
                        'up3left': None,\
                        'up3right': None,\
                        'halfdown': MoveDelta(0, self.altura/2, 0.25),\
                        'down': MoveDelta(0, self.altura, 0.5),\
                        'left': Delay(0.25)+MoveDelta(-self.width,0, 0.50)+Delay(0.20),\
                        'right': Delay(0.25)+MoveDelta(self.width,0, 0.50)+Delay(0.20),\
                        'wait': None,\
                        'waitleft': None,\
                        'waitright': None,\
                        'fall': MoveDelta(0,10,1.0)+MoveDelta(0,SELECTED_RESOLUTION[1]/2,1.0),\
                        'winner': MoveDelta(0, ceil(-self.altura/2.0), 0.5),\
                        }

        self.add_collnode("player", radius=30*self.scale, x=0, y=int(-160*self.scale))

    def set_in_window(self, window):
        self.altura = window.height
        self.set(x= window.x, y=window.y -5 + window.height*3/5)
        self.last_movement = None
        self.move()
        self.do(Blink(0.5,repeats=6))
        #self.escudo.set(centerx = self.centerx, centery = self.centery)

    def refresh_status(self):
        self.set_status(position = self.floor, lifes = self.lifes, score = self.score)

    def attach_netclimber(self, netclimber):
        debug("Asociando jugador en red: '%s'" % netclimber.name)
        self.id = netclimber.id
        self.name = netclimber.name
        self.color = netclimber.color
        self.netclimber = netclimber
        self.update_netclimber()
        debug("Jugador asociado")

    def move(self, movement="wait"):
        debug("Requested %s" % movement)
        if (self.ismoving() and not movement == 'hit') or self.last_movement == "fall":
            debug("Movimiento descartado")
            return None
        debug("Movimiento aceptado")
        self.abort_actions(Wait)
        if movement.startswith('wait'):
            self.abort_actions()
            self.do(self.animations[movement])
            self.last_movement = None
            self.manos = 2
        elif (movement == "left" or movement == 'right'):
            if self.last_movement:
                movement = None
            else:
                if movement == 'left':
                    self.window -= 1
                else:
                    self.window += 1
                self.do(self.animations[movement]+self.animations['wait'])
                self.last_movement = None
                self.score += 50
                self.set_status(score = self.score)
                self.manos = 2
        elif movement == "down":
            self.do(self.animations[movement]+self.animations['wait'])
            if self.last_movement and self.last_movement.startswith("up1"):
                movement = "halfdown"
            else:
                self.floor -= 1
            self.set_status(position = self.floor)
            self.last_movement = None
            self.manos = 2
        elif movement == "fall":
            self.do(self.animations[movement])
            self.last_movement = "fall"
            self.lifes -= 1
            self.set_status(lifes = self.lifes)
            self.manos = 0
        elif movement == "up_right":
            if self.last_movement == None:
                movement = "up1right"
                self.do(self.animations[movement]+self.animations['waitright'])
                self.last_movement = movement
                self.manos = 1
            elif self.last_movement == 'up1left':
                movement = "up2right"
                self.do(self.animations[movement]+self.animations['waitright'])
                self.last_movement = movement
                self.floor += 1
                self.manos = 1
            elif self.last_movement == 'up2left' or self.last_movement == "hit":
                movement = "up3right"
                self.do(self.animations[movement]+self.animations['wait'])
                self.last_movement = None
                self.score += 100
                self.set_status(position = self.floor, score = self.score)
                self.manos = 2
        elif movement == "up_left":
            if self.last_movement == None:
                movement = "up1left"
                self.do(self.animations[movement]+self.animations['waitleft'])
                self.last_movement = movement
                self.manos = 1
            elif self.last_movement == 'up1right':
                movement = "up2left"
                self.do(self.animations[movement]+self.animations['waitleft'])
                self.last_movement = movement
                self.floor += 1
                self.manos = 1
            elif self.last_movement == 'up2right' :
                movement = "up3left"
                self.do(self.animations[movement]+self.animations['wait'])
                self.last_movement = None
                self.score += 100
                self.set_status(position = self.floor, score = self.score)
                self.manos = 2
        elif movement == 'hit':
            if self.manos == 2:
                self.do(self.animations['waitleft'])
                self.last_movement = 'hit'
                self.score -= 200
                self.set_status(score = self.score)
                self.manos = 1
            elif self.manos == 1:
                movement = 'fall'
                self.last_movement = "fall"
                self.do(self.animations[movement])
                self.lifes -= 1
                self.set_status(lifes = self.lifes)
                self.manos = 0
        elif movement == 'winner':
            self.do(self.animations[movement])
            self.last_movement = None
        self.update_netclimber()
        if movement in self.movements and self.movements[movement]:
            self.do(self.movements[movement])
            #self.escudo.do(self.movements[movement])

    def update_netclimber(self):
        if self.netclimber:
            self.netclimber.score = self.score
            self.netclimber.lifes = self.lifes
            self.netclimber.position = self.floor

    def ismoving(self):
        #print self.get_actions(MoveDelta)
        return len(self.get_actions(MoveDelta))+len(self.get_actions(Delay))

    moving = property(ismoving)

    def invencible(self):
       for a in list(self.current_actions):
           if isinstance(a, Blink):
               return True

    def set_status(self, position = None, score = None, lifes = None):
        if position:
            self.big_position.set_text("%d" % (position-1))
            pass
        if score:
            self.big_score.set_text("%d" % score)
            self.big_score.set(right= SELECTED_RESOLUTION[0]*29/30)
        if lifes:
            self.vidas.set_lifes(lifes)
            pass

    def auto_move(self, stage):
        f, w = self.floor, self.window
        delay = randint(750,1500)
        if isinstance(stage[-f][w], MetaWindow) and stage[-f][w].ismoving():
            if not self.last_movement and w < len(stage[1])-1 and stage[-f][w+1].isescalable():
                self.move('right')
                delay = randint(900,1500)
            elif not self.last_movement and w > 1 and stage[-f][w-1].isescalable():
                self.move('left')
                delay = randint(900,1500)
            elif f > 1 and isinstance(stage[-f+1][w], Escalable) and stage[-f+1][w].isescalable():
                self.move('down')
                delay = randint(750,1300)
        elif self.last_movement == 'up1right' and f < len(stage) and stage[-f-1][w].isescalable():
            self.move('up_left')
            delay = randint(625,900)
        elif self.last_movement == 'up1left' and f < len(stage) and stage[-f-1][w].isescalable():
            self.move('up_right')
            delay = randint(625,900)
        elif self.last_movement == 'up2right':
            self.move('up_left')
            delay = randint(750,1500)
        elif self.last_movement == 'up2left' or self.last_movement == 'hit':
            self.move('up_right')
            delay = randint(750,1500)
        elif self.last_movement is None:
            if f < len(stage) and stage[-f-1][w].isescalable():
                self.move('up_right')
                delay = randint(550,900)
            elif w > 1 and stage[-f][w-1].isescalable():
                self.move('left')
                delay = randint(900,1500)
            elif w < len(stage[1])-1 and stage[-f][w+1].isescalable():
                self.move('right')
                delay = randint(900,1500)
            elif f > 1 and isinstance(stage[-f+1][w], Escalable) and stage[-f+1][w].isescalable():
                self.move('down')
                delay = randint(750,1300)
        elif self.last_movement == 'fall':
            pass
        return delay

if __name__ == "__main__":
    print netClimber()

