#!/usr/bin/python

from netFrame import netFrame,Player


class netTest:
	def __init__(self):
		self.net = netFrame()
		self.net.start()
		self.net.join()

	def tick(self):
		print "test"
		print self.net.game
		juego = self.net.get_game()
		juego.register(Player("javi",(100,100)))

		print self.net.game.imprime()




def main():

	test = netTest()
	for a in range(15):
		test.tick()




if __name__ == '__main__':
	main()
