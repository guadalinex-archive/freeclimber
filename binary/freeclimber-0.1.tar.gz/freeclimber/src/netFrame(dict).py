#!/usr/bin/python
# -*- coding: utf-8 -*-
# Pyro remote objects test

import Pyro.core
import Pyro.naming
from Pyro.EventService.Server import EventServiceStarter
from Pyro.naming import NameServerStarter
from Pyro.errors import NamingError, URIError, PyroError
from Pyro.ext.daemonizer import Daemonizer
import signal
import os, sys
import types
import threading
from time import sleep
from actors import netClimber
from config import *

MAX_PLAYERS = 4


class Player:
    def __init__(self,name,position):

        self.name = name
        self.position = position


    def __str__(self):
        return self.name



class netGame(Pyro.core.SynchronizedObjBase):

    colors = ['red','blue','green','yellow','white','violet','grey','orange','pink']

    def __init__(self):
        Pyro.core.SynchronizedObjBase.__init__(self)
        self.players = {}
        self.queued = []
        self.gameStarted = False
        self.winner = None
        self.status = None
        self.timeout = TIMEOUT
        self.timer = threading.Timer(1.0, self.countdown)
        self.timer.start()


    def register(self,player,isWinner=False):
        print "registrando"
        if not isWinner:
            if self.playerExists(player):
                print "Player '%s' already exists. Couldn't register..." % player.name
                r = "OK"
            elif self.numPlayers() > MAX_PLAYERS:
                print "Reached maximum players. Queeing player '%s'" % player.name
                r = "En cola"
                if not player in self.queued:
                    self.queued.append(player)
                #self.forceGameStart()
            else:
                print "Registering player '%s'" % player.name
                self.player.color = netGame.colors[self.numPlayers()]
                self.players[player.name]=player
                r = "OK"
        else:
            print "Registering winner '%s'" % player.name
            self.player.color = netGame.colors[self.numPlayers()]
            self.players[player.name]=player
            r = 'OK'
        return r

    def numPlayers(self):
        return len(self.players)

    def countdown(self):
        if self.timeout:
            self.timeout -= 1
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()
        else:
            self.gameStart()

    def unregister(self,player):
        if player.name in self.players.keys():
            del self.players[player.name]
            print "Unregistering player '%s'" % player.name

    def playerExists(self,player):
        print player.name in self.players.keys()
        return player.name in self.players.keys()

    def getPosition(self,player):
        for object in self.queued:
            if player.name == object.name:
                return self.players.index(object)
                break

    def getPlayer(self,player):
        for object in self.players:
            if player.name == object.name:
                return object

    def queuePosition(self,player):
        return self.getPosition(player) - MAX_PLAYERS

    def validPlayers(self):
        return self.players.values()

    def imprime(self):
        text = ""
        for object in self.players.values():
            text += object.name + '\n'
        return text

    def setWinner(self,player):
        self.winner = self.getPlayer(player)


    def getWinner(self):
        return self.winner


    def isWinner(self,player):
        return self.winner.name == player.name

    def updatePlayer(self, player):
        self.players[player.name]=player

    def forceGameStart(self):
        self.timer.cancel()
        if self.numPlayers() > 1:
            self.gameStarted = True

    def gameStart(self):
        if self.numPlayers() >= MIN_PLAYERS:
            self.gameStarted = True
        else:
            self.timeout = TIMEOUT
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()

    def gameStop(self):
        self.gameStarted = False
        for object in self.validPlayers():
            self.unregister(object)
            #self.register(object,isWinner=self.isWinner(object))



class netFrame(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self._abort_flag = False
        self.daemon = None
        self.ns = None
        self.childpid = None
        self.nsdaemon = Pyro.naming.NameServerStarter()
        self.status = None
        self.game = None



    # Cheching existen NameServer

    def existsNameServer(self):

        for contador in range(1,6):
            print "Buscando servidor... (Intento %d)" % contador
            self.status = "Buscando servidor... (Intento %d)" % contador
            try:
                Pyro.naming.NameServerLocator().getNS()
            except (NamingError,PyroError):
                exists = False
            else:
                return True
            sleep(1.0)
        return exists



    def run(self):

        #Checking existing name server

        if not self.existsNameServer():

            print "No se han encontrado servidores en la red"
            self.status = "No se han encontrado servidores en la red\nIniciando el servidor propio..."
            self.childpid = os.fork()

            if (self.childpid == 0):

                print "Iniciando el servidor propio... (pid %s)" % os.getpid()

                #print "child process"
                self.nsdaemon.start()
            else:

                sleep(5)
                #while not self.nsdaemon.waitUntilStarted():
                #   sleep(1)

                #print "parent process"
                self.daemon = Pyro.core.Daemon()

                self.ns = Pyro.naming.NameServerLocator().getNS()

                # daemon and nsdaemon connecting...
                self.daemon.useNameServer(self.ns)

                try:
                    self.ns.unregister('netGame')

                except NamingError:
                    pass

                # netGame object registering...
                print "Registering netGame object..."
                self.status = "Registering netGame object..."
                self.daemon.connect(netGame(),'netGame')

                # daemon loop...
                print "Demonio iniciado"
                self.status = "Servidor iniciado. Esperando jugadores..."
                self.daemon.requestLoop(condition = lambda: not self._abort_flag)
                os.kill(self.childpid,signal.SIGINT)
        else:
            print "Servidor encontrado. Iniciando conexion..."
            self.status = "Servidor encontrado. Iniciando conexion..."
            self.game = Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
            self.status = "Conexion establecida"
            print self.status

    def get_game(self):
        try:
            return Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
        except: pass

    def stop(self):

        # Server
        if self.ns is not None:
            self.game = None
            self._abort_flag = True
            os.kill(self.childpid,signal.SIGINT)
        # Client
        else:
            pass


def main():

    juegoenred = netFrame()
    juegoenred.start()
    sleep(25)
    juegoenred.stop()




if __name__ == '__main__':
    main()

