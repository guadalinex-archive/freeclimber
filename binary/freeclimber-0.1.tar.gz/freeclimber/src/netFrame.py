#!/usr/bin/python
# -*- coding: utf-8 -*-
# Pyro remote objects test

import Pyro.core
import Pyro.naming
from Pyro.EventService.Server import EventServiceStarter
from Pyro.naming import NameServerStarter
from Pyro.errors import NamingError, URIError, PyroError
from Pyro.ext.daemonizer import Daemonizer
import signal
import os, sys
import types
import threading
from time import sleep
from config import *
from types import ListType
import socket
from random import randint

PYRO_TRACELEVEL = 3

class netPlayer:

    def __init__(self):
        self.id = str(randint(10**5,10**7))
        self.name = self.id
        self.ip = socket.gethostbyname(socket.gethostname())
        self.score = 0
        self.lifes = 0
        self.position = 0
        self.color = ""

class netGame(Pyro.core.SynchronizedObjBase):

    colors  = ['red','blue','green','yellow','white','orange','pink','violet']

    def __init__(self):
        Pyro.core.SynchronizedObjBase.__init__(self)
        self.players = {}
        #self.players = []
        self.queued = []
        self.gameStarted = False
        self.winner = None
        self.status = None
        self.timeout = TIMEOUT
        self.timer = threading.Timer(1.0, self.countdown)
        self.timer.start()


    def register(self,player,isWinner=False):

        if not isWinner:
            if self.playerExists(player):
                debug("Player '%s' already exists. Couldn't register..." % player.name)
                r = "OK"
            elif len(self.players) >= MAX_PLAYERS:
                debug("Reached maximum players. Queeing player '%s'" % player.name)
                r = "En cola"
                if not player in self.queued: self.queued.append(player)
                self.forceGameStart()
            else:
                debug("Registering player '%s'" % player.name)
                self.addplayer(player)
                r = "OK"
        else:
            debug("Registering winner '%s'" % player.name)
            self.addplayer(player)
            r = 'OK'
        return r

    def playersIsList(self):
        return type(self.players) is ListType


    def addplayer(self,player):
        player.color = netGame.colors[self.numPlayers()]
        if self.playersIsList():
            self.players.append(player)
        else:
            self.players[player.name] = player


    def numPlayers(self):
        return len(self.players)

    def countdown(self):
        if self.timeout:
            self.timeout -= 1
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()
        else:
            self.gameStart()


    def unregister(self,player):
        if self.playersIsList():
            for object in self.players:
                if player.name == object.name:
                    self.players.remove(object)
                    debug("Unregistering player '%s'" % player.name)
        else:
            if player.name in self.players.keys():
                del self.players[player.name]
                debug("Unregistering player '%s'" % player.name)


    def playerExists(self,player):
        if self.playersIsList():
            for temp_player in self.players:
                if player.name == temp_player.name:
                    return True
            return False
        else:
            return player.name in self.players.keys()


    def getPosition(self,player):
        for object in self.queued:
            if player.name == object.name:
                return self.players.index(object)
                break

    def getPlayer(self,player):
        for object in self.players:
            if player.name == object.name:
                return object


    def queuePosition(self,player):
        return self.getPosition(player) - MAX_PLAYERS


    def validPlayers(self):
        if self.playersIsList():
            return self.players
        else:
            return self.players.values()

    def imprime(self):
        text = ""
        if self.playersIsList():
            for object in self.players:
                text += object.name + '\n'

        else:
            for object in self.players.values():
                text += object.name + '\n'

        return text

    def setWinner(self,player):
        self.winner = self.getPlayer(player)


    def getWinner(self):
        return self.winner


    def isWinner(self,player):
        if self.winner.name == player.name:
            return True


    def updatePlayer(self, player):
        if self.playersIsList():
            indice = self.getPosition(player)
            self.players.remove(self.getPlayer(player))
            self.players.insert(indice,player)
        else:
            self.players[player.name]=player

    def forceGameStart(self):
        try:
            self.timer.cancel()
        except:
            self.timeout = 0
        if self.numPlayers() >= 1:
            self.gameStarted = True

    def gameStart(self):
        if self.numPlayers() >= MIN_PLAYERS:
            self.gameStarted = True
        else:
            self.gameStarted = False
            self.timeout = TIMEOUT
            self.timer = threading.Timer(1.0, self.countdown)
            self.timer.start()

    def gameStop(self):
        self.gameStarted = False
        for object in self.validPlayers():
            self.unregister(object)
            #self.register(object,isWinner=self.isWinner(object))






class netFrame(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self)
        self._abort_flag = False
        self.daemon = None
        self.ns = None
        self.childpid = None
        self.nsdaemon = Pyro.naming.NameServerStarter()
        self.status = None
        self.game = None



    # Cheching existen NameServer

    def existsNameServer(self):

        for contador in range(1,2):
            self.status = "Buscando servidor... (Intento %d)" % contador
            debug(self.status)
            try:
                Pyro.naming.NameServerLocator().getNS()
            except (NamingError,PyroError):
                exists = False
            else:
                return True
            if self._abort_flag:
                break
            sleep(1.0)
        return exists

    def run(self):

        #Checking existing name server

        if not self.existsNameServer() and not self._abort_flag:

            debug("No se han encontrado servidores en la red")
            self.status = "No se han encontrado servidores en la red\nIniciando el servidor propio..."
            self.childpid = os.fork()

            if (self.childpid == 0):

                debug("Iniciando el servidor propio... (pid %s)" % os.getpid())

                #print "child process"
                self.nsdaemon.start()
            else:

                sleep(5)
                #while not self.nsdaemon.waitUntilStarted():
                #   sleep(1)

                #print "parent process"
                self.daemon = Pyro.core.Daemon()

                self.ns = Pyro.naming.NameServerLocator().getNS()

                # daemon and nsdaemon connecting...
                self.daemon.useNameServer(self.ns)

                try:
                    self.ns.unregister('netGame')

                except NamingError:
                    pass

                # netGame object registering...
                self.status = "Registering netGame object..."
                debug(self.status)
                self.daemon.connect(netGame(),'netGame')

                # daemon loop...
                debug("Demonio iniciado")
                self.status = "Servidor iniciado. Esperando jugadores..."
                self.daemon.requestLoop(condition = lambda: not self._abort_flag)

        elif not self._abort_flag:
            debug("Servidor encontrado. Iniciando conexion...")
            self.status = "Servidor encontrado. Iniciando conexion..."
            for i in range(20):
                try:
                    self.game = Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
                    break
                except:
                    debug("Fallo al establecer la conexión")

            self.status = "Conexion establecida"
            debug(self.status)
            while not self._abort_flag:
                #self.game = Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
                sleep(1.0)


    def get_game(self):
        try:
            return Pyro.core.getAttrProxyForURI(Pyro.naming.NameServerLocator().getNS().resolve('netGame'))
        except: pass

    def stop(self):

        # Server
        if self.ns is not None:
            self.game = None
            debug("Deteniendo Servidor de red..")
            os.kill(self.childpid,signal.SIGINT)
            os.waitpid(self.childpid, 0)
            self._abort_flag = True
            debug("Servidor detenido")
        # Client
        else:
            self._abort_flag = True
            debug("Desconectado del servidor")
            pass
        self.status = "Juego en red cancelado"


def main():

    juegoenred = netFrame()
    juegoenred.start()
    sleep(100)
    juegoenred.stop()




if __name__ == '__main__':
    main()


