#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
from config import *
import netFrame
import time

from pygext.gl.all import *
from pygame.locals import *
#import Pyro

SELECTED_RESOLUTION = get_game_resolution()



class Networking(Scene):

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene

    def enter(self):
        pygame.mixer.music.stop()
        pygame.mixer.music.set_volume(VOLUME*0.01)
        pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'menuintro.ogg'))
        pygame.mixer.music.play(-1)

        self.new_static("bg")
        self.new_layer("points")
        self.new_layer("info")
        self.new_layer("actors")

        ## Load the background.
        e = Entity(os.path.join(LINUX_GAME_PATH, MENU_PATH, 'option-bg.png'), hotspot=(0,0))
        e.set(x=0,y=0, scale = SELECTED_RESOLUTION[0]/float(e.width)).place("bg")



        self.font = font = GLFont(("GPUTEKSR.TTF", 30))
        self.mensaje = TextEntity(self.font, "Prueba de conexion en red")
        self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)

        self.ring = Entity(os.path.join(LINUX_GAME_PATH, 'images', "common","ring.png"))
        self.ring.set(centerx = 48, centery = 48).place("points")
        self.ring.do(RotateDelta(360,1.5,RepeatMode))
        #self.info.set(centerx=48, centery=48)
        self.mensaje.place("info")
        #self.info.place("info")
        self.server = None
        self.net = netFrame.netFrame()
        self.net.start()
        self.registrado = False
        self.ready = False
        self.jugador = None

        try:
            print self.wiimote
        except:
            self.wiimote = None

    def set_next_scene(self, new_scene):
        self.next_scene = new_scene

    def set_previous_scene(self, scene):
        self.previous_scene = scene

    def realtick(self):
        if self.net.status:
            self.mensaje.set_text(self.net.status)
            self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/2)
        if self.net.game:
            #juego = self.net.get_game()
            juego = self.net.game
            if juego:
                s = ''
                try:
                    for p in juego.validPlayers():
                        s += "Jugador '%s' (%s) from %s\n" % (p.color, p.name, p.ip)
                    self.mensaje.set_text("Conectado a %s\n%d/%d Jugadores registrados\nEl juego empezara en %ds.\n%s" % ("0.0.0.0",juego.numPlayers(), MAX_PLAYERS, juego.timeout, s))
                    self.mensaje.set(centerx = SELECTED_RESOLUTION[0]/2, centery = SELECTED_RESOLUTION[1]/2)
                    #y = SELECTED_RESOLUTION[1]*3/4
                    #x = SELECTED_RESOLUTION[0]*(juego.numPlayers()+1)/(MAX_PLAYERS+1)
                    if not self.registrado:
                        #self.jugador = netClimber()
                        self.jugador = netFrame.netPlayer()
                        if juego.register(self.jugador) == 'OK':
                            self.registrado = True
                            self.ready = True
                        else:
                            self.registrado = True
                            self.ready = False
                except Exception, inst:
                    print type(inst)     # the exception instance
                    print inst.args      # arguments stored in .args
                    print inst           # __str__ allows args to printed directly
                if juego.gameStarted and self.ready:
                    self.load_game()
        if self.net.ns:
            self.server = self.net
            debug("Conectando como cliente")
            self.net = netFrame.netFrame()
            self.net.start()


    def load_game(self):
        try:
            if self.next_scene:
                if self.wiimote:
                    self.next_scene.wiimote = self.wiimote
                self.next_scene.set_netFrame(self.net)
                self.next_scene.set_jugador(self.jugador)
                director.run(self.next_scene)
        except:
            director.quit()

    def abort_networking(self):
        try:
            if self.previous_scene:
                if self.wiimote:
                    self.previous_scene.wiimote = self.wiimote
                director.run(self.previous_scene)
            else:
                director.quit()
        except:
            director.quit()


    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            try:
                juego = self.net.game
                #juego = self.net.get_game()
                if self.jugador:
                    juego.unregister(self.jugador)
            except: debug("Fallo al unregistrar el jugador")
            self.net.stop()
            #self.net.join()
            if self.server:
                self.server.stop()
                #self.server.join()
            self.abort_networking()
        elif ev.key == K_f:
            if self.server and self.net.game:
                debug("Forzando inicio del juego en red")
                self.net.game.forceGameStart()



if __name__ == "__main__":
    screen.init(SELECTED_RESOLUTION, title="Network Test")
    director.run(Networking)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs
