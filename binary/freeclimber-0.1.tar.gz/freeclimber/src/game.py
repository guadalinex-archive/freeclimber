#!/usr/bin/python
# -*- coding: utf-8 -*-
##
## requires pygext 0.9.1 or newer
##

from pygame.locals import *
from pygext.gl.all import *
from config import *
from weather import Cloud, TestSystem, Snow
from building import *
from actors import *
from wiimote import IRreceptor

## Import psyco if available
try:
    import psyco
except ImportError:
    pass
else:
    from psyco.classes import *
    psyco.full()

from pygext.gl.all import *

SELECTED_RESOLUTION = get_game_resolution()

class CenteredScale(Scale):
    """Enlarge or shrink the current entity"""
    def init(self, scale, secs, center, mode=StopMode):
        self.scale = scale
        self.secs = secs
        self.mode = mode
        self.center = center

    def limited(self, x):
        self.entity.scale = self.startscale + self.dscale * x
        self.entity.set(centerx=self.center[0],centery=self.center[1])


class Game(Scene):
    init_gamepad()
    nfloors = 20
    if ASPECT == '4:3' or ASPECT == "9:6" or ASPECT == "10:16":
        columns = 8
    else:
        columns = 10

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene
        self.demo_mode = False
        self.wiimote = None
        self.paused = False


    def enter(self, theme = 'default'):
        self.i = 0

        debug("Cargando juego...")
        #pygame.event.set_grab(True)

        self.new_static("bg")

        ## The actors layer contains the ship and bullets.
        self.new_layer("city")
        self.new_layer("weather_b")
        self.new_layer("dummy")
        self.new_layer("room")
        self.new_layer("glass")
        self.new_stabile("building")
        self.new_stabile("actors")
        self.new_layer("particles")
        self.new_layer("weather_f")
        self.new_stabile("info")
        self.new_layer("points")

        ## Load the background.
        e = Entity(os.path.join(LINUX_GAME_PATH, 'images','levels', theme,  ASPECT, 'tile.jpg'), hotspot=(0,0))
        e.set(x=0,y=0).place("bg")

        debug("Capas creadas")

        screen.clear_color = None

        #system = TestSystem()
        node = Entity()
        node.set(x=0, y=0)
        #system.new_emitter(Snow, node)

        for x in range(6):
            Cloud(theme = theme)
            Cloud(capa = "weather_f", theme = theme)

        self.escenario = Stage((Building.nfloors, Building.columns), theme)

        debug("Escenario creado")

        self.player = Climber(x = SELECTED_RESOLUTION[0]/2, y = SELECTED_RESOLUTION[1]/2, width = self.escenario.width_unit, height = self.escenario.height_unit, theme = theme)
        debug("Jugador creado")
        self.set_player()

        pygame.mixer.music.stop()
        pygame.mixer.music.set_volume(VOLUME*0.01)
        pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'juegoclasica.ogg'))
        pygame.mixer.music.play(-1)

        debug("Musica cargada")


        self.pausedbg = Entity(os.path.join(LINUX_GAME_PATH, 'images','common', 'paused.png'), hotspot=(0,0))
        self.pausedbg.set(x=0,y=0,scale=max(SELECTED_RESOLUTION), alpha=165).place('info')
        self.pausedbg.do(Hide())
        self.pausedmsg = TextEntity(GLFont(("GPUTEKSB.TTF", SELECTED_RESOLUTION[0]/10),(255,255,255)), "PAUSA")
        self.pausedmsg.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2).place("info")
        self.pausedmsg.do(Hide())

        debug("Pausa preparada")



        if CONTROLLER == "IR controller":
            try:
                if not self.wiimote:
                    self.wiimote = IRreceptor()
                    self.wiimote.setDaemon(True)
                    if not self.wiimote.isAlive() and not self.wiimote.initialized:
                        self.wiimote.start()
                else:
                    self.wiimote.draw_hands()
            except:
                self.wiimote = IRreceptor()
                self.wiimote.setDaemon(True)
                if not self.wiimote.isAlive() and not self.wiimote.initialized:
                    self.wiimote.start()
        elif CONTROLLER.startswith("joystick"):
            init_gamepad(int(CONTROLLER[-1]))
            self.wiimote = None
        else:
            self.wiimote = None

        debug("Controles configurados")

        if self.demo_mode:
            now = pygame.time.get_ticks()
            self.prev_movement = now
            self.next_movement = now
            debug("Demo preparada")

        self.clasification = Clasification()

        self.countdown(3)

    def enter_netGame(self):
        pass

    def countdown(self, secs = None):
        center = (SELECTED_RESOLUTION[0]/2,SELECTED_RESOLUTION[1]/2)
        if secs:
            self.secs = secs
            self.cd = TextEntity(GLFont(("NORMT.TTF", SELECTED_RESOLUTION[0]/3),(255,215,20)), str(self.secs))
            self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2).place("info")
            self.cd.do(Hide()+Delay(1.0)+Show()+Delay(0.1)+CenteredScale(0,0.9,center)+CallFunc(self.countdown))
        else:
            if self.secs:
                self.cd.set_text(str(self.secs))
                self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, scale = 1, alpha = 255)
                self.cd.do(Delay(0.1)+CenteredScale(0,0.9,center)+CallFunc(self.countdown))
            else:
                self.cd.set_text("YA")
                self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2, scale=1.2, alpha = 255)
                self.cd.do(Delay(0.1)+CenteredScale(0,0.7,center)+Delete())
        #self.cd.do(Delay(0.1)+AlphaFade(0,0.9))
        self.secs -= 1

    def collision_player_bonus(self, player, item):
        if item.destroyed:
            return 0
        item.destroyed = True
        item.do(MoveTo(player.big_score.centerx, player.big_score.centery, 1.0))
        item.do(Delay(0.7) + CallFunc(item.destroy))
        player.score += 500
        player.refresh_status()

    def collision_player_life1up(self, player, item):
        if item.destroyed:
            return 0
        item.destroyed = True
        item.do(MoveTo(player.vidas.right, player.vidas.centery, 1.0))
        item.do(Delay(0.7) + CallFunc(item.destroy))
        player.lifes += 1
        player.refresh_status()

    def collision_player_enemy(self, player, item):
        if item.destroyed:
            return 0
        if item.active:
            if not self.player.invencible():
                player.move('hit')
                item.destroy()


    def collision_player_invencibility(self, player, item):
        if item.destroyed:
            return 0
        item.destroy()
        player.score += 500
        player.refresh_status()
        fx = pygame.mixer.Sound(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'supertirititran.ogg'))
        fx.play()
        player.do(Blink(0.25,repeats=20))


    def collision_player_speedup(self, player, item):
        if item.destroyed:
            return 0
        item.destroy()
        pass

    def is_paused(self):
        return not self.cd.deleted or self.paused

    def end_game(self):
        font = GLFont(("NORMT.TTF", SELECTED_RESOLUTION[0]/8),(240,240,20))
        if self.player.lifes == 0:
            self.cd = TextEntity(font, "GAME OVER")
            self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2).place("info")
            self.cd.do(Delay(0.2)+Blink(0.33,repeats = 9)+Show()+Delay(3.3)+CallFunc(self.exit_game))
        elif self.player.floor >= self.escenario.dim[0]:
            self.player.move('winner')
            pygame.mixer.music.fadeout(2500)
            finale = pygame.mixer.Sound(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'victoria.ogg'))
            finale.play()
            finale.set_volume(VOLUME*0.01)
            self.cd = TextEntity(font, "HAS GANADO")
            self.cd.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2).place("info")
            self.cd.do(Delay(0.2)+Blink(0.33,repeats = 9)+show()+Delay(2.0)+CallFunc(self.exit_game))

    def set_previous_scene(self, scene):
        self.previous_scene = scene

    def pause(self):
        if self.paused:
            self.pausedbg.do(Hide())
            self.pausedmsg.do(Hide())
            self.paused = False
            for e in self.interrupted:
                e.close_window(True)
                self.interrupted.remove(e)
        else:
            self.interrupted = []
            for e in self.get_layer("dummy"):
                if isinstance(e, MetaWindow):
                    if e.close_window(False):
                        self.interrupted.append(e)
            self.pausedbg.do(Show())
            self.pausedmsg.do(Show())
            self.paused = True

    def exit_game(self):
        try:
            if self.demo_mode:
                director.run(self)
            elif self.previous_scene:
                if self.wiimote:
                    self.previous_scene.wiimote = self.wiimote
                director.run(self.previous_scene)
            else:
                director.quit()
        except:
            director.quit()

    ## This callback is called by the director on every "realtick"
    ## aka. "engine tick". While frames are drawn as fast as possible,
    ## engine ticks happen at a constant time of FPS times per second.
    def realtick(self):
        debug("Realtick")
        if self.is_paused():
            debug("Juego pausado")
            return 0
        if self.demo_mode:
            debug("Modo demostración")
            self.ia()
        self.handle_wiimote_movements()
        if not self.player.ismoving(): # scroll
            debug("Comprobación de estados")
            if self.player.last_movement == "fall":
                #recolocar
                self.set_player()
            elif isinstance(self.escenario.escenario[-self.player.floor][self.player.window], MetaWindow) and self.escenario.escenario[-self.player.floor][self.player.window].is_closed() and not self.player.invencible():
                self.player.move("fall")
            elif self.player.y < SELECTED_RESOLUTION[1]/4:
                self.escenario.subir(SELECTED_RESOLUTION[1]/2, secs= 0.50)
                self.player.do(MoveDelta(0, SELECTED_RESOLUTION[1]/2, secs= 0.50))
                for e in self.get_layer("city"):
                    e.do(MoveDelta(0,SELECTED_RESOLUTION[1]/20, secs= 0.50))
            elif self.player.y > SELECTED_RESOLUTION[1]*5/6:
                self.escenario.bajar(-self.player.height, secs= 0.25)
                self.player.do(MoveDelta(0, -self.player.height, secs= 0.25))
                for e in self.get_layer("city"):
                    e.do(MoveDelta(0,-self.player.height/20, secs= 0.50))
            elif (self.player.floor >= self.escenario.dim[0] and self.player.manos == 2) or self.player.lifes == 0: # game over
                self.end_game()
            else:
                for e in self.get_layer("dummy"):
                    if isinstance(e, MetaWindow) and not randint(0,2000): # random close window
                        e.close_window(True)
                    elif isinstance(e, MetaWindow) and 'item' in e.entities and isinstance(e.entities['item'], Plant) and e.entities['item'].x in range(int(self.player.x-10),int(self.player.x)+10) and not randint(0,200):
                        e.entities['item'].activate()
        self.netGame_events()
        for e in self.get_layer("weather_b"):
            e.check_bounds()
        for e in self.get_layer("weather_f"):
            e.check_bounds()

    def tick(self):
        try:
            if self.wiimote and self.wiimote.initialized and not self.is_paused() and not self.i :
                self.wiimote.get_status()
            self.i = (self.i+1)%2
        except Exception, inst:
            debug("Error %s en tick(): %s" % (type(inst), inst))

    def set_player(self):
        punto_partida = self.escenario.escenario[-self.player.floor][self.player.window]
        while not punto_partida.isescalable():

            if self.player.floor > 2:
                self.player.floor -= 1
            else:
                self.player.window = (self.player.window + 1) % self.escenario.dim[1]
            punto_partida = self.escenario.escenario[-self.player.floor][self.player.window]
        self.player.set_in_window(punto_partida)

    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            self.demo_mode = False
            self.exit_game()
        elif ev.key == K_p:
            self.pause()
        if self.is_paused():
            return 0
        f, w = self.player.floor, self.player.window
        #print "(%s, %s)" % (f, w)
        stage = self.escenario.escenario
        if ev.key == K_DOWN and (self.player.manos == 1 or (f > 1 and isinstance(stage[-f+1][w], Escalable) and stage[-f+1][w].isescalable())):
            self.player.move('down')
        elif ev.key == K_UP and (self.player.manos == 1 or (f < len(stage) and stage[-f-1][w].isescalable())):
            self.player.move('up_right')
        elif ev.key == K_8 and (self.player.manos == 1 or (f < len(stage) and stage[-f-1][w].isescalable())):
            self.player.move('up_left')
        elif ev.key == K_RIGHT and w < len(stage[1])-1 and stage[-f][w+1].isescalable():
            self.player.move('right')
        elif ev.key == K_LEFT and w > 1 and stage[-f][w-1].isescalable():
            self.player.move('left')

    def handle_joybuttondown(self, ev):
        if self.is_paused():
            return 0
        if ev.button == 3:
            self.demo_mode = False
            self.exit_game()

    def handle_joyaxismotion(self, ev):
        if self.is_paused() or self.demo_mode:
            return 0

        if ev.axis == 3 and ev.value < -0.2:
            self.player.move('up_right')
        elif ev.axis == 1 and ev.value < -0.9:
            self.player.move('up_left')
        elif ev.axis == 0 and ev.value < -0.9:
            self.player.move('left')
        elif ev.axis == 4 and ev.value > 0.8:
            self.player.move('right')

    def handle_wiimote_movements(self):
        if self.is_paused() or self.demo_mode:
            return 0
        if self.wiimote and self.wiimote.initialized:
            #self.wiimote.get_status()
            mov = self.wiimote.get_movement()
            event = None
            if mov == "ll":
                event = pygame.event.Event(KEYDOWN, key = K_LEFT )
            elif mov == "ul":
                event = pygame.event.Event(KEYDOWN, key = K_8 )
            elif mov == "dl":
                event = pygame.event.Event(KEYDOWN, key = K_DOWN )
            elif mov == "rr":
                event = pygame.event.Event(KEYDOWN, key = K_RIGHT )
            elif mov == "ur":
                event = pygame.event.Event(KEYDOWN, key = K_UP )
            elif mov == "dr":
                event = pygame.event.Event(KEYDOWN, key = K_DOWN )
            if event:
                self.handle_keydown(event)

    def ia(self):
        now = pygame.time.get_ticks()
        if now > self.next_movement:
            self.prev_movement = now
            self.next_movement += self.player.auto_move(self.escenario.escenario)
            debug("Next movement at: %.2f" % (self.next_movement/1000.0))

    def netGame_events(self):
        pass

class NetGame(Game):
    init_gamepad()
    nfloors = 20
    columns = 8

    ## Use the RadialCollisions engine, since all our sprites fit
    ## nicely inside a circle.
    collengine = RadialCollisions

    def enter(self):
        debug("Cargando juego en red...")
        Game.enter(self)
        self.enter_netGame()
        debug("Juego en red cargado")

    def set_netFrame(self, net):
        self.netFrame = net

    def set_jugador(self, player):
        self.jugador = player

    def enter_netGame(self):
        debug("Generando el marcador...")
        self.mensaje = TextEntity(GLFont(("NORMT.TTF", 32)), "Juego on-line")
        self.mensaje.set(left=0, bottom=SELECTED_RESOLUTION[1])
        self.player.attach_netclimber(self.jugador)
        juego = self.netFrame.game
        print juego
        if juego:
            for jugador in juego.validPlayers():
                self.clasification.add(jugador)
            self.clasification.update(juego.validPlayers())

    def netGame_events(self):
        debug("Actualizando estado del juego en red")
        juego = self.net.game
        if juego:
            self.clasification.update(juego.validPlayers())
            s = ''
            for p in juego.validPlayers():
                s +="Jugador '%s', %d puntos, %d vidas, %d posicion\n" % (p.color, p.score, p.lifes, p.position)
            print s
            juego.updatePlayer(self.jugador)

def init_gamepad(dev = 0):
    try:
        j = pygame.joystick.Joystick(dev)
    except:
        return 0
    else:
        j.init()

def main():
    screen.init(SELECTED_RESOLUTION, fullscreen= FULLSCREEN, title="Free Climber")
    juego = Game()
    #director.visible_collision_nodes = True
    director.run(juego)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs

if __name__ == "__main__":
    main()
