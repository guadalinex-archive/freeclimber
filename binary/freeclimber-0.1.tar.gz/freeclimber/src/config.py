#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.


#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import pygtk
pygtk.require('2.0')
import gtk
import pygame
import gobject

CONFIG_FILE = '.freeclimber'
VERSION = '0.1'

wiimote = None

# Read Config file
if os.path.exists(os.path.join(os.path.expanduser('~'), CONFIG_FILE)):
   try:
       execfile(os.path.join(os.path.expanduser('~'), CONFIG_FILE))
   except:
       debug("Cargando configuracion original")
       execfile('config.ini')
else:
    execfile('config.ini')

def load_config():
    if os.path.exists(os.path.join(os.path.expanduser('~'), CONFIG_FILE)):
        try:
            execfile(os.path.join(os.path.expanduser('~'), CONFIG_FILE))
            return 1
        except:
            debug("Cargando configuracion original")
    execfile('config.ini')


def get_game_resolution():
    return RESOLUTIONS[ASPECT][DETAIL]

def debug(msg):
    if "--debug" in sys.argv:
        print "[%.3f] %s" % (pygame.time.get_ticks()/1000.0, msg)

def available_controllers():
    controllers = ['keyboard',]
    try:
        import cwiid
    except:
        pass
    else:
        controllers.append('IR controller')
    try:
        pygame.init()
    except:
        pass
    else:
        pygame.joystick.init()
        n = pygame.joystick.get_count()
        for i in range(n):
            j = pygame.joystick.Joystick(i)
            j.init()
            if j.get_numaxes() > 4:
                controllers.append('joystick'+str(i))
    return controllers


class Configurator:

    def __init__(self):
        self.window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.window.set_title("Configurador Freeclimber")
        self.window.connect("delete_event", self.delete_event)
        self.window.connect("destroy", self.destroy)
        self.window.set_border_width(10)

        secciones = gtk.VBox(False, 10)

        #graficos
        p1 = gtk.VBox(True,2)
        p1.pack_start(gtk.Label('Resolucion del juego'))
        p1.pack_start(gtk.Label('Resolucion actual'))
        p1.pack_start(gtk.Label('Relacion aspecto del juego'))
        p1.pack_start(gtk.Label('Relacion de aspecto actual'))
        p1.pack_start(gtk.Label('Imagenes por segundo (fps)'))
        p1.pack_start(gtk.Label('Modo pantalla'))

        p2 = gtk.VBox(True,2)
        self.res = gtk.combo_box_new_text()
        for d, r in RESOLUTIONS[ASPECT].iteritems():
            self.res.append_text("%s: %dx%d" % (d, r[0], r[1]))
        if DETAIL == "high":
            self.res.set_active(0)
        elif DETAIL == "medium":
            self.res.set_active(1)
        elif DETAIL == "low":
            self.res.set_active(2)
        self.res.connect("changed", self.active_apply)
        p2.pack_start(self.res)
        actual = get_screen_resolution()
        if actual:
            p2.pack_start(gtk.Label("%dx%d" % (actual[0], actual[1])))
        else:
            p2.pack_start(gtk.Label("Desconocida (python-xlib no instalado)"))
        self.aspect = gtk.combo_box_new_text()
        for a in RESOLUTIONS.keys():
            self.aspect.append_text(a)
        if ASPECT == "4:3":
            self.aspect.set_active(0)
        elif ASPECT.endswith("16:9"):
            self.aspect.set_active(3)
        elif ASPECT.endswith("16:10"):
            self.aspect.set_active(4)
        elif ASPECT.endswith("9:16"):
            self.aspect.set_active(1)
        elif ASPECT.endswith("10:16"):
            self.aspect.set_active(2)
        else:
            pass
        self.aspect.connect("changed", self.update)
        p2.pack_start(self.aspect)
        p2.pack_start(gtk.Label(get_aspect_relation()))

        adjustment  =  gtk.Adjustment(value=FPS, lower=30, upper=60, step_incr=5, page_incr=10, page_size=0)
        adjustment.emit("changed")
        self.fps_bar = gtk.HScale(adjustment)
        adjustment.connect("value-changed", self.active_apply)
        self.fps_bar.set_digits(0)
        p2.pack_start(self.fps_bar)
        self.fullscreen = gtk.CheckButton("Jugar a pantalla completa")
        self.fullscreen.set_active(FULLSCREEN)
        self.fullscreen.connect("clicked", self.active_apply)
        p2.pack_start(self.fullscreen)

        p = gtk.HBox(True, 2)
        p.pack_start(p1)
        p.pack_start(p2)

        pantalla = gtk.Frame("Opciones de pantalla:")
        pantalla.add(p)

        #control
        c1 = gtk.VBox(True,2)
        c1.pack_start(gtk.Label('Tipo de controlador'))
        c2 = gtk.VBox(True,2)
        self.controllers = gtk.combo_box_new_text()
        for c in available_controllers():
            self.controllers.append_text(c)
        self.controllers.set_active(0)

        self.controllers.connect("changed", self.active_apply)
        c2.pack_start(self.controllers)
        c2.pack_start(gtk.Button('Configurar'))

        c = gtk.HBox(True,2)
        c.pack_start(c1)
        c.pack_start(c2)

        control = gtk.Frame('Opciones de control')
        control.add(c)

        #sonido
        s1 = gtk.VBox(True,2)
        s1.pack_start(gtk.Label('Volumen'))
        s1.pack_start(gtk.Label('Stereo'))
        s2 = gtk.VBox(True,2)
        adjustment2  =  gtk.Adjustment(value=VOLUME, lower=0, upper=100, step_incr=10, page_incr=10, page_size=0)
        adjustment2.emit("changed")
        self.volume = gtk.HScale(adjustment2)
        adjustment2.connect("value-changed", self.active_apply)
        self.volume.set_digits(0)
        s2.pack_start(self.volume)
        self.stereo = gtk.CheckButton("Habilitar sonido stereo")
        self.stereo.set_active(STEREO)
        self.stereo.connect("clicked", self.active_apply)
        s2.pack_start(self.stereo)

        s = gtk.HBox(True,2)
        s.pack_start(s1)
        s.pack_start(s2)

        sonido = gtk.Frame('Opciones de sonido')
        sonido.add(s)

        #botones
        botones = gtk.HBox(True,2)
        self.aceptar = gtk.Button(stock=gtk.STOCK_APPLY)
        self.aceptar.connect("clicked", self.apply)
        self.aceptar.set_sensitive(False)
        self.jugar = gtk.Button("Jugar")
        self.jugar.connect("clicked", self.destroy, "play")
        self.cancelar = gtk.Button(stock=gtk.STOCK_QUIT)
        self.cancelar.connect("clicked", self.destroy)
        botones.pack_start(self.aceptar)
        botones.pack_start(self.jugar)
        botones.pack_start(self.cancelar)

        secciones.pack_start(gtk.Label("OPCIONES DE CONFIGURACION"))
        secciones.pack_start(pantalla)
        secciones.pack_start(control)
        secciones.pack_start(sonido)
        secciones.pack_start(botones)

        self.window.add(secciones)
        self.window.show_all()

    def delete_event(self, widget, event, data=None):
        return gtk.FALSE

    def destroy(self, widget, data=None):
        gtk.main_quit()
        if data == "play":
            import freeclimber
            freeclimber.main()

    def apply(self, widget, data=None):
        widget.set_sensitive(False)
        model = self.res.get_model()
        active = self.res.get_active()
        if active < 0:
            pass
        DETAIL = model[active][0].split(':')[0]
        model = self.aspect.get_model()
        active = self.aspect.get_active()
        if active < 0:
            pass
        ASPECT = model[active][0]
        model = self.controllers.get_model()
        active = self.controllers.get_active()
        if active < 0:
            pass
        CONTROLLER = model[active][0]
        FPS = self.fps_bar.get_adjustment().get_value()
        STEREO = self.fullscreen.get_active()
        VOLUME = self.volume.get_adjustment().get_value()
        STEREO = self.stereo.get_active()
        FULLSCREEN = self.fullscreen.get_active()
        try:
            f = open(('config.ini'),'r')
            conf = f.read()
            f.close()
        except:
            debug("Fallo al leer el fichero de configuracion")
        else:
            try:
                f = open(os.path.join(os.path.expanduser('~'), CONFIG_FILE),'w')
                for l in conf.split('\n'):
                    if l.startswith('ASPECT'):
                        l = "ASPECT = '%s'" % ASPECT
                    elif l.startswith('FPS'):
                        l = "FPS = %s" % FPS
                    elif l.startswith('FULLSCREEN'):
                        l = "FULLSCREEN = %s" % FULLSCREEN
                    elif l.startswith('DETAIL'):
                        l = "DETAIL = '%s'" % DETAIL
                    elif l.startswith('VOLUME'):
                        l = "VOLUME = %s" % VOLUME
                    elif l.startswith('STEREO'):
                        l = "STEREO = %s" % STEREO
                    elif l.startswith('CONTROLLER'):
                        l = "CONTROLLER = '%s'" % CONTROLLER
                    f.write(l + '\n')
                f.close()
            except:
                debug("Fallo al escribir la nueva configuracion")

    def active_apply(self, widget):
        self.aceptar.set_sensitive(True)

    def update(self, widget, data=None):
        model = widget.get_model()
        active = widget.get_active()
        if active < 0:
            return None
        new_aspect = model[active][0]
        liststore = gtk.ListStore(gobject.TYPE_STRING)
        self.res.set_model(liststore)
        for d, r in RESOLUTIONS[new_aspect].iteritems():
            self.res.append_text("%s: %dx%d" % (d, r[0], r[1]))
        if DETAIL == "high":
            self.res.set_active(0)
        elif DETAIL == "medium":
            self.res.set_active(1)
        elif DETAIL == "low":
            self.res.set_active(2)
        self.active_apply(None)

    def main(self):
        gtk.main()


if __name__ == "__main__":
    #load_config()
    conf = Configurator()
    conf.main()
