PyGame Extended
---------------
The 'pygext' package is a collection of game related libraries ranging from opengl-accelerated sprites to sound generation. It is meant to provide a more high level framework on top of PyGame so that game makers can concentrate on the game itself instead of reinventing the common stuff.

Dependencies
------------
In order to use all modules of the pygext package, you need the following Python extensions

PyGame (http://www.pygame.org/)
PyOpenGL (http://pyopengl.sf.net/)
Numeric (http://numpy.sf.net/)
Polygon (http://english.dezentral.de/soft/Polygon/index.html)


Installation
------------
> python setup.py install