"""Pygame Extended - a collection of game creation utilities

Currently, the most fully featured package is pygext.gl, which
contains a full, OpenGL-accelerated game framework. The other
packages are a lot thinner and mostly contain small, miscellanous
helper functions.

XXX TODO: short description of each sub-package here.
"""
__version__ = "0.9.5"
