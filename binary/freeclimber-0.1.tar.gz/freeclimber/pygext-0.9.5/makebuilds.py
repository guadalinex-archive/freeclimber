import os

os.system("""setup.py sdist --formats=gztar""")
os.system("""setup.py bdist_wininst""")
