##
## Pygext example game for testing point-and-click UI
## XXX: still completely unfinished
##

import setpath
import Numeric as N

import pygame
from pygame.locals import *

import pygext
from pygext.gl.all import *

import random

STARSIZE = 32
RESOLUTION = (800,600)
STARCOLORS = [
    (200,0,0),
    (255,255,100),
    (100,255,100),
    (0,0,250),
    ]

def generate_images():
    import pygext.render.utils as r
    sz = STARSIZE
    sz2 = STARSIZE // 2
    d = r.dist_array(sz,sz)
    x,y = r.xy_arrays(sz,sz)
    xd = (x - sz2) ** 2 + 1
    yd = (y - sz2) ** 2 + 1
    a = 1.0 / (d + N.where(xd<yd, xd,yd))
    a = r.cut_array(a, maxvalue=0.3)
    a = r.scale_to_01(a)
    a *= 255
    s = r.make_stencil(a)
    resources.init_bitmap("star_stencil", s).set_hotspot(0.5,0.5)

    from pygext.render.rects import rounded_hollow_rect
    s = rounded_hollow_rect((255,255,255), (STARSIZE+16,STARSIZE+16), 6, 2)
    resources.init_bitmap("select_box", s).set_hotspot(0.5,0.5)
    

class Star(object):
    def __init__(self, x, y, color):
        e = self.entity = Entity("star_stencil")
        e.set(x=x, y=y, color=color)

class StarMap(object):
    def __init__(self):
        self.stars = {}

    def add_star(self, x, y, color):
        s = Star(x,y,color)
        self.stars[(x,y)] = s
        return s
    
    def pick(self, px, py):
        sz = STARSIZE + 8
        sz2 = sz // 2
        for x,y in self.stars:
            if Rect(x-sz2,y-sz2, sz, sz).collidepoint(px,py):
                return self.stars[x,y]


class SpaceGame(object):
        
    def new_game(self):
        self.starmap = StarMap()
        self.generate_map()

    def generate_map(self):
        starmap = self.starmap

        sectors = {}
        
        for sx in range(5):
            for sy in range(5):
                x = sx * 100 + 60 + random.randrange(70)
                y = sy * 90 + 70 + random.randrange(70)
                sectors[sx,sy] = x,y
                color = random.choice(STARCOLORS)
                star = starmap.add_star(x,y,color)

        for i in range(18):
            sx = random.randrange(5)
            sy = random.randrange(5)
            if (sx,sy) in sectors:
                x,y = sectors.pop((sx,sy))
                del starmap.stars[x,y]

        for star in starmap.stars.itervalues():
            star.entity.place("stars")

class MainScene(Scene):

    def enter(self, game):
        self.new_layer("stars", 0)
        self.new_layer("gui1", 10)
        self.new_layer("gui2", 15)
        
        self.game = game
        self.game.new_game()

        self.cursor = Entity("select_box")        
        self.cursor.color = (0,200,0,0)
        self.cursor.place("gui1")        
        self.selected = None

        glmouse.pointer = glmouse.default_pointer
        self.init_gui()

    def init_gui(self):
        gui_top = Entity("gfx/spacegui_top.png")
        gui_left = Entity("gfx/spacegui_left.png")
        gui_bottom = Entity("gfx/spacegui_bottom.png")
        gui_right = Entity("gfx/spacegui_right.png")

        gui_left.place("gui2").set(left=0,top=0)
        gui_top.place("gui2").set(top=0, left=gui_left.right)
        gui_bottom.place("gui2").set(bottom=600, left=gui_left.right)
        gui_right.place("gui2").set(top=0,left=gui_bottom.right)

    def handle_mousebuttondown(self, ev):
        x,y = pygame.mouse.get_pos()
        star = self.game.starmap.pick(x,y)
        if star is None or star is self.selected:
            return
        e = star.entity
        c = self.cursor
        c.alpha = 0
        c.scale = 1.8
        c.abort_actions()
        c.set(x=e.x, y=e.y)
        c.do(AlphaFade(150, 0.2))
        c.do(Scale(1.0, 0.2))

def main():
    screen.init(RESOLUTION, (800,600), fullscreen=False, title="Space4X Example")
    generate_images()
    game = SpaceGame()
    director.run(MainScene, game)

if __name__ == '__main__':
    main()
