
import setpath
from pygext.gl.test import Test
from pygext.gl.vector.primitives import *
from pygext.gl.shapes import draw_shape

class PrimitiveTest(Test):
    def init(self):
        p1 = rect(50,50).fillcolor(255,0,0)
        p2 = p1.copy().linecolor(255,255,255)
        p3 = p2.copy().linewidth(10).lineantialias(True)
        p4 = p1.copy().hollow(10)
        p5 = p4.copy().linecolor(255,255,255)
        p6 = p1.copy().hollow(20).hollow(5)
        p7 = p5.copy().linecolor(255,255,255)
        p8 = polycut(p1, p4.translate(10,10)).fillcolor(255,255,0)
        p9 = p2.copy().fillcolor(None)
        pA = p9.copy().linestipple(1, 0xf0f0)
        pB = pA.copy().linewidth(3)
        pC = p1.copy().translate(60,20)
        pD = p1.copy().fillcolor(0,0,255,100)
        self.p = [p1,p2,p3,p4,p5,p6,p7,p8,p9,pA,pB,pC,pD]
        

    def render(self):
        x = 50
        y = 200
        for p in self.p:
            draw_shape(p, x, y)
            x += 80
            if x > 750:
                x = 50
                y += 80

PrimitiveTest().mainloop()
