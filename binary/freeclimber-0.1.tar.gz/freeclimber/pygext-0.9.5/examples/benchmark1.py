"""This benchmark tests framerates with a high number of static entities"""

import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()

from pygext.gl.all import *

class BenchScene(Scene):
    def enter(self):
        self.new_layer("entities")
        for x in range(40):
            for y in range(30):
                Entity("gfx/ball.png").set(x=x*20,y=y*20).place("entities")

    def handle_keydown(self, ev):
        director.quit()


screen.init((800,600))
director.run(BenchScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
