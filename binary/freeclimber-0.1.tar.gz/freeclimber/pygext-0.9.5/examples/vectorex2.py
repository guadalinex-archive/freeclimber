
import setpath
from pygext.gl.test import Test
from pygext.gl.vector.primitives import *
from pygext.gl.shapes import draw_shape


class TransformTest(Test):
    def init(self):
        p1 = rect(50,50).fillcolor(255,0,0).linecolor(255,255,255)
        p2 = p1.copy().rotate(45)
        p3 = p1.copy().scale(0.7)
        p4 = p1.copy().translate(0,-25)
        p5 = p1.copy().skewx(0.5)
        p6 = p1.copy().skewy(0.3)
        p7 = p1.copy().rotate(45).scale(0.5,1.5)
        p8 = p1.copy().scale(0.5).translate(40,0).rotate(50)
        self.p = [p1,p2,p3,p4,p5,p6,p7,p8]

    def render(self):
        x = 50
        y = 200
        for p in self.p:
            draw_shape(p, x, y)
            x += 80
            if x > 750:
                x = 50
                y += 80

TransformTest().mainloop()
