
import setpath
from pygext.gl.test import Test
from pygext.gl.vector.primitives import *
from pygext.gl.shapes import draw_shape


class BooleanTest(Test):
    def init(self):
        p = rect(50,50).fillcolor(255,0,0).linecolor(255,255,255)
        p1 = polyjoin(p.copy().translate(-10,-10), p.copy().translate(10,10)).fillcolor(255,0,0).linecolor(255,255,255)
        p2 = polycut(p.copy(), p.copy().rotate(45).translate(25,0)).fillcolor(255,0,0).linecolor(255,255,255)
        p3 = polyjoin(p2,
                      polyfit(p.copy().rotate(45).translate(40,0), p)
                      ).fillcolor(255,0,0).linecolor(255,255,255)
        self.p = [p1, p2, p3]

    def render(self):
        x = 50
        y = 200
        for p in self.p:
            draw_shape(p, x, y)
            x += 80
            if x > 750:
                x = 50
                y += 80

BooleanTest().mainloop()

