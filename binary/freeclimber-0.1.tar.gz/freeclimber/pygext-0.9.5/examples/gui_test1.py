
from pygext.gl.all import *

class GUIScene(Scene):
    def enter(self):
        self.new_layer("text")
        
        root = director.init_gui()
        self.font = font = GLFont(("arial", 16))
        glmouse.pointer = glmouse.default_pointer
        
        panel = gui.Panel(root)
        panel.set(
            x=50,y=50,
            width=300, height=200
            )
        
        button = gui.Button(panel, font=font, label="Click me!")
        button.set(
            top = 5,
            left = 5,
            width = 150,
            height = 40,
            on_click = self.button1click,
            )

        button2 = button.copy()
        button2.set(
            left = button.left,
            top = button.bottom+5,
            bgcolor = (100,200,100),
            on_click = self.button2click,
        )

        button3 = button.copy().set(width=100)
        button3.set(
            right = panel.width-5,
            bottom = panel.height-5,
            label = "Quit",
            on_click = director.quit,
            )

        panel2 = gui.ImagePanel(root, image="gfx/woodpanel.png")
        panel2.set(
            x=panel.x, y=panel.bottom + 10
            )
        button = gui.Button(panel2, font=font, label="Wooden")
        button.set(
            top = 10, left = 10,
            width = 150,
            height = 40,
            )

        panel3 = gui.BorderPanel(root)
        panel3.set(
            top = panel.top - 20,
            left = panel.right - 70,
            width = 250,
            height = 150,
            bgcolor = (37,178,176),
            bgoffset = 18,
            )
        panel3.extract_borders("gfx/panel.png", (18,18))
##        panel3.set_images(
##            top = "gfx/panel_top.png",
##            bottom = "gfx/panel_bottom.png",
##            left = "gfx/panel_left.png",
##            right = "gfx/panel_right.png",
##            topleft = "gfx/panel_topleft.png",
##            topright = "gfx/panel_topright.png",
##            bottomleft = "gfx/panel_bottomleft.png",
##            bottomright = "gfx/panel_bottomright.png",
##            )
        button = gui.Button(panel3, font=font, label="Custom")
        button.set(
            top = 20, left = 20,
            width = 100,
            height = 40,
            )

    def button1click(self):
        e = TextEntity(self.font, "Button 1 clicked!")
        e.set(left=10, bottom=0).place("text")
        e.do(Move(0,200).limit(time=4) + Delete)
        
    def button2click(self):
        e = TextEntity(self.font, "Button 2 clicked!")
        e.set(right=0,top=300,color=(0,255,0)).place("text")
        e.do(Move(300,0).limit(time=4) + Delete)

screen.init((800,600), title="Pygext GUI Test")
director.run(GUIScene)
