
import textile
import os, sys, shutil, re
import pygext
version = pygext.__version__

INPUT = "tutsrc"
OUTPUT = "tutorials"

HTML = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html>

<head>
    <title>%s</title>
    
    <link rel="stylesheet" href="docstyle.css" type="text/css" media="screen"/>
</head>

<body>
%s
</body>
</html>"""

def convert():
    l = os.listdir(INPUT)
    for fn in l:
        if not fn.endswith(".txt"):
            continue
        print "Converting",fn
        ifn = os.path.join(INPUT, fn)
        txt = open(ifn, "rU").read()
        tags = re.findall(r"\%\%\%\((.*?)\)\%\%\%", txt)
        for t in tags:
            tag = "%%%%%%(%s)%%%%%%" % t
            contents = open(t, "rU").read()
            txt = txt.replace(tag, contents.strip())
        htmlf = textile.textile(txt)
        htmlf = htmlf.replace("\n</pre>", "</pre>")
        htmlf = htmlf.replace("\n</code>", "</code>")
        f = open(os.path.join(OUTPUT, fn[:-4]+".html"), "wU")
        f.write(HTML % ("PygExt %s Tutorial" % version, htmlf))
        f.close()

if __name__ == '__main__':
    convert()
    shutil.copy2(os.path.join(INPUT, "docstyle.css"), OUTPUT)
