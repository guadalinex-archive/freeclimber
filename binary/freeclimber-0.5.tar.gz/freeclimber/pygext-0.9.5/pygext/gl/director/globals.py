
from pygext.gl.director.base import Director

__all__ = [
    'director',
    ]

director = Director()
