#!/usr/bin/env python

from pygext.gl.vector.editor import Editor

Editor().mainloop()
