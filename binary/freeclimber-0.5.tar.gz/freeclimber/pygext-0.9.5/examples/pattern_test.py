
from pygext.gl.all import *

class PatternScene(Scene):
    def enter(self):
        self.new_layer("pattern")
        shape = PatternImage("gfx/invader1.png", xsize=400, ysize=300)
        Entity(shape).place("pattern").set(x=100,y=100)

    def handle_keydown(self, ev):
        director.quit()

screen.init((800,600))
director.run(PatternScene)
