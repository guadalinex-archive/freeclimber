## a simple turn-based strategy example
## XXX WORK IN PROGRESS, DOES NOTHING YET

RESOLUTION = (800,600)
FULLSCREEN = False

from pygext.gl.all import *

class Unit(Entity):
    image = None
    maxhp = 0
    move = 0
    damage = 0

    def __init__(self):
        Entity.__init__(self, self.image)
        self.hp = self.maxhp


class Knight(Unit):
    image = "gfx/knight.png"
    maxhp = 100
    move = 3
    damage = 25

class Orc(Unit):
    image = "gfx/orc.png"
    maxhp = 50
    move = 4
    damage = 20


class MapTile(Entity):
    image = None
    movecost = 1

class Grass(MapTile):
    image = "gfx/grasstile.png"
    movecost = 1

class Game(object):
    def __init__(self):
        screen.init(RESOLUTION, (1600,1200), fullscreen=FULLSCREEN, title="Pygext Strategy")

class MainScene(Scene):
    def init(self):
        pass

    def enter(self):
        tilemap = EntityGroup()
        glmouse.pointer = glmouse.default_pointer
        ## TODO: tile map
        ## TODO: characters
