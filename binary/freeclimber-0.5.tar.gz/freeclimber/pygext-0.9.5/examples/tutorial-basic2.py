from pygext.gl.all import *
from pygame.locals import *  # key constants

class HelloWorld(Scene):
    def init(self):
        self.font = GLFont(("arial", 20))      
        self.new_layer("text")

    def enter(self):      
        text = TextEntity(self.font, "What's your name?", scale=2)
        text.set(centerx=400, centery=300).place("text")

        ## Create a text input widget
        input = TextInputEntity(self.font, scale=2, maxlen=20)
        input.set(left=text.left, top=text.bottom).place("text")
        self.input = input

        ## Set current state of the scene
        self.set_state("ask")

    ## Handler for the "ask" state
    def state_ask_handle_keydown(self, event):
        if event.key == K_RETURN:
            self.greet()
        else:
            self.input.handle_keydown(event)

    def greet(self):
        ## Change to a new state
        self.set_state("greet")
        
        ## Clear the text layer
        self['text'].clear()

        ## Insert the greeting text
        text = TextEntity(self.font, "Hello, %s!" % self.input.text, scale=2)
        text.set(centerx=400, centery=300).place("text")
        
    ## Default handler for all states that don't have their specialized handler
    def handle_keydown(self, event):
        director.quit()

screen.init((800,600))
director.run(HelloWorld)
