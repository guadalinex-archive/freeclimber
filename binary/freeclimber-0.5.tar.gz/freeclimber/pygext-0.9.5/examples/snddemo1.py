# sound demos

import setpath
import time
from pygext.sound.generate import *

def playwait(s):
    c = s.play()
    while (c.get_busy()):
        time.sleep(0.1)
    

##snd = make(sinewave(5000, 0.01, 10))
##playwait(snd)
##snd = make(sinewave(5000, 0.02, 30))
##playwait(snd)
##snd = make(sinewave(5000, 0.03, 100))
##playwait(snd)

#snd = concat(linear(5000, 50, 60, 150), linear(5000, 60, 55, 150))
snd = linear(10000, 30, 30, 150)
add_cos(snd, 0.5, 20)
add_noise(snd, 50)
add_fadein(snd, 100)
add_fadeout(snd, 9900)
playwait(make(snd))
