"""This benchmark tests framerates with a high number entities with several actions"""

import sys

if "psyco" in sys.argv:
    import psyco
    psyco.full()

from pygext.gl.all import *

class BenchScene(Scene):
    def enter(self):
        self.new_layer("entities")
        act = Rotate(100)
        act2 = Scale(1.0, secs=0.5, mode=PingPongMode)
        act3 = AlphaFade(100, secs=1.0, mode=PingPongMode)
        for x in range(26):
            for y in range(20):
                e = Entity("gfx/invader1.png", hotspot=(0.5,0.5))
                e.scale = 0.3
                e.set(x=x*30,y=y*30).place("entities")
                e.do(act)
                e.do(act2)
                e.do(act3)
                

    def handle_keydown(self, ev):
        director.quit()


screen.init((800,600))
director.run(BenchScene)
print "ticks per sec", director.ticks/director.secs
print "realticks per sec", director.realticks/director.secs
