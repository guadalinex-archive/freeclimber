import os
import pygext
version = pygext.__version__

os.system("""epydoc.py -o apidoc -n "PygExt %s" -u http://codereactor.net/projects/pygext/ --no-private --ignore-param-mismatch --no-frames --debug pygext""" % version)
