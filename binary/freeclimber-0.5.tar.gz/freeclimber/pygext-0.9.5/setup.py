#!/usr/bin/env python

from pygext import __version__ as VERSION

TROVE = """
Development Status :: 3 - Alpha
Environment :: MacOS X
Environment :: Win32 (MS Windows)
Environment :: X11 Applications
Intended Audience :: Developers
License :: OSI Approved :: MIT License
Operating System :: OS Independent
Programming Language :: Python
Topic :: Games/Entertainment
Topic :: Multimedia
Topic :: Software Development :: Libraries :: Application Frameworks
Topic :: Software Development :: Libraries :: Python Modules
Topic :: Software Development :: User Interfaces
"""

DESCRIPTION = \
"""Pygame Extended (or pygext) is my "everything and a kitchen sink" collection
of libraries for Pygame development. The main part of pygext, is the OpenGL
accelerated 2D framework (pygext.gl) for rendering and controlling sprites.
Pygext also contains additions to pygame.draw (e.g. rectangles with
round corners) and an opengl accelerated 2D vector graphics library
(experimental).

Pygext is currently 100% pure Python, so parts of it might still be a bit
slow on less than high end PCs. However, I've tried to design the code to
be as psyco-friendly as possible, so you will see quite a noticeable
difference with psyco enabled. Remember to add import psyco; psyco.profile()
at the beginning of your applications.

Main Features

* Use layers to control rendering order (unlimited layers per scene)
* Sprites you can rotate, scale and alpha blend
* Sprites can be attached to each other for synchronized movement
* Framerate independent animation and movement
* Control sprites via "Actions" instead of manually updating coordinates every frame
* Fully featured particle effects
* Collision detection
* Scenes and states for structuring game logic

NOTE: this release of pygext is still alpha, so there will be backward
incompatible API changes and refactoring in future versions."""

import os, sys
from distutils.core import setup

def find_site():
    for p in sys.path:
        if p.endswith("site-packages"):
            return p

def find_packages():
    packages = []
    for dirpath, dirnames, filenames in os.walk('pygext'):
        if '__init__.py' in filenames:
            package = dirpath.replace(os.path.sep, '.')
            print package
            packages.append(package)
    return packages

def get_libfiles(dir, ext):
    files = [os.path.join(dir,x) for x in os.listdir(dir)
             if os.path.splitext(x)[1] == ext]
    dir = os.path.join(find_site() ,dir)
    #print (dir,files)
    return (dir, files)
    
classifiers = filter(None, TROVE.split("\n"))

setup(
    name = "pygext",
    version = VERSION,
    description = "Pygame Extended: OpenGL accelerated 2D game programming framework",
    long_description = DESCRIPTION,
    author = "Sami Hangaslammi",
    author_email = "shang@iki.fi",
    maintainer = "Sami Hangaslammi",
    maintainer_email = "shang@iki.fi",
    packages = find_packages(),
    scripts = ["vecedit.py"],
    url = "http://codereactor.net/projects/pygext/",
    download_url = "http://codereactor.net/projects/pygext/pygext-%s.tar.gz" % VERSION,
##    data_files = [
##        get_libfiles("pygext/gl/vector/editor/gfx", ".png"),
##        get_libfiles("pygext/gl", ".png"),
##        ],
    package_data = {
        'pygext.gl.vector.editor': ['gfx/*.png'],
        'pygext.gl':['*.png'],
        },
    classifiers = classifiers,
    )
