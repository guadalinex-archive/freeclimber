#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
from config import *
import time

try:
    import cwiid
    import stats
except ImportError:
    pass

## Import psyco if available
from pygame.locals import *
try:
    import psyco
except ImportError:
    pass
else:
    from psyco.classes import *
    psyco.full()

#from threading import Thread
from pygext.gl.all import *
from pygext.render.halo import halocircle
from time import sleep


SELECTED_RESOLUTION = get_game_resolution()

class Lhand(Entity):

    image = os.path.join(LINUX_GAME_PATH, 'images',"common", "lhand.png")
    layer = "points"

    def init(self, pos, escala=1):
        self.colocate(pos, escala)

    def animate(self):
        self.do(Scale(0, 0.33))
        self.do(AlphaFade(0, 0.33)+Delete())

    def colocate(self, pos, escala = 1):
        xscale = SELECTED_RESOLUTION[0]/float(cwiid.IR_X_MAX)
        yscale = SELECTED_RESOLUTION[1]/float(cwiid.IR_Y_MAX)
        self.set(centerx = int(pos[0]*xscale), centery = int(pos[1]*yscale), scale = escala)

class Rhand(Entity):

    image = os.path.join(LINUX_GAME_PATH, 'images', "common","rhand.png")
    layer = "points"

    def init(self, pos, escala=1):
        self.colocate(pos, escala)

    def animate(self):
        self.do(Scale(0, 0.33))
        self.do(AlphaFade(0, 0.33)+Delete())

    def colocate(self, pos, escala = 1):
        xscale = SELECTED_RESOLUTION[0]/float(cwiid.IR_X_MAX)
        yscale = SELECTED_RESOLUTION[1]/float(cwiid.IR_Y_MAX)
        self.set(centerx = int(pos[0]*xscale), centery = int(pos[1]*yscale), scale = escala)

class IRreceptor(cwiid.Wiimote):

    def __init__(self):
        debug("Buscando wiimote")
        cwiid.Wiimote.__init__(self, WIIMOTE)
        #self.wiimote = None
        self.connecting = False
        self.rpt_mode=9
        self.initialized = isinstance(self, cwiid.Wiimote)
        self.enable(cwiid.FLAG_CONTINUOUS | cwiid.FLAG_NONBLOCK)
        self.tries = 5
        self.draw_hands()
        self.lefthand_x = CircleList(int(director.ticker.resolution)/2)
        self.righthand_x = CircleList(int(director.ticker.resolution)/2)
        self.lefthand_scale = CircleList(int(director.ticker.resolution)/2)
        self.righthand_scale = CircleList(int(director.ticker.resolution)/2)
        self.lefthand_y = CircleList(int(director.ticker.resolution)/2)
        self.righthand_y = CircleList(int(director.ticker.resolution)/2)
        self.last_movement = None
        #self.state = None
        self.leds = (1,2,4,8,4,2)
        self.l = 0
        self.last_led = pygame.time.get_ticks()
        self.last = pygame.time.get_ticks()
        self.low_battery_alert = None


    def draw_hands(self):
        self.left = Lhand(pos=(cwiid.IR_X_MAX/3,cwiid.IR_Y_MAX*2/3))
        self.right = Rhand(pos=(cwiid.IR_X_MAX*2/3,cwiid.IR_Y_MAX*2/3))

    def get_status(self):
        if not self.initialized:
            return 0
        if director.ticker.now >= self.last_led+750:
            try:
                self.led = int(self.leds[int(self.l%len(self.leds))])
            except:
                debug("Error al cambiar el estado de los led's del Wiimote")
            self.last_led = director.ticker.now
            self.l += 1
            if not self.l%40:
                debug("Ajustando modo...")
                try:
                    self.rpt_mode=9
                except:
                    debug("Error al cambiar el modo del Wiimote")
            debug("Actualizando estado IR...")
            self.request_status()
        if self.state:
            if self.state['error']:
                debug("Error en el wiimote")
            if self.state['battery']*100/cwiid.BATTERY_MAX <= 10 and not self.low_battery_alert:
                self.low_battery_alert = Entity(os.path.join(LINUX_GAME_PATH, 'images',"common", "battery-alert.png"))
                self.low_battery_alert.set(scale=SELECTED_RESOLUTION[0]/float(self.low_battery_alert.width*10))
                self.low_battery_alert.set(right = SELECTED_RESOLUTION[0], bottom = SELECTED_RESOLUTION[1]).place("info")
                self.low_battery_alert.do(Blink(1.0))
            #debug(self.wiimote.state['ir_src'])
            tmp_lhand = (cwiid.IR_X_MAX/2, cwiid.IR_Y_MAX/2)
            tmp_lscale = 9
            tmp_rhand = (cwiid.IR_X_MAX/2, cwiid.IR_Y_MAX/2)
            tmp_rscale = 9
            for ir_src in self.state['ir_src']:
                if ir_src and ir_src['pos'] < tmp_lhand:
                    tmp_lhand = ir_src['pos']
                    tmp_lscale = ir_src['size']
                    debug ("Mano izquierda: (%d,%d)" % tmp_lhand)
                if ir_src and ir_src['pos'] >= tmp_rhand:
                    tmp_rhand = ir_src['pos']
                    tmp_rscale = ir_src['size']
                    debug ("Mano derecha: (%d,%d)" % tmp_rhand)

            if tmp_rscale < 9:
                self.righthand_x.append( tmp_rhand[0])
                self.righthand_y.append( tmp_rhand[1])
                self.righthand_scale.append(tmp_rscale)
            if tmp_lscale < 9:
                self.lefthand_x.append( tmp_lhand[0])
                self.lefthand_y.append( tmp_lhand[1])
                self.lefthand_scale.append(tmp_lscale)

            self.left.colocate(pos=self.get_left_hand(), escala=1.0/(8-stats.lmean(self.lefthand_scale)))
            self.right.colocate(pos=self.get_right_hand(), escala=1.0/(8-stats.lmean(self.righthand_scale)))
            return self.state


    def get_left_hand(self):
        return (stats.lmean(self.lefthand_x), stats.lmean(self.lefthand_y))

    def get_right_hand(self):
        return (stats.lmean(self.righthand_x), stats.lmean(self.righthand_y))

    def get_movement(self):
        lpos = self.get_left_hand()
        rpos = self.get_right_hand()
        movement = None

        if lpos[0]<H and lpos[1] > cwiid.IR_Y_MAX/3 and lpos[1] < cwiid.IR_Y_MAX*2/3:
            movement = "ll"
        elif lpos[1]<V and lpos[0] > cwiid.IR_X_MAX/7 and lpos[0] < cwiid.IR_X_MAX*3/7:
            movement = "ul"
        elif lpos[1]>cwiid.IR_Y_MAX-V and lpos[0] > cwiid.IR_X_MAX/7 and lpos[0] < cwiid.IR_X_MAX*3/7:
            movement = "dl"

        #print "Mano derecha: (%d,%d)" % rpos
        if rpos[0]>cwiid.IR_X_MAX-V and rpos[1]>cwiid.IR_Y_MAX/3 and rpos[1] < cwiid.IR_Y_MAX*2/3:
            movement = "rr"
        elif rpos[1]<H and rpos[0] > cwiid.IR_X_MAX*4/7 and rpos[0] < cwiid.IR_X_MAX*6/7:
            movement = "ur"
        elif rpos[1]>cwiid.IR_Y_MAX-H and rpos[0] > cwiid.IR_X_MAX*4/7 and rpos[0] < cwiid.IR_X_MAX*6/7:
            movement = "dr"

        if not movement == self.last_movement or pygame.time.get_ticks() > self.last + 850:
            self.last_movement = movement
            self.last = pygame.time.get_ticks()
            return movement

    def close(self):
        try:
            self.close()
            self.initialized = False
        except:
            formatExceptionInfo()

class Zone(Entity):

    image = halocircle((100,100,255,128), 200, 224, 0.3, 0.75, 0.1)
    layer = "points"

class Arrow(Entity):
    image = os.path.join(LINUX_GAME_PATH, 'images','common','arrow.png')
    layer = "arrow"

    def init(self, direction, hand):
        if hand == 'left':
            self.set(centerx = SELECTED_RESOLUTION[0]*2/7, centery = SELECTED_RESOLUTION[1]/2).place("arrow")
        elif hand == 'right':
            self.set(centerx = SELECTED_RESOLUTION[0]*5/7, centery = SELECTED_RESOLUTION[1]/2).place("arrow")
        if direction == "up":
            self.do(MoveDelta(0,-SELECTED_RESOLUTION[1]/3, 1.0)+Delete())
            self.do(AlphaFade(0.0,1.0))
        elif direction == "down":
            self.set(angle=180)
            self.do(MoveDelta(0,+SELECTED_RESOLUTION[1]/3, 1.0)+Delete())
            self.do(AlphaFade(0.0,1.0))
        elif direction == "right":
            self.set(angle=90)
            self.do(MoveDelta(SELECTED_RESOLUTION[0]/3,0, 1.0)+Delete())
            self.do(AlphaFade(0.0,1.0))
        elif direction == "left":
            self.set(angle=-90)
            self.do(MoveDelta(-SELECTED_RESOLUTION[0]/3,0, 1.0)+Delete())
            self.do(AlphaFade(0.0,1.0))

class CircleList(list):

    def __init__(self, len=50):
        list.__init__(self)
        for i in range(len):
            self.insert(0,0)
        self.pos = 0
        self.len = len

    def append(self, e):
        self[self.pos] =  e
        self.pos = (self.pos+1)%self.len



class IR_tracking(Scene):

    def init(self, next_scene = None, previous_scene = None):
        self.next_scene = next_scene
        self.previous_scene = previous_scene
        self.wiimote = None

    def enter(self):
        self.i = 0
        if VOLUME:
            try:
                pygame.mixer.music.stop()
                pygame.mixer.music.set_volume(VOLUME*0.01)
                pygame.mixer.music.load(os.path.join(LINUX_GAME_PATH, MUSIC_PATH, 'menuintro.ogg'))
                pygame.mixer.music.play(-1)
            except:
                formatExceptionInfo()

        self.new_static("bg")
        self.new_layer("points")
        self.new_layer("info")
        self.new_layer("arrow")

        screen.clear_color = (0,0,0)

        ## Load the background.
        e = Entity(os.path.join(LINUX_GAME_PATH, MENU_PATH, 'option-bg.png'), hotspot=(0,0))
        e.set(centerx=SELECTED_RESOLUTION[0]/2,centery=SELECTED_RESOLUTION[1]/2, scale=SELECTED_RESOLUTION[1]/float(e.height)).place("bg")

        self.font = font = GLFont(("/usr/share/fonts/truetype/ttf-larabie-straight/zerothre.ttf", SELECTED_RESOLUTION[0]/30))
        self.mensaje = TextEntity(self.font, "Conecte el adaptador bluetooth a su equipo,\n    active su receptor IR (Presione 1+2)   \n     y pulse ESPACIO cuando este listo     ")
        self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)
        self.info = TextEntity(self.font, "Bateria: ??%", 0.5 )
        self.ring = Entity(os.path.join(LINUX_GAME_PATH, 'images',"common", "ring.png"))
        self.ring.set(scale = SELECTED_RESOLUTION[0]/float(5*self.ring.width), centerx = SELECTED_RESOLUTION[0]/10, centery = SELECTED_RESOLUTION[0]/10)
        d = Entity(os.path.join(LINUX_GAME_PATH, MENU_PATH, 'wiimote.png'), hotspot=(0,0))
        d.set(alpha=160, scale = float(self.ring.width)/d.width, centerx = SELECTED_RESOLUTION[0]/10, centery = SELECTED_RESOLUTION[0]/10).place("points")
        self.ring.place("points")
        self.ring.do(RotateDelta(360,2.0,RepeatMode))
        self.info.set(centerx=SELECTED_RESOLUTION[0]/10, centery=SELECTED_RESOLUTION[0]/10)
        self.mensaje.place("info")
        self.info.place("info")

        self.calibration = []

        self.wiimote = None

        #wiimote.start()
        zi = Zone()
        zi.set(centerx = SELECTED_RESOLUTION[0]*2/7, centery = SELECTED_RESOLUTION[1]/2, scale = 0.25).place('points')

        zd = Zone()
        zd.set(centerx = SELECTED_RESOLUTION[0]*5/7, centery = SELECTED_RESOLUTION[1]/2, scale = 0.25).place('points')

        zii = Zone()
        zii.set(centerx = SELECTED_RESOLUTION[0]/8, centery = SELECTED_RESOLUTION[1]/2, scale = 0.25).place('points')

        zdd = Zone()
        zdd.set(centerx = SELECTED_RESOLUTION[0]*7/8, centery = SELECTED_RESOLUTION[1]/2, scale = 0.25).place('points')

        ziu = Zone()
        ziu.set(centerx = SELECTED_RESOLUTION[0]*2/7, centery = SELECTED_RESOLUTION[1]/6, scale = 0.25).place('points')

        zil = Zone()
        zil.set(centerx = SELECTED_RESOLUTION[0]*2/7, centery = SELECTED_RESOLUTION[1]*5/6, scale = 0.25).place('points')

        zdu = Zone()
        zdu.set(centerx = SELECTED_RESOLUTION[0]*5/7, centery = SELECTED_RESOLUTION[1]/6, scale = 0.25).place('points')

        zdl = Zone()
        zdl.set(centerx = SELECTED_RESOLUTION[0]*5/7, centery = SELECTED_RESOLUTION[1]*5/6, scale = 0.25).place('points')

        self.zones = [zi, zii, zd, zdd, zil, ziu, zdu, zdl]
        for z in self.zones:
            z.do(Hide())


    def load_game(self):
        #wiimote.join()
        if self.next_scene:
            director.wiimote = self.wiimote
            self.next_scene.wiimote = self.wiimote
            for e in self.get_layer('points'): e.do(AlphaFade(0,1.5))
            for e in self.get_layer('info'): e.do(AlphaFade(0,1.5))
            for e in self.get_layer('arrow'): e.do(AlphaFade(0,1.5))
            self.ring.do(Delay(1.6)+CallFunc(director.set_scene, self.next_scene))
        else:
            self.wiimote.close()
            director.quit()


    def tick(self):
        pass

    def realtick(self):
        if not self.wiimote:
            return 0
        elif self.wiimote.initialized :
            self.wiimote.get_status()
            for z in self.zones:
                z.do(Show())
            self.mensaje.set_text("Calibrando movimientos...\nEl juego empezara cuando\nrecorra todas las zonas")
            self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)
            state = self.wiimote.get_status()
            if state:
                self.info.set_text("Bateria: %d%%" % (state['battery']*100/cwiid.BATTERY_MAX), 0.5)
            mov = self.wiimote.get_movement()
            if mov:
                if not mov in self.calibration:
                    self.calibration.append(mov)
                if mov == "ll":
                    Arrow(direction = 'left', hand= 'left')
                elif mov == "ul":
                    Arrow(direction = 'up', hand= 'left')
                elif mov == "dl":
                    Arrow(direction = 'down', hand= 'left')
                elif mov == "rr":
                    Arrow(direction = 'right', hand= 'right')
                elif mov == "ur":
                    Arrow(direction = 'up', hand= 'right')
                elif mov == "dr":
                    Arrow(direction = 'down', hand= 'right')
            if len(self.calibration) == 6:
                self.load_game()
        else:
            self.mensaje.set_text("No se han encontrado receptores IR.\n Pulse ESPACIO para buscar otra vez")
            self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)


    def handle_keydown(self, ev):
        if ev.key == K_ESCAPE:
            self.load_game()
        elif ev.key == K_SPACE:
            self.mensaje.set_text("Buscando dispositivos...")
            self.mensaje.set(centerx=SELECTED_RESOLUTION[0]/2, centery=SELECTED_RESOLUTION[1]/2)
            self.ring.do(Delay(0.25)+CallFunc(self.scan))
        elif ev.key == K_RETURN:
            self.load_game()


    def scan(self):
        if not self.wiimote or not self.wiimote.initialized:
            self.wiimote = IRreceptor()

if __name__ == "__main__":
    screen.init(SELECTED_RESOLUTION, title="Wiimote Test")
    director.run(IR_tracking)
    print "ticks per sec", director.ticks/director.secs
    print "realticks per sec", director.realticks/director.secs
